# 独立语义审查 semantic_1

审查身份：`/root/semantic_review_one`；independent=true；fresh_context=true。
packet：`fidelity/packets/semantic_1-20261031T013834Z-c93b8281`，manifest SHA-256 `9fbc3c3b40ae2cde359cc0af9e289ed9e998975efee93c1c50d07fa6f074fff1`。

已对全部424条canonical义务给出objects、statement、hypotheses、conclusion、nonvacuity五项判断：2120项pass，0项fail，0项blocked。每项证据精确绑定冻结规范、原文页/公式与完整编译环境的type/definition哈希；完整记录见semantic_1.json。

数学结论是本次逐条比较的结果，不是编译状态或其他审阅的转述。559个映射入口均无缺失，2709个导出type的SHA-256匹配；通读原文15页并核对7种Weyl定义、tau平方、总和偶子格、有限支撑、空宽、三处倍数2、取消后特化和七个新增零参数出口。

技术边界：仅使用packet允许副本，未读实现源文件、其他packet或同事裁决，未复跑编译；定理完整proof terms未提供。本审查验证数学对象、命题范围、已编译类型与实际依赖，不代替独立route裁决或编译器认证。raw B重复内容按主题与canonical及原文核对；所有辅助证明见证只做索引，未声称对每个字节作数学理解。

关键读法：Spec与ExternalHL的符号函数位置通过signsReindex的全Weyl和重索引统一；整数下标负值先置零再toNat；support的延拓整数m和有限矩阵p区分；宽零的数值可去奇点在有理函数取消后解释，未把未消去的0/0总除法值算作1。旧C6.2证书本身不涵盖七特化，当前另有accepted_C62_zero。

| # | Canonical ID | 五维 | 本条数学核对 |
|---:|---|---|---|
| 0 | `CONV.variables` | pass / pass / pass / pass / pass | PaperField和独立ParameterField均为FractionRing(MvPolynomial(Fin(n+1),ℚ))；第0变量是参数，第a+1变量取成Units；不是给结论预设的一般系数系统。 |
| 1 | `DEF.Edot` | pass / pass / pass / pass / pass | 每个互反二次因子明确是(1+x_a u)(1+x_a⁻¹u)，有限乘积的整数系数由intCoeff提取；Spec的区间检查只再显式截掉已为零的高次项。 |
| 2 | `DEF.Eddot` | pass / pass / pass / pass / pass | 两边的Eddot定义都是(1+u)Edot；次数至多2n+1而非2n。 |
| 3 | `CONV.edot.zero` | pass / pass / pass / pass / pass | intCoeff先检测r<0才用r.toNat，因此负整数不会误读为常数系数；r>2n由dotE_degree_le强制为零。 |
| 4 | `CONV.eddot.zero` | pass / pass / pass / pass / pass | 负下标显式为零，高下标以ddotE_degree_le≤2n+1处理，端点2n+1保留。 |
| 5 | `COEFF.edot.palindrome` | pass / pass / pass / pass / pass | reflect(2n,dotE)=dotE加次数界经intCoeff_pal给全部整数r的回文，不限于原非负系数。 |
| 6 | `COEFF.eddot.palindrome` | pass / pass / pass / pass / pass | Eddot用reflect(2n+1)；整数零延拓与反射一起覆盖区间外r。 |
| 7 | `COEFF.eddot.sum` | pass / pass / pass / pass / pass | intCoeff_one_add_X_mul对任意整数r给coeff((1+X)P,r)=coeff(P,r)+coeff(P,r−1)，包括r=0。 |
| 8 | `DEF.Lambda` | pass / pass / pass / pass / pass | lambdaKernel中i先经paperIndex=i.val+1转为整数；两个下标分别n−i+m和n+i+m，第二项为减号。 |
| 9 | `DEF.h` | pass / pass / pass / pass / pass | hKernel使用整数下标n−i+m和n+i+m−1；移位不是自然数截减。 |
| 10 | `DEF.hplus` | pass / pass / pass / pass / pass | hPlusKernel第二下标减2，区别于h的减1；第一下标不变。 |
| 11 | `DEF.hhat` | pass / pass / pass / pass / pass | hHatKernel两个项都取eDdot而非eDot，下标仍是h的减1型。 |
| 12 | `DEF.J` | pass / pass / pass / pass / pass | jkMatrix(i,j)=w_j(y_i)F_i(j−Ky_i)，JKOn用命题过滤该行列式；没有把列权重误换为w_i。 |
| 13 | `CONV.weight.slot` | pass / pass / pass / pass / pass | 权重函数第一个参数是列j，但取值位移是行y_i；这正是原文权重槽约定。 |
| 14 | `DEF.even.lattice` | pass / pass / pass / pass / pass | EvenVector和EvenLattice都只对sum_i y_i施加Even；例如(1,1)属于子格，绝非逐分量偶数。 |
| 15 | `CONV.empty.det` | pass / pass / pass / pass / pass | det_fin_zero_eq_one量化任意Fin0方阵，空排列的唯一积给1。 |
| 16 | `CONV.empty.sum` | pass / pass / pass / pass / pass | JK_zero和JKEven_zero对任意K和空权重函数均等于1；Fin0→ℤ有唯一向量，Fin0没有可求值的条目。 |
| 17 | `CONV.field.t` | pass / pass / pass / pass / pass | 一个参数不定元连同n个x变量的分式域就是ℚ(t,x)；形式变量的非零性不是额外数值限制。 |
| 18 | `CONV.field.tau` | pass / pass / pass / pass / pass | BC和Bminus的Weyl基参数实际代入τ²；权重直接取整数τ幂，所有有符号幂在形式τ的域中合法。 |
| 19 | `CONV.finite.sums` | pass / pass / pass / pass / pass | 零延拓先给每行核有限支撑；K≠0时y↦j−Ky单射，再由矩阵各行的有限支撑给行列式在ℤ^k的有限支撑；k=0由唯一空向量另处处理。 |
| 20 | `A.1.3` | pass / pass / pass / pass / pass | B0的paper入口只要求n>0，k任意Nat；指数的整数除2经B0_exponent_exact/cast等于原半整数写法，核是h、周期2k+1、仿射符号(−1)^y。 |
| 21 | `A.1.4` | pass / pass / pass / pass / pass | Bminus入口k可为0，基参数τ²和边界(1+τz)/(1−z)均来自原Weyl定义；右边周期2k且τ指数2ky²−(2j−1)y无交替符号。 |
| 22 | `A.1.5` | pass / pass / pass / pass / pass | Bplus的paper入口明确要求k>0，右端外部2⁻¹、周期2k、hPlus核与(−1)^y权重均保留。 |
| 23 | `A.1.6` | pass / pass / pass / pass / pass | C0入口k任意Nat，周期2k+2，指数(k+1)y²−jy，减号Lambda核；没有多余半因子。 |
| 24 | `A.1.7` | pass / pass / pass / pass / pass | Ct入口k任意Nat，右端是JKEven而非JK；权重无(−1)^y并且无外部半因子。 |
| 25 | `A.1.8` | pass / pass / pass / pass / pass | BC入口用形式τ作唯一参数，左边实际Weyl基参数τ²；右边周期2k+1、(−1)^y、τ指数(2k+1)y²−2jy。 |
| 26 | `A.Bplus.widthzero` | pass / pass / pass / pass / pass | Bplus宽零由独立width_zero入口给1；没有把正宽半行列式延至空矩阵。 |
| 27 | `B.1.9` | pass / pass / pass / pass / pass | Bt入口同时要求n,k>0，hHat核、Bplus型权重及外部半因子对应(1.9)。 |
| 28 | `B.widthzero` | pass / pass / pass / pass / pass | Bt空矩形另用nuCt归一化宽零定理给1；不把1/2带入空det。 |
| 29 | `DEF.case.C0` | pass / pass / pass / pass / pass | C0对象是weylSum的实际定义代入，rho=(1−z²)⁻¹，宽零nu=1；其对称化参数是t。 |
| 30 | `DEF.rho.C0` | pass / pass / pass / pass / pass | 独立rho分支和ExternalHL.C0定义都给(1−z²)⁻¹；分母结构确与原文表中C0行相同。 |
| 31 | `DEF.nu0.C0` | pass / pass / pass / pass / pass | k=0时C0边界因子展开为1；匹配nuZero的实际case matcher，而非依靠枚举顺序猜测。 |
| 32 | `DEF.case.Ct` | pass / pass / pass / pass / pass | Ct对象是weylSum的实际定义代入，rho=(1−tz²)/(1−z²)，宽零nu=∏_{r=1}^n(1+t^r)；其对称化参数是t。 |
| 33 | `DEF.rho.Ct` | pass / pass / pass / pass / pass | 独立rho分支和ExternalHL.Ct定义都给(1−tz²)/(1−z²)；分母结构确与原文表中Ct行相同。 |
| 34 | `DEF.nu0.Ct` | pass / pass / pass / pass / pass | k=0时Ct边界因子展开为∏_{r=1}^n(1+t^r)；匹配nuZero的实际case matcher，而非依靠枚举顺序猜测。 |
| 35 | `DEF.case.BC` | pass / pass / pass / pass / pass | BC对象是weylSum的实际定义代入，rho=(1+τz)/(1−z²)，宽零nu=1；其对称化参数是τ²。 |
| 36 | `DEF.rho.BC` | pass / pass / pass / pass / pass | 独立rho分支和ExternalHL.BC定义都给(1+τz)/(1−z²)；分母结构确与原文表中BC行相同。 |
| 37 | `DEF.nu0.BC` | pass / pass / pass / pass / pass | k=0时BC边界因子展开为1；匹配nuZero的实际case matcher，而非依靠枚举顺序猜测。 |
| 38 | `DEF.case.B0` | pass / pass / pass / pass / pass | B0对象是weylSum的实际定义代入，rho=(1−z)⁻¹，宽零nu=1；其对称化参数是t。 |
| 39 | `DEF.rho.B0` | pass / pass / pass / pass / pass | 独立rho分支和ExternalHL.B0定义都给(1−z)⁻¹；分母结构确与原文表中B0行相同。 |
| 40 | `DEF.nu0.B0` | pass / pass / pass / pass / pass | k=0时B0边界因子展开为1；匹配nuZero的实际case matcher，而非依靠枚举顺序猜测。 |
| 41 | `DEF.case.Bminus` | pass / pass / pass / pass / pass | Bminus对象是weylSum的实际定义代入，rho=(1+τz)/(1−z)，宽零nu=∏_{r=1}^n(1−τ^(2r−1))；其对称化参数是τ²。 |
| 42 | `DEF.rho.Bminus` | pass / pass / pass / pass / pass | 独立rho分支和ExternalHL.Bminus定义都给(1+τz)/(1−z)；分母结构确与原文表中Bminus行相同。 |
| 43 | `DEF.nu0.Bminus` | pass / pass / pass / pass / pass | k=0时Bminus边界因子展开为∏_{r=1}^n(1−τ^(2r−1))；匹配nuZero的实际case matcher，而非依靠枚举顺序猜测。 |
| 44 | `DEF.case.Bplus` | pass / pass / pass / pass / pass | Bplus对象是weylSum的实际定义代入，rho=1，宽零nu=∏_{r=1}^n(1+t^(r−1))；其对称化参数是t。 |
| 45 | `DEF.rho.Bplus` | pass / pass / pass / pass / pass | 独立rho分支和ExternalHL.Bplus定义都给1；分母结构确与原文表中Bplus行相同。 |
| 46 | `DEF.nu0.Bplus` | pass / pass / pass / pass / pass | k=0时Bplus边界因子展开为∏_{r=1}^n(1+t^(r−1))；匹配nuZero的实际case matcher，而非依靠枚举顺序猜测。 |
| 47 | `DEF.case.Bt` | pass / pass / pass / pass / pass | Bt对象是weylSum的实际定义代入，rho=(1−tz)/(1−z)，宽零nu=∏_{r=1}^n(1+t^r)；其对称化参数是t。 |
| 48 | `DEF.rho.Bt` | pass / pass / pass / pass / pass | 独立rho分支和ExternalHL.Bt定义都给(1−tz)/(1−z)；分母结构确与原文表中Bt行相同。 |
| 49 | `DEF.nu0.Bt` | pass / pass / pass / pass / pass | k=0时Bt边界因子展开为∏_{r=1}^n(1+t^r)；匹配nuZero的实际case matcher，而非依靠枚举顺序猜测。 |
| 50 | `DEF.pochhammer` | pass / pass / pass / pass / pass | pochhammer用Fin n乘积(1−a t^r.val)，故下标从0到n−1且n=0是空积。 |
| 51 | `DEF.Vn` | pass / pass / pass / pass / pass | Vn的r.val+1项有限几何和对应纸面r=1,…,n；不是Pochhammer的乘积。 |
| 52 | `DEF.Wn` | pass / pass / pass / pass / pass | 实现把全体置换与Bool符号函数作双有限和；Spec在位置a先取符号而实现在σa取符号，signsReindex用η∘σ⁻¹给双射，weylPoint_eq及numerator_eq证明两种全和相等。 |
| 53 | `DEF.nu.positive` | pass / pass / pass / pass / pass | 三种非平凡nu均用if k=0 then pochhammer else1，其余case恒为1；正宽条件足以选择else。 |
| 54 | `DEF.P.weylsum` | pass / pass / pass / pass / pass | 两种独立定义均以原Weyl根因子((tu_a−u_b)(1−tu_au_b))/((u_a−u_b)(1−u_au_b))和u_a^(−k)作全Weyl和，再除Vn·nu；P没有被定义成待证仿射右边。 |
| 55 | `SYMMETRIZER` | pass / pass / pass / pass / pass | symmetrizer的结论正是全部Perm的有序差商之和=Vn，Injective z只保证纸面独立变量的分母非零。 |
| 56 | `SYMMETRIZER.recurrence` | pass / pass / pass / pass / pass | Vn_succ按秩n+1给几何和乘Vn_n；zeroHead把交错式在一个变量为0时化为低一秩式，读完整type的隐式n避免把两秩误看成同一对象。 |
| 57 | `WEYL.symmetric.normalization` | pass / pass / pass / pass / pass | weylSum归一化分母始终含Vn，不因k=0去掉；只有nu的if分支随宽度变化。 |
| 58 | `WEYL.inversion.reduction` | pass / pass / pass / pass / pass | reducedWeyl删掉的是置换差商，保留全部反演、rho和配对比值；weylSum_eq_reducedWeyl的1/nu未丢失，k没有正宽要求。 |
| 59 | `DEF.Nt` | pass / pass / pass / pass / pass | Nt按a<b各一次乘(z_a−z_b)(1−tz_az_b)，Spec用全a,b中的if a<b，语义相同。 |
| 60 | `DEF.fr.first` | pass / pass / pass / pass / pass | fColumn的r.val=0分支只有z^(n−1)，不叠加两项造成首列2。 |
| 61 | `DEF.fr.rest` | pass / pass / pass / pass / pass | 当纸面r=r.val+1≥2时，两个自然幂分别n−r和n+r−2，Fin n保证首幂非负，t幂r−1。 |
| 62 | `L2.1.2.3` | pass / pass / pass / pass / pass | lemma_2_1_eq_2_3对任意域元素t,z直接给det(fColumn)=Nt，比分式域形式变量结论更强，n=1也保留单列。 |
| 63 | `L2.1.2.4` | pass / pass / pass / pass / pass | 第二列族的指数按r.val+1换算为n−r和n+r，负号和t^r正确，行因子是1−tz_a²。 |
| 64 | `L2.1.2.5` | pass / pass / pass / pass / pass | 第三列族给n−r和n+r−1，τ幂2r−1，Nt的参数是τ²；行因子是1+τz_a。 |
| 65 | `L2.1.first.alternating` | pass / pass / pass / pass / pass | 交换两个z行改变det符号；相等行时det为0，difference_factor_dvd_any_pair将任意不同下标差因子落实在多元多项式环。 |
| 66 | `L2.1.first.reflection` | pass / pass / pass / pass / pass | 行比例系数((tz_a)⁻¹)^(n−1)/z_a^(n−1)=t^(1−n)z_a^(2−2n)，vanish和factor_dvd连接为互反因子整除。 |
| 67 | `L2.1.first.degree` | pass / pass / pass / pass / pass | 列次数求和上界3·card(pairIndex)，pairIndex的基数为n(n−1)/2；非零形式t使全部因子总次数恰取同值。 |
| 68 | `L2.1.first.constant` | pass / pass / pass / pass / pass | 用外变量s缩放所有z，最低s次数n(n−1)/2的系数是下降Vandermonde；因子积同系数，故常数必须1。 |
| 69 | `L2.1.second.alternating` | pass / pass / pass / pass / pass | Ct列族同样为逐行求值的交错det，任意差因子整除它，与basic列族没有混用。 |
| 70 | `L2.1.second.reflection` | pass / pass / pass / pass / pass | Ct比例系数−((tz_a)⁻¹)^n/z_a^n=−t^(−n)z_a^(−2n)，给第二式的互反因子。 |
| 71 | `L2.1.second.degree` | pass / pass / pass / pass / pass | Ct次数界在3·binom(n,2)外另加2n，恰是n个二次行因子的次数；未遗漏它们。 |
| 72 | `L2.1.second.constant` | pass / pass / pass / pass / pass | Ct最低缩放次数仍为binom(n,2)，最低系数是同一Vandermonde，所以额外行因子不改变常数1。 |
| 73 | `L2.1.third.alternating` | pass / pass / pass / pass / pass | Bminus列族交错；差因子在τ参数的多元多项式det中整除。 |
| 74 | `L2.1.third.reflection` | pass / pass / pass / pass / pass | Bminus行比例τ·((τ²z_a)⁻¹)^n/z_a^(n−1)=τ^(1−2n)z_a^(1−2n)；Nt参数确为τ²。 |
| 75 | `L2.1.third.degree` | pass / pass / pass / pass / pass | 第三式总次数3·binom(n,2)+n，增加的是n个一次因子1+τz_a。 |
| 76 | `L2.1.third.constant` | pass / pass / pass / pass / pass | 第三式最低缩放系数也是下降Vandermonde；行因子常数项1，剩余常数锁定为1。 |
| 77 | `L2.1.second.rowfactor` | pass / pass / pass / pass / pass | ct_column_extra_row_factor以有限几何和行商给每个条目(1−tz²)的乘积分解，det按行取出这些因子。 |
| 78 | `L2.1.third.rowfactor` | pass / pass / pass / pass / pass | bminus_column_extra_row_factor给(1+τz)乘行商；形式τ非零时z=−τ⁻¹使整行消失。 |
| 79 | `L2.1.Gauss` | pass / pass / pass / pass / pass | 三个factor_dvd闭包均实际含FractionRing、Polynomial.IsPrimitive.dvd_of_fraction_map_dvd_fraction_map以及根整除；full_factor_product_dvd再调用两两IsRelPrime的乘积整除。这里是确有Gauss返回步骤，而非把最终等式当作路线证据。 |
| 80 | `DEF.phi` | pass / pass / pass / pass / pass | phi用整数zpow差z^m−z^(−m)；z作为unit时与Laurent含义一致。 |
| 81 | `DEF.psi` | pass / pass / pass / pass / pass | psi第二幂是1−m，对应有移位的B反演，不是phi。 |
| 82 | `DEF.C` | pass / pass / pass / pass / pass | Cfun是z^m+z^(−m)，从而Cfun0=2，不与常数首列chi1混同。 |
| 83 | `DEF.L.basis` | pass / pass / pass / pass / pass | 标准坐标由paperIndex(p)=p.val+1与Kronecker basis给出，维数n+k；商空间中的坐标公式确使用同一原空间。 |
| 84 | `DEF.fold.C.positive` | pass / pass / pass / pass / pass | 正m且m≤L时bracketC只有paperIndex(p)=m处取1，其负指标分支不可能同时触发。 |
| 85 | `DEF.fold.C.zero` | pass / pass / pass / pass / pass | m=0与正paperIndex(p)及其负值都不同，故bracketC逐分量零。 |
| 86 | `DEF.fold.C.negative` | pass / pass / pass / pass / pass | 负m时唯一可能非零项是m=−paperIndex(p)，系数−1，因而是−e_(−m)。 |
| 87 | `DEF.fold.B.positive` | pass / pass / pass / pass / pass | B的m≥1分支在m=paperIndex(p)取1，反射位置1−m≤0不能触发。 |
| 88 | `DEF.fold.B.nonpositive` | pass / pass / pass / pass / pass | B的m≤0只能触发1−m=paperIndex(p)，且系数−1。 |
| 89 | `DEF.fold.plus.large` | pass / pass / pass / pass / pass | plus的m≥2避开m=1特例，直接给坐标e_m。 |
| 90 | `DEF.fold.plus.center` | pass / pass / pass / pass / pass | plus先检测m=1，在p.val=0取2，正是C0=2强制的2e1。 |
| 91 | `DEF.fold.plus.nonpositive` | pass / pass / pass / pass / pass | plus的m≤0经2−m≥2反射到e_(2−m)，符号为正。 |
| 92 | `CONV.fold.range` | pass / pass / pass / pass / pass | 三种bracket评估定理分别限制m在[−L,L]、[1−L,L]、[2−L,L]；这些恰保证所有非零折叠坐标存在。 |
| 93 | `DEF.Phi.C` | pass / pass / pass / pass / pass | PhiC的列p取phi_(paperIndex p)，矩阵维数n×(n+k)，没有把k当秩。 |
| 94 | `DEF.Phi.B` | pass / pass / pass / pass / pass | PhiB同样用psi的纸面列号p，维数和x行一致。 |
| 95 | `DEF.Phi.plus.first` | pass / pass / pass / pass / pass | PhiPlus在p.val=0强制为1，未使用Cfun0。 |
| 96 | `DEF.Phi.plus.rest` | pass / pass / pass / pass / pass | PhiPlus其余列取Cfun_(p.val)，即纸面C_(p−1)。 |
| 97 | `FOLD.eval.C` | pass / pass / pass / pass / pass | PhiC_bracket在准确允许范围把有限坐标和还原phi_m，m=0自动给0。 |
| 98 | `FOLD.eval.B` | pass / pass / pass / pass / pass | PhiB_bracket用psi_(1−m)=−psi_m处理负段，原文的有移位范围得到保留。 |
| 99 | `FOLD.eval.plus` | pass / pass / pass / pass / pass | PhiPlus_bracket连m=1都给Cfun0=2；因2e1与首列1相乘而成立。 |
| 100 | `DEF.chi.first` | pass / pass / pass / pass / pass | chi1由PhiPlus的常数首列和weylPolyPlus0=1确定，不等于Cfun0=2。 |
| 101 | `DEF.chi.rest` | pass / pass / pass / pass / pass | chi_r对应weylPolyPlus_(r−1)，r≥2时其求值为Cfun_(r−1)。 |
| 102 | `WEYL.denominator.C` | pass / pass / pass / pass / pass | DeltaC定义即前n个phi列的det；product公式含(−1)^n、每变量z^(−n)(1−z²)及Nt1，符号一致。 |
| 103 | `WEYL.denominator.monic.C` | pass / pass / pass / pass / pass | weylPolyC_r单项首一次数r，乘z−z⁻¹后等于phi_(r+1)，给纸面次数r−1的商多项式。 |
| 104 | `WEYL.denominator.inversion.C` | pass / pass / pass / pass / pass | 多行反演公式中的乘积每个被反演行仅乘−1，单行特例即原文。 |
| 105 | `WEYL.denominator.B` | pass / pass / pass / pass / pass | DeltaB的每变量幂为−n+1，因子1−z，外有(−1)^n；与psi_1=z−1的符号相符。 |
| 106 | `WEYL.denominator.monic.B` | pass / pass / pass / pass / pass | weylPolyB_r首一次数r，乘z−1后为psi_(r+1)，故Vandermonde次数和列排序一致。 |
| 107 | `WEYL.denominator.inversion.B` | pass / pass / pass / pass / pass | DeltaB反演乘积的单行因子−z⁻¹，保留了移位导致的非恒定因子。 |
| 108 | `WEYL.denominator.plus` | pass / pass / pass / pass / pass | DeltaPlus的常数首列使外部没有(−1)^n和单变量边界因子，只有z^(−n+1)Nt1。 |
| 109 | `WEYL.denominator.monic.plus` | pass / pass / pass / pass / pass | weylPolyPlus的r=0特判保证常数1，r>0为Dickson首一多项式；对应chi_r次数r−1。 |
| 110 | `WEYL.denominator.inversion.plus` | pass / pass / pass / pass / pass | DeltaPlus对全部指定反演行保持不变，因为每个Cfun对反演不变且首列恒1。 |
| 111 | `DEF.u.C.first` | pass / pass / pass / pass / pass | C折叠的u列在r.val=0单独定义成[k+1]，因此首列无一般式的第二项。 |
| 112 | `DEF.u.C.rest` | pass / pass / pass / pass / pass | C折叠的u列在r.val>0时paperIndex=r.val+1；两括号指标为k+r及k+2−r，参数幂r.val=r−1，整数负指标保留。 |
| 113 | `DEF.u.B.first` | pass / pass / pass / pass / pass | B折叠的u列在r.val=0单独定义成[k+1]，因此首列无一般式的第二项。 |
| 114 | `DEF.u.B.rest` | pass / pass / pass / pass / pass | B折叠的u列在r.val>0时paperIndex=r.val+1；两括号指标为k+r及k+2−r，参数幂r.val=r−1，整数负指标保留。 |
| 115 | `DEF.u.+.first` | pass / pass / pass / pass / pass | plus折叠的u列在r.val=0单独定义成[k+1]，因此首列无一般式的第二项。 |
| 116 | `DEF.u.+.rest` | pass / pass / pass / pass / pass | plus折叠的u列在r.val>0时paperIndex=r.val+1；两括号指标为k+r及k+2−r，参数幂r.val=r−1，整数负指标保留。 |
| 117 | `DEF.utilde.C.first` | pass / pass / pass / pass / pass | C折叠的tilde列在r.val=0单独定义成[k]，因此首列无一般式的第二项。 |
| 118 | `DEF.utilde.C.rest` | pass / pass / pass / pass / pass | C折叠的tilde列在r.val>0时paperIndex=r.val+1；两括号指标为k+r−1及k+1−r，参数幂r.val=r−1，整数负指标保留。 |
| 119 | `DEF.utilde.B.first` | pass / pass / pass / pass / pass | B折叠的tilde列在r.val=0单独定义成[k]，因此首列无一般式的第二项。 |
| 120 | `DEF.utilde.B.rest` | pass / pass / pass / pass / pass | B折叠的tilde列在r.val>0时paperIndex=r.val+1；两括号指标为k+r−1及k+1−r，参数幂r.val=r−1，整数负指标保留。 |
| 121 | `DEF.V.C0` | pass / pass / pass / pass / pass | VC0逐行逐列定义为uC，实际是(n+k)×n矩阵；caseFolding指定C评估与对应Delta。 |
| 122 | `P2.2.ratio.C0` | pass / pass / pass / pass / pass | C0的paper_prop_2_2入口以独立ExternalHL Weyl和为左边、det(PhiC·VC0)/DeltaC为右边；只要求n,k>0，所需数值非零条件在形式变量上已证明。 |
| 123 | `P2.2.minor.C0` | pass / pass / pass / pass / pass | VC0尾块选行k+i.val，即纸面k+1,…,k+n；k>0使首括号给对角1且其余折叠行都在其上，故det=1。 |
| 124 | `DEF.V.Ct` | pass / pass / pass / pass / pass | VCt逐行逐列定义为[k+r]C−t^r[k−r]C，实际是(n+k)×n矩阵；caseFolding指定C评估与对应Delta。 |
| 125 | `P2.2.ratio.Ct` | pass / pass / pass / pass / pass | Ct的paper_prop_2_2入口以独立ExternalHL Weyl和为左边、det(PhiC·VCt)/DeltaC为右边；只要求n,k>0，所需数值非零条件在形式变量上已证明。 |
| 126 | `P2.2.minor.Ct` | pass / pass / pass / pass / pass | VCt尾块选行k+i.val，即纸面k+1,…,k+n；k>0使首括号给对角1且其余折叠行都在其上，故det=1。 |
| 127 | `DEF.V.BC` | pass / pass / pass / pass / pass | VBC逐行逐列定义为uC(τ²)+τ uCTilde(τ²)，实际是(n+k)×n矩阵；caseFolding指定C评估与对应Delta。 |
| 128 | `P2.2.ratio.BC` | pass / pass / pass / pass / pass | BC的paper_prop_2_2入口以独立ExternalHL Weyl和为左边、det(PhiC·VBC)/DeltaC为右边；只要求n,k>0，所需数值非零条件在形式变量上已证明。 |
| 129 | `P2.2.minor.BC` | pass / pass / pass / pass / pass | VBC尾块选行k+i.val，即纸面k+1,…,k+n；k>0使首括号给对角1且其余折叠行都在其上，故det=1。 |
| 130 | `DEF.V.B0` | pass / pass / pass / pass / pass | VB0逐行逐列定义为uB，实际是(n+k)×n矩阵；caseFolding指定B评估与对应Delta。 |
| 131 | `P2.2.ratio.B0` | pass / pass / pass / pass / pass | B0的paper_prop_2_2入口以独立ExternalHL Weyl和为左边、det(PhiB·VB0)/DeltaB为右边；只要求n,k>0，所需数值非零条件在形式变量上已证明。 |
| 132 | `P2.2.minor.B0` | pass / pass / pass / pass / pass | VB0尾块选行k+i.val，即纸面k+1,…,k+n；k>0使首括号给对角1且其余折叠行都在其上，故det=1。 |
| 133 | `DEF.V.Bminus` | pass / pass / pass / pass / pass | VBminus逐行逐列定义为[k+r]B+τ^(2r−1)[k+1−r]B，实际是(n+k)×n矩阵；caseFolding指定B评估与对应Delta。 |
| 134 | `P2.2.ratio.Bminus` | pass / pass / pass / pass / pass | Bminus的paper_prop_2_2入口以独立ExternalHL Weyl和为左边、det(PhiB·VBminus)/DeltaB为右边；只要求n,k>0，所需数值非零条件在形式变量上已证明。 |
| 135 | `P2.2.minor.Bminus` | pass / pass / pass / pass / pass | VBminus尾块选行k+i.val，即纸面k+1,…,k+n；k>0使首括号给对角1且其余折叠行都在其上，故det=1。 |
| 136 | `DEF.V.Bplus` | pass / pass / pass / pass / pass | VBplus逐行逐列定义为uPlus，实际是(n+k)×n矩阵；caseFolding指定plus评估与对应Delta。 |
| 137 | `P2.2.ratio.Bplus` | pass / pass / pass / pass / pass | Bplus的paper_prop_2_2入口以独立ExternalHL Weyl和为左边、det(Phiplus·VBplus)/Deltaplus为右边；只要求n,k>0，所需数值非零条件在形式变量上已证明。 |
| 138 | `P2.2.minor.Bplus` | pass / pass / pass / pass / pass | VBplus尾块选行k+i.val，即纸面k+1,…,k+n；k>0使首括号给对角1且其余折叠行都在其上，故det=1。 |
| 139 | `DEF.V.Bt` | pass / pass / pass / pass / pass | VBt逐行逐列定义为uB−t uBTilde，实际是(n+k)×n矩阵；caseFolding指定B评估与对应Delta。 |
| 140 | `P2.2.ratio.Bt` | pass / pass / pass / pass / pass | Bt的paper_prop_2_2入口以独立ExternalHL Weyl和为左边、det(PhiB·VBt)/DeltaB为右边；只要求n,k>0，所需数值非零条件在形式变量上已证明。 |
| 141 | `P2.2.minor.Bt` | pass / pass / pass / pass / pass | VBt尾块选行k+i.val，即纸面k+1,…,k+n；k>0使首括号给对角1且其余折叠行都在其上，故det=1。 |
| 142 | `P2.2.fold.C0` | pass / pass / pass / pass / pass | finiteBasicRow(t,k+1,r,z)=z^(−n−k)f_r(z)；C折叠的差恰为−PhiC·VC0，最终n个列负号与DeltaC中的(−1)^n对应。 |
| 143 | `P2.2.fold.BC` | pass / pass / pass / pass / pass | BC在同一行函数两侧分别乘1+τz与1+τz⁻¹，折叠负列为uC+τuCTilde，基参数在两处都为τ²。 |
| 144 | `P2.2.fold.Ct` | pass / pass / pass / pass / pass | finiteCtRow保留z^(−n−k)和Ct列的负t^r项，反演差为−PhiC·VCt。 |
| 145 | `P2.2.fold.B0` | pass / pass / pass / pass / pass | B行函数的移位参数k给z^(−n−k+1)，反演项另乘z，负列为uB。 |
| 146 | `P2.2.fold.Bt` | pass / pass / pass / pass / pass | Bt折叠两项分别乘1−tz与1−tz⁻¹且第二项带z，给uB−t uBTilde而不是简单相邻行核。 |
| 147 | `P2.2.fold.Bminus` | pass / pass / pass / pass / pass | Bminus行函数的指数−n+1−k及第三alternant的τ幂正确；B反演差给表中VBminus的负列。 |
| 148 | `P2.2.fold.Bplus.first` | pass / pass / pass / pass / pass | Bplus使用反演和，PhiPlus_VBplus_apply首列为Cfun_k；k>0避免中心特例另添倍数。 |
| 149 | `P2.2.fold.Bplus.rest` | pass / pass / pass / pass / pass | Bplus其余列的Cfun指标k+r−1和k+1−r，与t^(r−1)系数同时保留。 |
| 150 | `P2.2.triangular.leading` | pass / pass / pass / pass / pass | 七种V的第一括号[k+r]都直接在p=k+r取1；k≥1避免plus首括号落在中心1。 |
| 151 | `P2.2.triangular.lower` | pass / pass / pass / pass / pass | 第二括号的正段上界k+2−r<k+r；负段C为r−k−2，B为r−k−1，plus为r−k，也都严格小于k+r；tilde项再降低一格。 |
| 152 | `CONV.sections3to5` | pass / pass / pass / pass / pass | 第3–5节的实际仿射结果入口保留n,k>0；一般线性代数转移可对更多维数成立，不能反过来拿它延伸例外宽零公式。 |
| 153 | `DEF.Q0` | pass / pass / pass / pass / pass | firstCols取原矩阵列j.val，翻译为纸面1到n，不是从k开始的H。 |
| 154 | `DEF.index.J` | pass / pass / pass / pass / pass | tailRowsAfterN取行n+i.val，翻译为J=n+1,…,n+k。 |
| 155 | `DEF.H` | pass / pass / pass / pass / pass | lastRowsY取行k+i.val，翻译为H=k+1,…,k+n；与J的起点不同。 |
| 156 | `DEF.I` | pass / pass / pass / pass / pass | firstRowsZ取行i.val，正是I=1,…,k。 |
| 157 | `DEF.omega` | pass / pass / pass / pass / pass | omegaSign的自然数指数k(k+1)/2是1+…+k，恰为首k个行符号的乘积。 |
| 158 | `DEF.zeta` | pass / pass / pass / pass / pass | zetaSign明确为(−1)^(nk)乘omega，与最后k行n+r的符号积一致。 |
| 159 | `CONV.subset.order` | pass / pass / pass / pass / pass | 任意Q用orderEmbOfFin递增枚举，补集另用其递增嵌入；sign公式由这两个顺序固定。 |
| 160 | `CONV.minor.columns` | pass / pass / pass / pass / pass | X的n行固定，Q嵌入第二个submatrix参数，因此选择列，Cauchy–Binet的维数与此一致。 |
| 161 | `CONV.minor.rows` | pass / pass / pass / pass / pass | Y、U、Z的L行通过第一个submatrix参数选行；H,J,I的矩阵封装都遵循这一点。 |
| 162 | `T3.1.transfer` | pass / pass / pass / pass / pass | 转移定理实际量化任意Field且无需CharZero；只有两个核零式及四个指定minor非零，结论的(−1)^(nk)和分母U_J Z_I均保留，也不要求XY非奇异。 |
| 163 | `T3.1.rank.X` | pass / pass / pass / pass / pass | rank子论证由非零X_Q0使该n×n子矩阵rank=n，rank_submatrix≤rankX≤n，所以rankX=n；范围核定理的依赖确含rank_of_det_ne_zero和rank_submatrix_le。 |
| 164 | `T3.1.rank.U` | pass / pass / pass / pass / pass | 同理非零U_J给rankU≥k而U宽k给≤k，得到rankU=k，未以kernel结论作为前提。 |
| 165 | `T3.1.kernel` | pass / pass / pass / pass / pass | XU=0先给rangeU⊆kerX，rank-nullity使两者维数同为k，再用有限维子空间包含且同维推出相等。 |
| 166 | `T3.1.topforms` | pass / pass / pass / pass / pass | 两个顶形式在F^L/rangeU上定义：X诱导商同构给像形式，固定U列的det经任意线性截面下降；section_eq保证与截面无关，非零坐标minor使二者非零，n维顶外幂为一维所以成比例。 |
| 167 | `T3.1.epsilon` | pass / pass / pass / pass / pass | paperEpsilon使用Q的递增枚举q_r.val减r.val，零基平移相消；因有序q_r≥r，Nat减法无截断损失。 |
| 168 | `T3.1.complement.sign` | pass / pass / pass / pass / pass | 坐标扩展det按先U的k列后n坐标列展开；分块置换符号为(−1)^(nk)epsilon，所剩补集minor按递增行次序。 |
| 169 | `T3.1.minors.X` | pass / pass / pass / pass / pass | XU的清分母finset关系除非零U_J后给alpha=detX_Q0/detU_J，它与Q无关；不是为每个Q任意选择比例常数。 |
| 170 | `T3.1.minors.Y` | pass / pass / pass / pass / pass | YZ关系同样用固定H,I的比值给单一beta；Y选行的det与Yᵀ选列的det相等。 |
| 171 | `T3.1.CauchyBinet` | pass / pass / pass / pass / pass | 两组minor乘积的epsilon平方为1；Cauchy–Binet在补集上重索引给det(UᵀZ)，没有漏掉补集排序符号。 |
| 172 | `T3.1.epsilon.Q0` | pass / pass / pass / pass / pass | Q0递增元素q_r=r，所以epsilon指数是0。 |
| 173 | `T3.1.epsilon.H` | pass / pass / pass / pass / pass | H递增元素q_r=k+r，指数nk，因此epsilon(H)=(−1)^(nk)。 |
| 174 | `T3.1.alpha` | pass / pass / pass / pass / pass | XU标准互补关系在Q0和其尾补集J给固定alpha，U_J非零使除法合法。 |
| 175 | `T3.1.beta` | pass / pass / pass / pass / pass | YZ关系在H和补集I给beta=(−1)^(nk)detY_H/detZ_I，保留了H的epsilon。 |
| 176 | `T3.1.normalized` | pass / pass / pass / pass / pass | normalized_transfer先除Phi初始minor，再用V_H=1；符号不变，仍有D_J和C_I两个非零分母。实际P由已核过有限比值连接，未将其作为核前提。 |
| 177 | `L3.2.symmetry.Lambda` | pass / pass / pass / pass / pass | Lambda奇性由eDot在2n下反射，将两个整数下标交换；中点m=0两项相等。 |
| 178 | `L3.2.symmetry.h` | pass / pass / pass / pass / pass | h关于m↦1−m的反射把第二项回文成第一项，再交换加法顺序。 |
| 179 | `L3.2.symmetry.hplus` | pass / pass / pass / pass / pass | hPlus对应中心2−m，减2的下标恰给此反射而非1−m。 |
| 180 | `L3.2.palindrome.form.h` | pass / pass / pass / pass / pass | eDot( n+i+m−1 )回文成eDot( n−i−m+1 )；Derived.h_palindrome_form明确给全部整数m此等式。 |
| 181 | `L3.2.palindrome.form.hplus` | pass / pass / pass / pass / pass | hPlus的第二项回文后是n−i−m+2，保留中心移位2；Derived接口没有只覆盖正m。 |
| 182 | `L3.2.D.C` | pass / pass / pass / pass / pass | DC逐条目rowSign(p)·Lambda_i(p)，行号p.val+1，矩阵L×k，转置将i变成配对行。 |
| 183 | `L3.2.D.B` | pass / pass / pass / pass / pass | DB同一行符号乘h_i(p)，没有eDdot或额外系数。 |
| 184 | `L3.2.D.plus` | pass / pass / pass / pass / pass | DPlus也是同一行符号乘hPlus_i(p)，特别p=1是−hPlus_i(1)，不是−2hPlus_i(1)。 |
| 185 | `L3.2.kernel.C` | pass / pass / pass / pass / pass | PhiC_DC使用真实classicalCoefficients而非任意只具支撑的系数；生成函数在−x_a零并奇配对产生核零式。 |
| 186 | `L3.2.minor.C` | pass / pass / pass / pass / pass | DC的尾行r给(−1)^(n+r)eDot(i−r)，上三角对角eDot0=1，det符号积zeta。 |
| 187 | `L3.2.kernel.B` | pass / pass / pass / pass / pass | PhiB_DB用h关于1−m的对称和psi移位配对得到零，不是复用错误的C型反演。 |
| 188 | `L3.2.minor.B` | pass / pass / pass / pass / pass | DB尾块与DC相同，故det同为zeta而无2。 |
| 189 | `L3.2.kernel.plus` | pass / pass / pass / pass / pass | PhiPlus_DPlus的固定中心行使用常数首列1，生成函数配对后中心正好−hPlus(1)，核零成立。 |
| 190 | `L3.2.minor.plus` | pass / pass / pass / pass / pass | DPlus尾块首项是eDot0+eDot0=2，其余对角1；k>0给det2zeta，k=1也保留此2。 |
| 191 | `L3.2.generating.C` | pass / pass / pass / pass / pass | Lambda生成和只含有限多个整数m，变量z作为Laurent评估须非零；移位系数后为z^(−n)Edot(z)(z^i−z^(−i))。 |
| 192 | `L3.2.generating.vanish.C` | pass / pass / pass / pass / pass | Edot在−x_a的互反因子中有1−x_a·x_a⁻¹=0，unit确保Laurent幂合法，所以Lambda生成值零。 |
| 193 | `L3.2.generating.B` | pass / pass / pass / pass / pass | h生成式的第二幂是1−i；palindromic改写及整数移位给z^(−n)Edot(z)(z^i+z^(1−i))。 |
| 194 | `L3.2.generating.vanish.B` | pass / pass / pass / pass / pass | 同一Edot零因子使h的生成函数值零，没有要求h序列本身恒零。 |
| 195 | `L3.2.generating.plus` | pass / pass / pass / pass / pass | hPlus生成式的第二幂2−i，对应正中心移位2。 |
| 196 | `L3.2.generating.vanish.plus` | pass / pass / pass / pass / pass | Edot(−x_a)=0也使hPlus生成函数零；−x_a非零由unit成立。 |
| 197 | `L3.2.pair.C` | pass / pass / pass / pass / pass | 奇配对把m和−m合并为phi_m，m=0项因Lambda0=0消失，p>L由零延拓截去。 |
| 198 | `L3.2.pair.B` | pass / pass / pass / pass / pass | 以p≥1和1−p≤0划分全部整数，符号差给psi_p；不存在被双计的固定整数。 |
| 199 | `L3.2.pair.plus` | pass / pass / pass / pass / pass | 中心2配对的固定整数1单独留下−hPlus(1)；其余除以x_a后成为Cfun_(p−1)，所以DPlus首行不加倍。 |
| 200 | `L3.2.support.C` | pass / pass / pass / pass / pass | 对于任意整数m>n+k，n−i+m>2n因i≤k，另一下标更大，故Lambda两项均零；这里的m是延拓整数，不受矩阵行p≤L限制。 |
| 201 | `L3.2.support.B` | pass / pass / pass / pass / pass | h的第二下标至少比第一下标多2i−1≥1；m>L时两项越过2n。 |
| 202 | `L3.2.support.plus` | pass / pass / pass / pass / pass | hPlus第二与第一下标差2i−2≥0，m>L时同样双零，包括i=1的相等情形。 |
| 203 | `L3.2.lastblock.C` | pass / pass / pass / pass / pass | DC尾行m=n+r时第一系数回文为eDot(i−r)，另一系数指标2n+i+r>2n消失；符号(−1)^(n+r)。 |
| 204 | `L3.2.lastblock.B` | pass / pass / pass / pass / pass | DB尾行第二系数2n+i+r−1>2n，因为i,r≥1；留下同一eDot(i−r)。 |
| 205 | `L3.2.lastblock.plus` | pass / pass / pass / pass / pass | DPlus尾行第二系数2n+i+r−2回文为eDot(2−i−r)，故尾条目为两项和，r=i=1是唯一额外非零对角。 |
| 206 | `L3.2.triangular.C` | pass / pass / pass / pass / pass | i<r给eDot(i−r)=0；i=r给eDot0=1，因而DC尾块为上三角对角行符号。 |
| 207 | `L3.2.triangular.B` | pass / pass / pass / pass / pass | DB尾块同一公式给上三角与同一对角符号，不能从det=符号积反推条目，本审查按条目公式核算。 |
| 208 | `L3.2.triangular.plus` | pass / pass / pass / pass / pass | DPlus尾块的额外eDot(2−i−r)仅在i=r=1可非零，第一对角加倍，其余对角保持原行符号。 |
| 209 | `L3.3.fold.C` | pass / pass / pass / pass / pass | CC(b)只按整数p和−p作差，b没有有限支撑前提，矩阵本身因行数L有限。 |
| 210 | `L3.3.fold.B` | pass / pass / pass / pass / pass | CB(b)按(−1)^p乘b(p)+b(1−p)，两个反射项是和而非差。 |
| 211 | `L3.3.fold.plus.center` | pass / pass / pass / pass / pass | CPlus的p.val=0分支明确为−b(1)；没有由Gamma1=−2b1错误继承倍数。 |
| 212 | `L3.3.fold.plus.rest` | pass / pass / pass / pass / pass | p≥2才使用(−1)^p[b(p)+b(2−p)]，与中心特判在p=1不重叠。 |
| 213 | `L3.3.unfold.C` | pass / pass / pass / pass / pass | DCᵀCC配对保留(−1)^mLambda_i(m)b_j(m)，有限支撑来自Lambda，b任意。 |
| 214 | `L3.3.unfold.B` | pass / pass / pass / pass / pass | DBᵀCB的两个行符号相乘为1，展开为h_i(m)b_j(m)的整数有限和。 |
| 215 | `L3.3.unfold.plus` | pass / pass / pass / pass / pass | DPlusᵀCPlus也给无符号hPlus整数和，固定中心使用一次；定理b任意，没有偷加b有限支撑。 |
| 216 | `L3.3.center.once` | pass / pass / pass / pass / pass | p=1时DPlus=−hPlus(1)、CPlus=−b1，乘积正hPlus(1)b1，因此配对中心恰计一次。 |
| 217 | `AFFINE.row.support` | pass / pass / pass / pass / pass | K>0使ceil(A/K)≤y等价于A≤Ky；低于下界两指标>N，高于上界两指标<0。类型只要求δ≤2i，纸面δ∈{0,1,2},i≥1保证它，故没有额外前提。 |
| 218 | `AFFINE.row.support.edot` | pass / pass / pass / pass / pass | Lambda,h,hPlus全部由Edot整数系数构造所以N=2n；hHat使用Eddot所以必须N=2n+1，四核各自有限支撑定理均存在。 |
| 219 | `AFFINE.multilinearity` | pass / pass / pass / pass / pass | det_finsum_rows在各条目有限支撑下按每行选择同一个y_i展开；K≠0和四核支撑使具体应用满足前提，不将偶子格和误作单个det。 |
| 220 | `AFFINE.exponent.nonnegative` | pass / pass / pass / pass / pass | 各case专属非负性定理对所有Fin k列和整数y成立；通用Ay²−By以0≤B≤A为条件，纸面j≤k和K/2≥k−η使它满足。 |
| 221 | `AFFINE.B0.exponent.integral` | pass / pass / pass / pass / pass | B0_numerator_even保证分子可被2整除；exact与cast核对整数除法确等于原式，不靠向下取整近似。 |
| 222 | `AFFINE.tau.exponent` | pass / pass / pass / pass / pass | BC和Bminus的整数τ指数分别是(2k+1)y²−2jy和2ky²−(2j−1)y；这正是纸面t指数乘2，已分别证明非负。 |
| 223 | `AFFINE.polynomial` | pass / pass / pass / pass / pass | parameterJKPolynomial用自然数幂X^e且核为常多项式，有限支撑保障有限finsum；eval定理和非负指数把具体整数幂还原，反射步骤仍可在非零形式参数域中用负幂。 |
| 224 | `P4.1.K.C0` | pass / pass / pass / pass / pass | C0序列实际把步长设为2k+2，q参数唯一；配对右边也用同一步长。 |
| 225 | `P4.1.K.BC` | pass / pass / pass / pass / pass | BC序列实际步长2k+1且τ指数(2k+1)q²+2jq；Weyl对象基参数τ²与此相合。 |
| 226 | `P4.1.b.residue` | pass / pass / pass / pass / pass | residue_point_eq在K≠0时把整数finsum化成唯一q项；C0权重(k+1)q²+jq，BC则按τ约定倍指数。 |
| 227 | `P4.1.b.outside` | pass / pass / pass / pass / pass | 支撑外没有q满足m=j+Kq，每个if项都是0，residueSum_zero给零而不需收敛解释。 |
| 228 | `P4.1.c` | pass / pass / pass / pass / pass | cC0Seq、cBCSeq都按b(m)−b(−m)定义，并且CC在正p求同一表达式。 |
| 229 | `P4.1.quasiperiod` | pass / pass / pass / pass / pass | q↦q+1使bC0(m+K)权重增加m+k+1；BC的τ指数增加2m+2k+1，等于t^(m+K/2)的约定值。 |
| 230 | `P4.1.reflection.odd` | pass / pass / pass / pass / pass | 两种c的负m将b两项交换，直接得奇性，对支撑外也成立。 |
| 231 | `P4.1.reflection.affine` | pass / pass / pass / pass / pass | 由准周期分别移位两个b项，cC0使用t^(m−k−1)，cBC使用τ^(2m−2k−1)，各对应m−K/2。 |
| 232 | `P4.1.C0.firstcolumn` | pass / pass / pass / pass / pass | C0取m=k+1时反射到自身且系数1，c+c=0在特征零得c=0；形式t非零满足通用定理。 |
| 233 | `P4.1.C0.restcolumns` | pass / pass / pass / pass / pass | C0取m=k+r的反射指数r−1，反射点k+2−r；bracketC奇性保证其与有限列评估一致。 |
| 234 | `P4.1.C0.kernel` | pass / pass / pass / pass / pass | VC0_transpose_CC结论是真实矩阵积零，k>0与形式参数非零为纸面证明域内条件。 |
| 235 | `P4.1.BC.firstcolumn` | pass / pass / pass / pass / pass | BC的m=k+1反射指数τ^1，反射点k，故首列c(k+1)+τc(k)=0。 |
| 236 | `P4.1.BC.restcolumns` | pass / pass / pass / pass / pass | BC普通列由m=h和h−1两条反射分别乘1、τ；括号中的指数2h−K和2h−2−K确配成两组零。 |
| 237 | `P4.1.BC.kernel` | pass / pass / pass / pass / pass | VBC的tau平方有限列与bBC的tau幂序列实际进入同一矩阵核关系，未用C0序列替代。 |
| 238 | `P4.1.residues.disjoint` | pass / pass / pass / pass / pass | 对1≤p,j≤k有0<p+j≤2k<K，所以−p不可能同余j；正p仅p=j给q0，因而两剩余类分离。 |
| 239 | `P4.1.CI.entries` | pass / pass / pass / pass / pass | CC头块正项Kronecker delta，负项零，所以矩阵本身为单位阵而不只是det为1。 |
| 240 | `P4.1.CI.det` | pass / pass / pass / pass / pass | 单位头块的det1与DC尾块zeta、配对列符号omega在normalized_transfer中抵消。 |
| 241 | `P4.1.A` | pass / pass / pass / pass / pass | y=−q把b权重变成Ky²/2−jy；(−1)^(j−Ky)拆为列符号(−1)^j和仿射符号(−1)^(Ky)。 |
| 242 | `P4.1.pairing` | pass / pass / pass / pass / pass | 配对逐条目多一个只依赖列j的(−1)^j，故是右乘对角矩阵；不是按行左乘。 |
| 243 | `P4.1.sign.C0` | pass / pass / pass / pass / pass | C0的K=2k+2为偶数，整数Ky偶，zpow(−1)^(Ky)=1。 |
| 244 | `P4.1.det.C0` | pass / pass / pass / pass / pass | C0转移中D_J=zeta=(−1)^(nk)omega，C_I=1，配对det含omega，所有符号乘积1，给P=detA。 |
| 245 | `P4.1.C0.result` | pass / pass / pass / pass / pass | C0正宽最终入口与独立P的Weyl和连接，再用有限行多线性给(1.6)，没有把RedC0当作定义P。 |
| 246 | `P4.1.sign.BC` | pass / pass / pass / pass / pass | BC的K=2k+1为奇数，Ky与y同奇偶，留下(−1)^y。 |
| 247 | `P4.1.det.BC` | pass / pass / pass / pass / pass | BC的D_J、C_I和列符号与C0相同，转移归一化仍恰为1。 |
| 248 | `P4.1.BC.result` | pass / pass / pass / pass / pass | BC最终paper入口用τ、不是独立t和τ，并在τ²的Weyl和与正确(1.8)权重之间给等式。 |
| 249 | `P4.2.K.B0` | pass / pass / pass / pass / pass | B0序列步长2k+1，带(−1)^y且分子偶除2；配对使用同一步长和h核。 |
| 250 | `P4.2.K.Bminus` | pass / pass / pass / pass / pass | Bminus步长2k，权重无符号且以τ为基；ExternalHL内部对称化参数τ²。 |
| 251 | `P4.2.b.residue` | pass / pass / pass / pass / pass | 支撑条件m=j−Ky且K>0使y唯一；B0/Bminus分别实现K奇/偶的(−1)^(Ky)简化。 |
| 252 | `P4.2.b.outside` | pass / pass / pass / pass / pass | 所有if项在m不同余j时皆零，整数finsum只表示一个剩余类而非额外求和对象。 |
| 253 | `P4.2.gamma` | pass / pass / pass / pass / pass | gammaB0和gammaBminus都是(−1)^m[b(m)+b(1−m)]；CB正行恰为该gamma值。 |
| 254 | `P4.2.quasiperiod` | pass / pass / pass / pass / pass | y↦y−1给B0的−t^(m+k)，给Bminus的τ^(2m+2k−1)；分别对应(−1)^K t^(m+(K−1)/2)。 |
| 255 | `P4.2.reflection.finite` | pass / pass / pass / pass / pass | 1−m与m奇偶相反，而两个b项交换，故gamma(1−m)=−gamma(m)。 |
| 256 | `P4.2.reflection.affine` | pass / pass / pass / pass / pass | 仿射反射指数B0为m−k−1、Bminus的τ指数2m−2k−1，反射中心分别K+1；二者都保留前导负号。 |
| 257 | `P4.2.reflection.factor` | pass / pass / pass / pass / pass | 把b(K+1−m)视为b(1−m)前移K，b(m−K)视为b(m)后移K，两者因子均为(−1)^K t^((K+1)/2−m)；center_fold_affine的互逆因子条件确由准周期满足。 |
| 258 | `P4.2.B0.firstcolumn` | pass / pass / pass / pass / pass | B0在m=k+1为反射固定点，gamma=−gamma，特征零消除2得零。 |
| 259 | `P4.2.B0.restcolumns` | pass / pass / pass / pass / pass | B0普通列取m=k+r得到r−1的t幂及k+2−r反射点，括号B有限反射保证评估一致。 |
| 260 | `P4.2.Bminus.columns` | pass / pass / pass / pass / pass | Bminus取m=k+r给τ^(2r−1)，反射点k+1−r，恰为VBminus两括号。 |
| 261 | `P4.2.kernel.B0` | pass / pass / pass / pass / pass | VB0转置与CB(bB0)相乘为零的定理保留真实矩阵大小，未假设目标P恒等式。 |
| 262 | `P4.2.kernel.Bminus` | pass / pass / pass / pass / pass | VBminus核关系用bBminus与τ平方的V，参数未混淆。 |
| 263 | `P4.2.CI.direct` | pass / pass / pass / pass / pass | 正p的m−j绝对值<K，residueSum_minus_small只留y0，所以b_j(p)=δ_pj。 |
| 264 | `P4.2.CI.reflected` | pass / pass / pass / pass / pass | 对反射m=1−p，1≤j+p−1≤2k−1<K，所以没有整倍K，b_j(1−p)=0，k1仍有效。 |
| 265 | `P4.2.CI.entries` | pass / pass / pass / pass / pass | CB头块由正delta加反射零形成对角(−1)^p；通用CB_head_of_small虽只输出det，本审查按CB定义核算整个块。 |
| 266 | `P4.2.CI.det` | pass / pass / pass / pass / pass | 首k个(−1)^p的积是omega；B0和Bminus的head定理分别证实det值。 |
| 267 | `P4.2.A` | pass / pass / pass / pass / pass | DB_CB的配对式正是h_i(j−Ky)乘该剩余类权重之和，B0整数除2已证恰整。 |
| 268 | `P4.2.pairing` | pass / pass / pass / pass / pass | DB与CB符号在p配对时平方消失，所以最终A没有额外列对角符号。 |
| 269 | `P4.2.sign.B0` | pass / pass / pass / pass / pass | B0步长奇数，因此(−1)^(Ky)留下(−1)^y。 |
| 270 | `P4.2.det.B0` | pass / pass / pass / pass / pass | ordinary_B_transfer用D_J=zeta、C_I=omega和V_H=1，使归一化总系数1；B0给完整h行和det。 |
| 271 | `P4.2.B0.result` | pass / pass / pass / pass / pass | B0的正宽P入口连接外部Weyl和，最终(1.3)周期和指数均与全宽入口一致。 |
| 272 | `P4.2.sign.Bminus` | pass / pass / pass / pass / pass | Bminus步长偶数，(−1)^(Ky)=1，没有残余交替符号。 |
| 273 | `P4.2.det.Bminus` | pass / pass / pass / pass / pass | Bminus与B0同D_B和omega头块，故P=detA，τ指数并未被再除2。 |
| 274 | `P4.2.Bminus.result` | pass / pass / pass / pass / pass | Bminus最终P入口只要求n,k>0，形式τ下消去Admissible条件，得到(1.4)。 |
| 275 | `P5.1.K` | pass / pass / pass / pass / pass | Ct使用步长2k；bCt的finsum等式条件是m=j+2kq，且不是Bplus的反向式权重。 |
| 276 | `P5.1.b.residue` | pass / pass / pass / pass / pass | Ct每个支撑项的符号(−1)^q和指数kq²+jq都直接出现在定义，K>0使q唯一。 |
| 277 | `P5.1.b.outside` | pass / pass / pass / pass / pass | Ct支撑外所有if项零，与有穷性无关的剩余类约束正确。 |
| 278 | `P5.1.c` | pass / pass / pass / pass / pass | cCt定义为bCt(m)−bCt(−m)，因此CC的正行正是此c。 |
| 279 | `P5.1.quasiperiod` | pass / pass / pass / pass / pass | Ct将q移一格时符号变号，幂增加m+k，故准周期−t^(m+k)；形式t非零允许反向移位。 |
| 280 | `P5.1.reflection.odd` | pass / pass / pass / pass / pass | cCt负m直接交换两项，始终为奇函数。 |
| 281 | `P5.1.reflection.affine` | pass / pass / pass / pass / pass | Ct两次准周期与奇性给正系数反射c(m)=t^(m−k)c(2k−m)，与C0的负型不同。 |
| 282 | `P5.1.column` | pass / pass / pass / pass / pass | 在m=k+r时反射点k−r、系数t^r，和VCt中减号正好相消。 |
| 283 | `P5.1.kernel` | pass / pass / pass / pass / pass | VCt_transpose_CC_all甚至含t0；正宽纸面形式域情形由同一真实核等式覆盖。 |
| 284 | `P5.1.fixed.residue` | pass / pass / pass / pass / pass | 末列j=k的两个剩余类重合；反射对应q↦−q−1，符号差使b(m)−b(−m)加成2而非抵消，指数kq(q+1)。 |
| 285 | `P5.1.nonfixed.residue` | pass / pass / pass / pass / pass | j<k时2j不是2k的倍数，正负类不重合；k1时无此列，但末列加倍仍存在。 |
| 286 | `P5.1.CI.entries` | pass / pass / pass / pass / pass | cCt_head_entry给整个头块：普通列对角1、最后列对角2，其他0。 |
| 287 | `P5.1.CI.det` | pass / pass / pass / pass / pass | 头块det是末列因子2，要求k>0；k1时矩阵[2]确成立。 |
| 288 | `P5.1.a` | pass / pass / pass / pass / pass | a的weightCt乘Lambda定义与CtParityInterface中局部a一致，行位移j−2ky且没有交替符号。 |
| 289 | `P5.1.Aplus` | pass / pass / pass / pass / pass | Aplus对a作无符号整数finsum；该定义与末列零式使用的是同一a。 |
| 290 | `P5.1.Aminus` | pass / pass / pass / pass / pass | Aminus每项额外(−1)^y，DC_CC_Ct_pairing中除列符号后的正是它。 |
| 291 | `P5.1.pairing` | pass / pass / pass / pass / pass | Ct的配对列符号是(−1)^j，故矩阵是Aminus右乘符号对角。 |
| 292 | `P5.1.halfdet` | pass / pass / pass / pass / pass | Ct转移时D_J=zeta、C_I=2，再抵消配对omega，剩下1/2乘detAminus。 |
| 293 | `P5.1.parity.projector` | pass / pass / pass / pass / pass | JKEven_projector把总和Even的示性函数化为(1+(−1)^(sum y))/2；char0保证2可逆，未用逐坐标偶性。 |
| 294 | `P5.1.parity.det` | pass / pass / pass / pass / pass | 行符号(−1)^(y_i)从det每行提出，乘积即总和符号，有限多线性因此给两行和det之平均。 |
| 295 | `P5.1.lastcolumn.exponent` | pass / pass / pass / pass / pass | 末列j=k时k(1−y)²−k(1−y)=ky²−ky，直接整数恒等式，无需对t取根。 |
| 296 | `P5.1.lastcolumn.argument` | pass / pass / pass / pass / pass | k−2k(1−y)=−(k−2ky)，恰将Lambda参数反号。 |
| 297 | `P5.1.lastcolumn.antisymmetry` | pass / pass / pass / pass / pass | 末列权重不变而Lambda奇，所以a_i,k(1−y)=−a_i,k(y)；没有固定整数y=1/2。 |
| 298 | `P5.1.lastcolumn.zero` | pass / pass / pass / pass / pass | 有限支撑的y↦1−y双射使末列和等于其负，在char0为0；k>0确保这是一条实际末列，因此detAplus=0。 |
| 299 | `P5.1.result` | pass / pass / pass / pass / pass | Ct最终P等式用偶总和子格，与有符号全格半det的中间式区分；无符号全格det为0不被错误当作目标。 |
| 300 | `L5.2.b.residue` | pass / pass / pass / pass / pass | bBplus用m=j−2ky的唯一y项，权重是(−1)^y t^(ky²−(j−1)y)，Spec的residueSequence商条件等价。 |
| 301 | `L5.2.b.outside` | pass / pass / pass / pass / pass | 非该剩余类时bBplus定义的每个if分支为0，故支撑限制成立。 |
| 302 | `L5.2.Gamma` | pass / pass / pass / pass / pass | Gamma用(−1)^m[b(m)+b(2−m)]，其m=1值确是−2b1。 |
| 303 | `L5.2.quasiperiod` | pass / pass / pass / pass / pass | lemma52准周期对所有整数m有效，只有t非零的分式域条件；纸面paper入口消去了这个形式参数已满足的条件。 |
| 304 | `L5.2.symmetry` | pass / pass / pass / pass / pass | 2−m与m同奇偶，两b项交换，所以Gamma中心对称，既无符号变化也无遗漏中心。 |
| 305 | `L5.2.reflection` | pass / pass / pass / pass / pass | 反射点2k+2−m与m同奇偶，移位关系给前导−t^(m−k−1)；负幂只用于形式域。 |
| 306 | `L5.2.fixedcenter` | pass / pass / pass / pass / pass | 反射固定点m=k+1指数0，所以Gamma=−Gamma，char0给Gamma=0。 |
| 307 | `L5.2.shift.reflected` | pass / pass / pass / pass / pass | 将准周期取输入2−m，便得b(2k+2−m)=−t^(k+1−m)b(2−m)，全体整数m不只支撑内。 |
| 308 | `L5.2.shift.backward` | pass / pass / pass / pass / pass | 对b(m)=−t^(m−k−1)b(m−2k)反向求解，得到b(m−2k)=−t^(k+1−m)b(m)，形式t可逆。 |
| 309 | `P5.3.C` | pass / pass / pass / pass / pass | CPlus(bBplus)使用(5.1)序列，首行规范化−b1，其他行是Gamma正p值。 |
| 310 | `P5.3.center.eval` | pass / pass / pass / pass / pass | 首行与bracket[1]+=2e1相乘为−2b1，正好Gamma1；未把首行误写成Gamma1。 |
| 311 | `P5.3.bracket.eval` | pass / pass / pass / pass / pass | bracketPlus_CPlus_Bplus在完整允许范围含中心m1，其他反射用Gamma(2−m)=Gamma(m)，因此每个有限列评估同一Gamma。 |
| 312 | `P5.3.firstcolumn` | pass / pass / pass / pass / pass | Bplus首列[k+1]+由bracket求值为Gamma(k+1)=0，不依赖P结论。 |
| 313 | `P5.3.restcolumns` | pass / pass / pass / pass / pass | Bplus普通列评估为Gamma(k+r)+t^(r−1)Gamma(k+2−r)，两项由lemma52反射相消。 |
| 314 | `P5.3.kernel` | pass / pass / pass / pass / pass | VBplus转置核等式使用真实CPlus标准化中心和k>0，未将Gamma中心重复。 |
| 315 | `P5.3.CI.center` | pass / pass / pass / pass / pass | bBplus(1)的差j−1在0,…,k−1，只有j1为0给y0，其他无2k倍数。 |
| 316 | `P5.3.CI.direct` | pass / pass / pass / pass / pass | 2≤p≤k的正项差j−p绝对值<2k，只有p=j给y0，因此delta。 |
| 317 | `P5.3.CI.reflected` | pass / pass / pass / pass / pass | 反射m=2−p要求2ky=j+p−2，落在1,…,2k−2内，非2k倍；k1此范围为空。 |
| 318 | `P5.3.CI.entries` | pass / pass / pass / pass / pass | 头块首行−δ_j1，其他行(−1)^pδ_pj，正好整块符号对角。 |
| 319 | `P5.3.CI.det` | pass / pass / pass / pass / pass | 头块det是omega，没有倍数2；该2从另一互补块产生。 |
| 320 | `P5.3.doubling.location` | pass / pass / pass / pass / pass | DPlus尾块首对角双eDot0给2zeta，而CPlus头det只是omega；两处逐条目计算定位倍数2。 |
| 321 | `P5.3.A` | pass / pass / pass / pass / pass | DPlus_CPlus_Bplus_pairing的整数y行和用hPlus核与(5.1)权重，周期2k正确。 |
| 322 | `P5.3.pairing` | pass / pass / pass / pass / pass | 配对没有额外列符号，矩阵本身等于A_Bplus。 |
| 323 | `P5.3.pairing.center.once` | pass / pass / pass / pass / pass | 展开中心p1的两负号相乘后只剩hPlus_i(1)b_j(1)；D_J的2不能再加在此。 |
| 324 | `P5.3.halfdet` | pass / pass / pass / pass / pass | 用D_J=2zeta和C_I=omega归一化得到1/2 detA_Bplus；没有额外正交型alternant常数。 |
| 325 | `P5.3.result` | pass / pass / pass / pass / pass | 正宽paper_prop_5_3保持k>0，连接真Weyl对象与(1.5)；宽零由单独命题处理。 |
| 326 | `Bt.hhat.sum` | pass / pass / pass / pass / pass | Eddot_r=Edot_r+Edot_(r−1)展开hHat四项，按下标分组恰为h(m)+h(m−1)，对全部整数m有效。 |
| 327 | `L5.4.a` | pass / pass / pass / pass / pass | aBt和独立adjacentSequence都将b(m)与b(m+1)相加；移位是向前一格。 |
| 328 | `L5.4.c` | pass / pass / pass / pass / pass | cBt对a(m)+a(1−m)乘(−1)^m，保留B型反射中心1而非Gamma的2。 |
| 329 | `L5.4.gamma` | pass / pass / pass / pass / pass | gammaBt定义c(m)−t c(m−1)，向后移位和负号正确。 |
| 330 | `L5.4.a.support` | pass / pass / pass / pass / pass | b(m)支撑在j类，b(m+1)支撑在j−1类，Derived支持包含定理用整数可除条件表达，k1时两类确覆盖模2所有类。 |
| 331 | `L5.4.c.symmetry` | pass / pass / pass / pass / pass | c(1−m)的括号两项交换，符号因奇偶相反改变为负。 |
| 332 | `L5.4.5.3` | pass / pass / pass / pass / pass | 展开a后，Gamma(m)−Gamma(m+1)的两组(−1)幂一正一负，化为c(m)；编译等式对全部m无t非零要求。 |
| 333 | `L5.4.5.4` | pass / pass / pass / pass / pass | 把c(m)−t c(m−1)代入上一等式，Gamma(m)系数1+t，前向系数−1，后向系数−t。 |
| 334 | `L5.4.5.5` | pass / pass / pass / pass / pass | Gamma对m及m±1反射时，t幂分别偏±1，抽出−t^(m−k−1)后两个移位系数交换位置，正好gamma反射。 |
| 335 | `L5.4.fixedcenter` | pass / pass / pass / pass / pass | 固定点m=k+1反射给gamma=−gamma，形式char0使其为0；paper入口覆盖所有j。 |
| 336 | `L5.4.reflection.expanded` | pass / pass / pass / pass / pass | T−(m+1)=T−m−1而T−(m−1)=T−m+1，额外t与1分别落在这两项；展开括号与gamma(T−m)的真实定义一致。 |
| 337 | `P5.5.C` | pass / pass / pass / pass / pass | CB(aBt)的正行定义与cBt(p)相同，CB_Bt_apply直接给条目等式。 |
| 338 | `P5.5.firstcolumn` | pass / pass / pass / pass / pass | VBt首列的bracketB评估给c(k+1)−tc(k)=gamma(k+1)=0，符合uB−tutildeB。 |
| 339 | `P5.5.restcolumns` | pass / pass / pass / pass / pass | 普通列四项重组为gamma(k+r)+t^(r−1)gamma(k+2−r)，由反射相消；没有把c本身当gamma。 |
| 340 | `P5.5.kernel` | pass / pass / pass / pass / pass | VBt_transpose_CB将上述每列零整合为矩阵核零；所用仍是DB型反射a序列。 |
| 341 | `P5.5.CI.direct` | pass / pass / pass / pass / pass | 1≤p,j≤k时b(p)只p=j给1，b(p+1)只p+1=j给1，皆y0，故a(p)=δ_pj+δ_p,j−1。 |
| 342 | `P5.5.CI.reflected` | pass / pass / pass / pass / pass | a(1−p)的两个同余条件为2ky=j+p−1或j+p−2；第一严格介于0与2k，第二仅p=j1可为0，所以反射只在左上角多1。 |
| 343 | `P5.5.CI.entries` | pass / pass / pass / pass / pass | CB_Bt_head_entry明确给(−1)^p乘三个Kronecker条件，包含左上角重叠项，非仅普通双对角。 |
| 344 | `P5.5.CI.bidiagonal` | pass / pass / pass / pass / pass | p+1=j只在上邻对角非零，额外角项使第一对角−2，余对角依p符号交替，k1为[−2]。 |
| 345 | `P5.5.CI.det` | pass / pass / pass / pass / pass | 上双对角det为对角积2omega；k1时−2=2·(−1)，边界成立。 |
| 346 | `P5.5.DJ.undoubled` | pass / pass / pass / pass / pass | Bt仍用D_B，其尾det=zeta；C_I才为2omega，倍数2的来源不同于Bplus。 |
| 347 | `P5.5.pairing.m` | pass / pass / pass / pass / pass | lemma33对b=aBt展开给sum_m h(m)[b(m)+b(m+1)]；a不需要自身有限支撑。 |
| 348 | `P5.5.pairing.y` | pass / pass / pass / pass / pass | finsum_adjacent_pairing通过m↦m−1重索引第二项，给(h(m)+h(m−1))b(m)，再用唯一剩余类y展开。 |
| 349 | `P5.5.A` | pass / pass / pass / pass / pass | 相邻h之和已证为hHat，故Bt的A条目是(5.1)权重乘hHat(j−2ky)。 |
| 350 | `P5.5.pairing.hhat` | pass / pass / pass / pass / pass | DB_CB_Bt_pairing直接给每个i,j等于上述A条目，因而矩阵相等。 |
| 351 | `P5.5.halfdet` | pass / pass / pass / pass / pass | D_J=zeta,C_I=2omega带入转移后符号抵消、留下1/2；不是把hHat定义时插入半系数。 |
| 352 | `P5.5.result` | pass / pass / pass / pass / pass | 正宽Bt paper入口保留n,k>0，真Weyl和与(1.9)一致，宽零另论。 |
| 353 | `P6.1.C0` | pass / pass / pass / pass / pass | C0宽度固定0的paper_prop_6_1仅有秩条件，独立Weyl和的边界归一化是1；有限宽零列变换det等于它，先在形式域约去后得到1。 |
| 354 | `P6.1.Ct` | pass / pass / pass / pass / pass | Ct宽度固定0的paper_prop_6_1仅有秩条件，独立Weyl和的边界归一化是∏_{r=1}^n(1+t^r)；有限宽零列变换det等于它，先在形式域约去后得到1。 |
| 355 | `P6.1.BC` | pass / pass / pass / pass / pass | BC宽度固定0的paper_prop_6_1仅有秩条件，独立Weyl和的边界归一化是1；有限宽零列变换det等于它，先在形式域约去后得到1。 |
| 356 | `P6.1.B0` | pass / pass / pass / pass / pass | B0宽度固定0的paper_prop_6_1仅有秩条件，独立Weyl和的边界归一化是1；有限宽零列变换det等于它，先在形式域约去后得到1。 |
| 357 | `P6.1.Bminus` | pass / pass / pass / pass / pass | Bminus宽度固定0的paper_prop_6_1仅有秩条件，独立Weyl和的边界归一化是∏_{r=1}^n(1−τ^(2r−1))；有限宽零列变换det等于它，先在形式域约去后得到1。 |
| 358 | `P6.1.Bplus` | pass / pass / pass / pass / pass | Bplus宽度固定0的paper_prop_6_1仅有秩条件，独立Weyl和的边界归一化是∏_{r=1}^n(1+t^(r−1))；有限宽零列变换det等于它，先在形式域约去后得到1。 |
| 359 | `P6.1.Bt` | pass / pass / pass / pass / pass | Bt宽度固定0的paper_prop_6_1仅有秩条件，独立Weyl和的边界归一化是∏_{r=1}^n(1+t^r)；有限宽零列变换det等于它，先在形式域约去后得到1。 |
| 360 | `P6.1.finite.ratio` | pass / pass / pass / pass / pass | 七个finite_*_ratio_all_width对任意k成立且左端为未除nu的Red对象；k0时由Weyl反演归约得nu(0)P=该有限比值，不需D,C转移或V_H=1。 |
| 361 | `P6.1.triangular` | pass / pass / pass / pass / pass | 宽零每个V是方阵：C0/B0普通反射项只落到更小行，Ct/Bminus反射到同一行改变对角，BC和Bt混合只增加更小行；Bplus中心单独处理，均上三角。 |
| 362 | `P6.1.diagonal.C0` | pass / pass / pass / pass / pass | VC0宽零的r.val=0为e1，余列e_r与较低e_(r−2)组合，所以对角1。 |
| 363 | `P6.1.product.C0` | pass / pass / pass / pass / pass | C0上三角对角积1，与宽零nu_C0=1完全抵消。 |
| 364 | `P6.1.diagonal.BC` | pass / pass / pass / pass / pass | BC的tau uCTilde在宽零对角上为0：tilde的折叠行至多r−1；uC对角1，所以仍为1。 |
| 365 | `P6.1.product.BC` | pass / pass / pass / pass / pass | BC宽零上三角det1，不因rho中的tau项引入边界归一化。 |
| 366 | `P6.1.diagonal.B0` | pass / pass / pass / pass / pass | B0宽零普通列反射到r−1，首列e1；对角均1。 |
| 367 | `P6.1.product.B0` | pass / pass / pass / pass / pass | B0的对角积1，与其常nu=1相符。 |
| 368 | `P6.1.diagonal.Ct` | pass / pass / pass / pass / pass | Ct的[k+r]−t^r[k−r]在k0时为e_r+t^r e_r，因此对角1+t^r。 |
| 369 | `P6.1.product.Ct` | pass / pass / pass / pass / pass | Ct对角积∏_(r=1)^n(1+t^r)=(-t;t)_n，对应nuCt的k0分支。 |
| 370 | `P6.1.diagonal.Bt` | pass / pass / pass / pass / pass | Bt宽零首列(1+t)e1；其他列的e_r系数1+t^r，其余只在e_(r−1)，故相同对角。 |
| 371 | `P6.1.product.Bt` | pass / pass / pass / pass / pass | Bt乘积仍是(-t;t)_n，真实对象用nuCt而非nuBplus。 |
| 372 | `P6.1.diagonal.Bminus` | pass / pass / pass / pass / pass | Bminus宽零第二bracket[1−r]B=−e_r，故对角1−τ^(2r−1)，符号为减。 |
| 373 | `P6.1.product.Bminus` | pass / pass / pass / pass / pass | 这些奇数幂因子的积是(τ;τ²)_n，恰为nuBminus0。 |
| 374 | `P6.1.diagonal.Bplus` | pass / pass / pass / pass / pass | Bplus宽零r1为2e1；r≥2的反射bracket[2−r]+=e_r，故对角1+t^(r−1)，统一首值2。 |
| 375 | `P6.1.product.Bplus` | pass / pass / pass / pass / pass | Bplus乘积∏_(r=1)^n(1+t^(r−1))=(-1;t)_n，首因子2不可删。 |
| 376 | `P6.1.Bt.firstcolumn` | pass / pass / pass / pass / pass | widthZero_Bt_firstcolumn实际计算PhiB·VBt首列=(1+t)psi1，而不是孤立原始bracket。 |
| 377 | `P6.1.Bt.restcolumns` | pass / pass / pass / pass / pass | 其普通列等式保留(1+t^r)psi_r−(t+t^(r−1))psi_(r−1)，零基换算在完整type中正确。 |
| 378 | `P6.1.BC.firstcolumn` | pass / pass / pass / pass / pass | BC宽零首列uC1+tau utildeC1=e1+tau·0，评估为phi1。 |
| 379 | `P6.1.BC.restcolumns` | pass / pass / pass / pass / pass | BC普通列评估为phi_r+(τ−τ^(2r−1))phi_(r−1)−τ^(2r−2)phi_(r−2)；r2时phi0=0，未引入越界行。 |
| 380 | `P6.1.Bplus.center` | pass / pass / pass / pass / pass | Bplus首列PhiPlus·2e1=2=Cfun0，相对chi1=1对角就是2；这也是nuBplus0的第一因子。 |
| 381 | `P6.1.extend.B0` | pass / pass / pass / pass / pass | (1.3)在k0的JK是1，Weyl宽零值1，paper_theorem_A_1_3的k任意Nat确包含该端点。 |
| 382 | `P6.1.extend.Bminus` | pass / pass / pass / pass / pass | (1.4)虽K=0，但Fin0无权重条目，JK_zero允许任意K，宽零Bminus归一化值1。 |
| 383 | `P6.1.extend.C0` | pass / pass / pass / pass / pass | (1.6)宽零K2，空矩阵det和空向量和均1，对应C0值1。 |
| 384 | `P6.1.extend.Ct` | pass / pass / pass / pass / pass | (1.7)宽零K0，唯一空向量总和0为偶，JKEven_zero给1并与Ct宽零相等。 |
| 385 | `P6.1.extend.BC` | pass / pass / pass / pass / pass | (1.8)宽零K1，空det=1，BC宽零对象也是1；五式延伸不包括两个半det式。 |
| 386 | `CONV.cancel.before.specialize` | pass / pass / pass / pass / pass | 所有归一化对象先在FractionRing中解释，宽零结果是常数1，故按原文消去后特化时即使数值nu为0也取1。通用ExternalHL在数值奇点的总除法值不被声称为该延拓值；正宽参数零由parameterWeylPolynomial和非零点多项式恒等引出。 |
| 387 | `C6.2.6.1` | pass / pass / pass / pass / pass | (6.1)的左det秩n、列phi_(k+r)，分母DeltaC；右det宽k、条目Lambda_i(j)，展开下标为原式两个Edot项。 |
| 388 | `C6.2.6.2.h` | pass / pass / pass / pass / pass | (6.2)第一等式左边用psi_(k+r)/DeltaB，右边h_i(j)，没有外部半因子。 |
| 389 | `C6.2.6.2.hhat` | pass / pass / pass / pass / pass | (6.2)第二等式同一左比值等于2⁻¹det hHat_i(j)，Eddot核与1/2同时保留。 |
| 390 | `C6.2.6.3` | pass / pass / pass / pass / pass | (6.3)左列Cfun_(k+r−1)、分母DeltaPlus，右是2⁻¹det hPlus_i(j)；正宽保证左首列不是Cfun0的特殊情形。 |
| 391 | `C6.2.columns.C0` | pass / pass / pass / pass / pass | VC0(0)的首列本来单括号，其余t^(r−1)在r≥2为严格正幂，因此整矩阵变为选取行k+r的classicalV。 |
| 392 | `C6.2.specialization.C0` | pass / pass / pass / pass / pass | C0零参数paper入口左边是真P的weylSum在0，右边有限C比值；独立ZeroSpecialization通过caseC0和symbolicX给同一对象。 |
| 393 | `C6.2.columns.Ct` | pass / pass / pass / pass / pass | VCt的所有t^r指数r≥1，所以零参数时只剩[k+r]C。 |
| 394 | `C6.2.specialization.Ct` | pass / pass / pass / pass / pass | Ct在零参数的有限比值是辛C型，而非把仿射每个非零shift都删掉；独立Ct零参数接口也直接指向该左比值。 |
| 395 | `C6.2.columns.BC` | pass / pass / pass / pass / pass | VBC(0)使τ项整体为0且τ²=0，uC普通列只剩首括号；维数和classicalV相同。 |
| 396 | `C6.2.specialization.BC` | pass / pass / pass / pass / pass | BC零参数入口同时将平方根参数τ设0，Weyl基参数也为0，得到C型比值，且没有附加1/2。 |
| 397 | `C6.2.columns.B0` | pass / pass / pass / pass / pass | VB0(0)首列单括号，普通列严格正t^(r−1)项消失，得[k+r]B。 |
| 398 | `C6.2.specialization.B0` | pass / pass / pass / pass / pass | B0零参数Weyl对象等于B型有限比值，独立caseFolding取B而非plus。 |
| 399 | `C6.2.columns.Bminus` | pass / pass / pass / pass / pass | VBminus的tau幂2r−1始终正数，tau0时所有第二括号消失。 |
| 400 | `C6.2.specialization.Bminus` | pass / pass / pass / pass / pass | Bminus零参数入口τ0、基参数τ²0，左边是B Weyl和，右psi_(k+r)/DeltaB。 |
| 401 | `C6.2.columns.Bt` | pass / pass / pass / pass / pass | VBt(0)=uB(0)−0·utildeB(0)，故剩[k+r]B。 |
| 402 | `C6.2.specialization.Bt` | pass / pass / pass / pass / pass | Bt零参数边界t也为0，所以Weyl对象与B0一致，右边为无外部半因子的B有限比值。 |
| 403 | `C6.2.columns.Bplus` | pass / pass / pass / pass / pass | VBplus_zero额外保留k>0，使[k+r]+处在普通正行范围；k0首列仍为2e1，故不能无限制用此化简。 |
| 404 | `C6.2.specialization.Bplus` | pass / pass / pass / pass / pass | Bplus零参数仍是固定边界1的Bplus标签，有限比值cosine/DeltaPlus没有再加1/2；显示式(6.3)的右det才有1/2。 |
| 405 | `C6.2.nonzero.shift.C0` | pass / pass / pass / pass / pass | C0指数对y≠0严格正，weight_zero和JK_of_zero_shifts把0参数JK还原只留y0的Lambda det。 |
| 406 | `C6.2.nonzero.shift.B0` | pass / pass / pass / pass / pass | B0指数偶除2的正性已单独证明，不能仅用分子非负；weight_zero据此删去每个非零shift。 |
| 407 | `C6.2.nonzero.shift.Bplus` | pass / pass / pass / pass / pass | Bplus的B= j−1≤k−1<A=k，所以y≠0时Ay²−By严格正，权重在0消失。 |
| 408 | `C6.2.nonzero.shift.Bt` | pass / pass / pass / pass / pass | Bt与Bplus的参数指数相同，hHat换核不改变零参数删shift的合法性。 |
| 409 | `C6.2.Ct.exception` | pass / pass / pass / pass / pass | Ct的指数零当且仅当j=k,y1（对非零y），weight_exception_one实际为0^0=1；因此此项必须保留，未错误断言所有非零shift消失。 |
| 410 | `C6.2.Ct.route` | pass / pass / pass / pass / pass | Ct_even_sum_zero_parity保留even投影与半有符号JK，parity_bridge把它等于RedC0(0)，最终via_parity连接真实Ct零参数有限比值。 |
| 411 | `COEFF.endpoints` | pass / pass / pass / pass / pass | 真实classicalCoefficients的Edot常数是1，回文给最高系数1；Eddot常数和最高系数同理，Derived的四项合取完整覆盖端点。 |
| 412 | `KERNEL.Lambda.center` | pass / pass / pass / pass / pass | Lambda0由回文eDot_(n−i)=eDot_(n+i)相减，定理不需要2可逆。 |
| 413 | `L3.3.pairing.C` | pass / pass / pass / pass / pass | unfold_odd专门要求f0=0和奇性；对有符号Lambda仍奇，配对正负整数后得到DCᵀCC，零中心不会重复。 |
| 414 | `L3.3.pairing.B` | pass / pass / pass / pass / pass | unfold_center_one用p≥1和1−p≤0的不交分割，故每个整数只出现一次，不要求b本身有限支撑。 |
| 415 | `L5.2.shift.proof` | pass / pass / pass / pass / pass | residueSum_minus_quasiperiod明确以w(y−1)=a(j−Ky)w(y)为移位前提，(5.1)权重恰满足；Gamma中心对称直接展开定义。 |
| 416 | `L5.2.reflection.proof` | pass / pass / pass / pass / pass | center_fold_affine的K+δ=2k+2为偶，所以反射符号一致；两个准周期因子互逆，将两项相加得到Gamma反射。 |
| 417 | `L5.4.expansion` | pass / pass / pass / pass / pass | 真实5.3/5.4编译类型对所有m成立；前式由四个b项合并，后式只再代入gamma=c−t c_shift，不引入反射假设。 |
| 418 | `P5.5.bracket.eval` | pass / pass / pass / pass / pass | bracketB_sum在允许范围用c(1−m)=−c(m)还原负段；CB_Bt_apply和cBt_first使Bt的实际C满足该求值法则。 |
| 419 | `SYMMETRIZER.proof` | pass / pass / pass / pass / pass | 交错化rename给置换符号，Vandermonde整除和总次数界使商为常数，zeroHead与scalar_succ固定常数为Vn；相关依赖都在symmetrizer的实际闭包。 |
| 420 | `T3.1.rank.YZ` | pass / pass / pass / pass / pass | YZ非零H和I子块分别给rankY=n、rankZ=k；range_eq_kernel依赖rank_transpose、rank_of_det_ne_zero及子矩阵rank界，无把目标rank当假设。 |
| 421 | `L3.3.pairing.plus.partition` | pass / pass / pass / pass / pass | unfold_center_two将唯一固定整数1单列，剩余p≥2与2−p≤0无交且覆盖全部；有限L截尾来自核支撑，故中心只出现一次。 |
| 422 | `P4.1.BC.tau.weight` | pass / pass / pass / pass / pass | BC用t^(r/2):=τ^r的原文约定，2[(2k+1)y²/2−jy]=(2k+1)y²−2jy；bBCSeq和配对type均使用该整数τ指数，Weyl端内部基参数τ²。 |
| 423 | `P4.2.Bminus.tau.weight` | pass / pass / pass / pass / pass | Bminus同理2[ky²−(j−1/2)y]=2ky²−(2j−1)y；无取数值平方根，bBminusSeq与真实Weyl基参数τ²一致。 |

## 实际检查输入

- `fidelity/packets/semantic_1-20261031T013834Z-c93b8281/manifest.json` — `9fbc3c3b40ae2cde359cc0af9e289ed9e998975efee93c1c50d07fa6f074fff1`。完整读取角色隔离、全部允许输入、required_inspected_sources和bound_input_hashes；逐个校验packet副本哈希。
- `fidelity/packets/semantic_1-20261031T013834Z-c93b8281/PROMPT.txt` — `4bc7d17900282b645ea2780b3616c18e6166ce71b4ea43972d29b3deb8631ea2`。完整角色和报告要求。
- `fidelity/packets/semantic_1-20261031T013834Z-c93b8281/inputs/fidelity/inputs/authoritative.pdf` — `b13eaa9ed2a2dc2919980a702965a2d138ee634b49d9a32125ddeaa67fece7ab`。仅完整字节读取以验证manifest的SHA-256；未作内容/视觉语义审阅，也未用该副本作为数学pass依据。
- `fidelity/packets/semantic_1-20261031T013834Z-c93b8281/inputs/fidelity/inputs/authoritative.txt` — `0cd074228dab999ce8217978668d5284f99f7fc610805a6e05e25ff94bc24a2f`。完整通读全部15页数学正文；逐条以页码、公式、证明段对照424义务；参考文献仅识别用途，未对外部文献作核查。
- `fidelity/packets/semantic_1-20261031T013834Z-c93b8281/inputs/fidelity/specs/paper_a.json` — `d68b0e5bba18573eddded78055b2d65121cf8c9c739453e49a7ce09511bc080f`。全部411原子结构和对应映射已解析；statement、assumptions、edge_cases按数学主题与canonical及原文逐组对照，未将JSON来源声明当作审查结论。
- `fidelity/packets/semantic_1-20261031T013834Z-c93b8281/inputs/fidelity/specs/paper_b.json` — `b7e38418a565769fd090102f5a3b79411f1d55c9b3c41fe5a95217f100cef4e1`。全部341原子结构和对应映射已解析；重点复核与A不同的变量域、宽零、奇偶、tau、support、中心和特化边界；其余重复陈述通过canonical映射与原文进行主题核对，非声称每字逐句编辑审读。
- `fidelity/packets/semantic_1-20261031T013834Z-c93b8281/inputs/fidelity/specs/canonical_math.json` — `a4c231b77eb70d75157c9855cb13fe5e6f97f1716fdc68dc8bcf89069ff3f414`。全部424条冻结数学字段；按id/index核对当前canonical除了declarations外逐字段一致，并对全部义务作五维语义审查。
- `fidelity/packets/semantic_1-20261031T013834Z-c93b8281/inputs/fidelity/canonical_claims.json` — `e272bc7e27e26b16938b8331052b71f7d959fd1556f1c519ec07d3bacdab3407`。全部424条映射、559个去重声明入口；每条statement、assumptions、objects、route、edge_cases与源证据；issues元数据仅作待核数据。
- `fidelity/packets/semantic_1-20261031T013834Z-c93b8281/inputs/fidelity/protocol.json` — `53fb330785ca76709bf22e4cb9557972a62e37db1489da2b73e83612ea960f9b`。完整读取review_schema、判定边界、hash绑定、certificate和pure-spec firewall要求；未把协议内命令当作本角色执行授权。
- `fidelity/packets/semantic_1-20261031T013834Z-c93b8281/inputs/fidelity/reviews/lean_reverse.json` — `11fef988cf5f2946dac95dcc81911bb9d35786f643818de97ea5f71c2bf40c74`。读取结构/provenance、18个object_groups叙述、coverage和unresolved；全2140声明/217对象字段已索引用于与环境精确对照，焦点是本次义务涉及对象与公开type，未宣称逐一理解所有辅助证明见证。独立复原不是paper verdict。
- `fidelity/packets/semantic_1-20261031T013834Z-c93b8281/inputs/fidelity/certificates.json` — `b48a4f6f2cf539d7d96fa0b8b40d016c2cad7fc24c0aee125f45aad6b29be17d`。全部17条certificate entries及claim列表；检查16正文容器和额外七case零参数出口，并展开实际Spec定义/accepted theorem type及其依赖。
- `fidelity/packets/semantic_1-20261031T013834Z-c93b8281/inputs/fidelity/specs/zero_parameter_addendum.json` — `c31a6f43be890fc0427967b0cf06d063f93b095cb735b145e62a2b3252763377`。完整七case独立类型出口、原文范围、固定Bplus边界及正宽限制；与environment中ZeroSpecialization、forall case和新certificate对照。
- `fidelity/packets/semantic_1-20261031T013834Z-c93b8281/inputs/fidelity/reviews/lean_reverse.md` — `49a7be4da16494c66ea9e946cba647daf2754f69eed67e0395b6bdff9fac3a17`。仅完整字节读取以验证manifest的SHA-256；未作内容/视觉语义审阅，也未用该副本作为数学pass依据。
- `fidelity/packets/semantic_1-20261031T013834Z-c93b8281/inputs/fidelity/specs/zero_parameter_addendum.md` — `ee91198e1b9ac45b5b143f525aba48b558a449f1d9f29c953b2adc4a87694d5b`。仅完整字节读取以验证manifest的SHA-256；未作内容/视觉语义审阅，也未用该副本作为数学pass依据。
- `fidelity/packets/semantic_1-20261031T013834Z-c93b8281/environment.json` — `2fa31da691cd21e6352409184e690919df4e87c8abe9fbe46504729c63eacef4`。全部2709声明结构、type哈希、mapped缺失和公理清单已校验；逐组审读全部559映射入口的数学type以及相关对象definition、实例构造器、matcher和定理条件；按type/value依赖计算2207项目声明闭包并在需要处审读rank、Gauss、支撑、fold、minor和specialization依赖。未取得/逐项重放定理完整proof terms，辅助证明与标准库实现仅作索引/依赖证据，不声称每字理解所有18MB。
