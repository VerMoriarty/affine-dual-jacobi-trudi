# 独立规范裁决报告

角色：`spec_reconciliation`，独立任务身份 `/root/spec_reconcile`。只读取冻结 A/B 规范及权威原文；没有读取 Lean 源码、README、旧审计日志或其他 reviews。裁决以原文为依据，不以两份抽取的相同意见作为证据。

## 冻结输入与校验

| 相对路径 | 实际 SHA-256 |
|---|---|
| `fidelity/specs/paper_a.json` | `d68b0e5bba18573eddded78055b2d65121cf8c9c739453e49a7ce09511bc080f` |
| `fidelity/specs/paper_a.md` | `fc8b0387b0ca5cbe56920e1f363d5614c30d31708fc31e8e6b181e557ab8adcf` |
| `fidelity/specs/paper_b.json` | `b7e38418a565769fd090102f5a3b79411f1d55c9b3c41fe5a95217f100cef4e1` |
| `fidelity/specs/paper_b.md` | `60e9d5a8ad5a8dd72796d30e2f7a3b1c86e63def24deced452de24d4ff567282` |
| `fidelity/inputs/authoritative.pdf` | `b13eaa9ed2a2dc2919980a702965a2d138ee634b49d9a32125ddeaa67fece7ab` |
| `fidelity/inputs/authoritative.txt` | `0cd074228dab999ce8217978668d5284f99f7fc610805a6e05e25ff94bc24a2f` |

A：411 / 411 个唯一原子已覆盖；B：341 / 341 个唯一原子已覆盖。两份规范引用的 PDF/TXT hash 均与实际输入一致。所有原始规范文件保持不变。
canonical 共 424 条，ID 全部唯一；映射类型：`{'source_only': 19, 'equivalent': 257, 'component_of': 148}`。定义、约定、证明步骤均计入原子覆盖分母。跨 claim 重复引用只表示原始复合原子的组件分解，覆盖率按 unique ID 计算。

## 裁定规则

`equivalent` 表示同一数学原子及其适用范围；`component_of` 表示原文支持的组件、量化实例或拆分关系，不能把一个子句当作整个复合原子的等价物；`source_only` 表示另一份规范没有独立原子，空侧明确保留为空，并附原文证据。

两份规范共有153个相同 ID 拼写；这不是153次自动等价判断。特别是 `P5.1.parity.projector` 的同名冲突已纠正。纯规范阶段每条 `declarations=[]`，没有依实现选择或删减数学命题。

## 分歧、缺项与回源裁定

### R001 — same_id_different_atom

A.P5.1.parity.projector 是标量偶性指示函数；B 同名 ID 是行列式投影公式。二者在证明中相接而非同一原子。原文第11页显示的是行列式公式，指示函数是其 parity projector 的直接代数展开。

涉及 canonical：`P5.1.parity.projector`, `P5.1.parity.det`。

原文依据：page 11; Proposition 5.1 parity projector displayed formula。

处理：B 同名原子只映射到 canonical P5.1.parity.det；A 的指示函数独立保留为 source_only。

### R002 — missing_independent_atom

A 单列形式变量、可逆变量与矩形宽度；B 将变量域写在各原子的 assumptions，未单列对应 ID。原文第1页 x=(x1,...,xn)、(kn) 与第2页有理函数域支持该约定。不能编造 B 的变量约定 ID。

涉及 canonical：`CONV.variables`。

原文依据：page 1; Introduction, x and rectangle notation；page 2; coefficient-field paragraph。

### R003 — missing_independent_atom

A 单列所有实际仿射和因零延拓有限；B 将有限性表述于 FINITE.rows.specialization 与 DEF.J 的 edge_cases，未把第2页全局句独立成原子。保留这条全局约定并以第8页共同支撑界作证明来源。

涉及 canonical：`CONV.finite.sums`。

原文依据：page 2; All sums below are finite by zero extension；page 8; common row-support bound。

### R004 — missing_independent_atom

A 单列正宽和空矩形对称群归一化都是 V_n(t)；B 未独立抽取这句话。原文(2.1)后明确说明只有宽零边界 Pochhammer 因子改变。

涉及 canonical：`WEYL.symmetric.normalization`。

原文依据：page 3; paragraph immediately below the rho/nu table。

### R005 — missing_independent_atom

B 单列两种系数族的常数项和最高项为1，A 仅在后文证明注记使用 e_0=1。直接由(1.1)：每对首项 x_a*x_a^{-1}=1，常数项均1，乘(1+u)亦保持两端。独立补入，不伪造 A ID。

涉及 canonical：`COEFF.endpoints`。

原文依据：page 1; (1.1) generating polynomials；page 7; complementary-block diagonal calculation。

### R006 — missing_independent_atom

B 单列 Lambda_i(0)=0；A 在 L3.3.unfold.C 的 route/edge case 使用而未单列原子。原文第8页证明明确写 Lambda_i(0)=0，故补为 source_only。

涉及 canonical：`KERNEL.Lambda.center`。

原文依据：page 8; Lemma 3.3 first proof sentence。

### R007 — proof_granularity

这些是 B 独立抽取、而 A 仅在 route 中叙述或没有独立原子的证明步骤。均按原文相应证明保留为独立 canonical 原子；不会因被归为证明元数据而移出覆盖分母。

涉及 canonical：`SYMMETRIZER.proof`, `T3.1.rank.YZ`, `L3.3.pairing.C`, `L3.3.pairing.B`, `L3.3.pairing.plus.partition`, `L5.2.shift.proof`, `L5.2.reflection.proof`, `L5.4.expansion`, `P5.5.bracket.eval`。

原文依据：page 3; symmetrizer proof sentence；page 6; Theorem 3.1 maximal-rank sentence；page 8; Lemma 3.3 pairing proof；page 11; Lemma 5.2 proof；page 12; Lemma 5.4 first proof sentence；page 13; Proposition 5.5 finite bracket evaluations。

### R008 — explicit_inferred_constants

A 独立给出 alpha=det X_Q0/det U_J 与 beta=(-1)^(nk)det Y_H/det Z_I；B 只抽取 epsilon(Q0),epsilon(H) 与“求值确定常数”的步骤，没有独立给出这两条商式。由原文第7页求值句及第6页两比例式直接得到，保留 A-only 原子。

涉及 canonical：`T3.1.alpha`, `T3.1.beta`。

原文依据：page 6; proportional complementary-minor equations；page 7; evaluation at Q0 and H。

### R009 — formal_square_root

A 将系数域拆成两条，B 将其合并且另列平方根约定。原文要求 BC 与 B_- 使用 Q(tau,x)、t=tau^2 及 t^(r/2):=tau^r（全部整数 r）。两个具体 tau 权是第9–10页 t 权按此约定重写，来源是直接形式指数代换。

涉及 canonical：`CONV.field.t`, `CONV.field.tau`, `AFFINE.tau.exponent`, `P4.1.BC.tau.weight`, `P4.2.Bminus.tau.weight`。

原文依据：page 2; coefficient-field and half-power convention；page 8; parameter-exponent paragraph；page 9; Proposition 4.1 affine A entries；page 10; Proposition 4.2 affine A entries。

### R010 — granularity

原文区分空行列式1、空向量和1以及 k=0 不求值条目/权。A 合并后两者，B 拆成两个原子。半因子(1.5),(1.9)仅正宽成立，宽零的归一化值另为1；不能把字面半因子公式用于空矩形。

涉及 canonical：`CONV.empty.det`, `CONV.empty.sum`, `A.Bplus.widthzero`, `B.widthzero`。

原文依据：page 2; empty determinant/vector/no-entry conventions and Theorems A,B；page 13; Proposition 6.1。

### R011 — granularity

A 把三交错式的交错性、反射乘子、次数界和常数分别抽取，B 逐类合并。原文第4页依次给三乘子、第二/第三行因子、Gauss 引理、三次数及最低次项。以组件关系逐个映射，不把合并的 B atom 宣称与任一 A 子句单独等价。

涉及 canonical：`L2.1.2.3`, `L2.1.2.4`, `L2.1.2.5`, `L2.1.first.alternating`, `L2.1.first.reflection`, `L2.1.first.degree`, `L2.1.first.constant`, `L2.1.second.alternating`, `L2.1.second.reflection`, `L2.1.second.degree`, `L2.1.second.constant`, `L2.1.third.alternating`, `L2.1.third.reflection`, `L2.1.third.degree`, `L2.1.third.constant`, `L2.1.second.rowfactor`, `L2.1.third.rowfactor`, `L2.1.Gauss`。

原文依据：page 4; Lemma 2.1 statement and complete proof。

### R012 — granularity

B 在 diamond 和全部七例上量化，A 按折叠类型/案例分别列原子；首列与其余列保持区分，tilde 只用于 C,B。单位三角块只在 k>=1 下成立。第4–6页支持该多对多分解。

涉及 canonical：`DEF.u.C.first`, `DEF.u.C.rest`, `DEF.u.B.first`, `DEF.u.B.rest`, `DEF.u.+.first`, `DEF.u.+.rest`, `DEF.utilde.C.first`, `DEF.utilde.C.rest`, `DEF.utilde.B.first`, `DEF.utilde.B.rest`, `P2.2.minor.C0`, `P2.2.minor.Ct`, `P2.2.minor.BC`, `P2.2.minor.B0`, `P2.2.minor.Bminus`, `P2.2.minor.Bplus`, `P2.2.minor.Bt`, `DEF.chi.first`, `DEF.chi.rest`, `P2.2.triangular.leading`, `P2.2.triangular.lower`, `P2.2.fold.Bplus.first`, `P2.2.fold.Bplus.rest`。

原文依据：page 4; evaluation matrices and normalized plus center；page 5; Section 2.2 and Table 1；page 6; Proposition 2.2 final triangularity argument。

### R013 — scope

转移定理在任意域 F 中成立，四个指定子式非零，矩阵维数与两核关系均保留；其仿射应用才使用特征零有理函数域。第3–5节 n,k>=1 的范围没有扩张到宽零。

涉及 canonical：`T3.1.transfer`, `T3.1.rank.X`, `T3.1.rank.U`, `T3.1.rank.YZ`, `T3.1.kernel`, `T3.1.normalized`。

原文依据：page 6; Section 3 opening and Theorem 3.1；page 7; normalization formula (3.1)。

### R014 — normalization

原文将 D^+ 首行设为 -h_i^+(1)，C^+ 首行为 -b_j(1)，配对中心仅计一次。倍数2来自 det D^+_J=2zeta；有限折叠 [1]_+=2e1 是另一处定义系数，不能移到仿射配对中心再加倍。

涉及 canonical：`L3.2.D.plus`, `L3.2.minor.plus`, `L3.2.pair.plus`, `L3.3.fold.plus.center`, `L3.3.center.once`, `P5.3.doubling.location`, `P5.3.pairing.center.once`。

原文依据：page 4; plus folding fixed center；page 7; Lemma 3.2 plus pairing and last block；page 8; (3.4),(3.7) and center proof；page 12; Proposition 5.3。

### R015 — parity_scope

C_t 的倍数2来自固定剩余类 j=k（包括 k=1）；最终求和域是向量分量总和为偶数的子格。原文用投影和末列对合使 det A^+=0，从而得到半个 det A^-，不能改为无投影全格和。

涉及 canonical：`P5.1.fixed.residue`, `P5.1.CI.entries`, `P5.1.CI.det`, `P5.1.parity.det`, `P5.1.lastcolumn.zero`, `P5.1.result`。

原文依据：page 10; Proposition 5.1 fixed residue；page 11; initial block, parity projection and last-column involution。

### R016 — adjacent_normalization

B_t 沿用 D^B；倍数2来自相邻剩余类首块原点重叠，C_I 对角为 -2,1,-1,...，k=1 为[-2]，det C_I=2omega。hhat 由 h(m)+h(m-1) 得到，不另造 ddot 系数矩阵。

涉及 canonical：`P5.5.CI.entries`, `P5.5.CI.bidiagonal`, `P5.5.CI.det`, `P5.5.DJ.undoubled`, `P5.5.pairing.hhat`。

原文依据：page 12; Section 5.3 hhat and adjacent definitions；page 13; Proposition 5.5 overlap block and final pairing。

### R017 — width_zero_scope

A 分离对角系数与乘积，B 每例合并；原文宽零证明重用有限交错化/折叠，不越界调用正宽度单位子式或核转移。归一化因子先在有理函数中消去，可去奇点按消去后解释，不增加 Pochhammer 数值非零假设。

涉及 canonical：`P6.1.diagonal.C0`, `P6.1.product.C0`, `P6.1.diagonal.BC`, `P6.1.product.BC`, `P6.1.diagonal.B0`, `P6.1.product.B0`, `P6.1.diagonal.Ct`, `P6.1.product.Ct`, `P6.1.diagonal.Bt`, `P6.1.product.Bt`, `P6.1.diagonal.Bminus`, `P6.1.product.Bminus`, `P6.1.diagonal.Bplus`, `P6.1.product.Bplus`, `P6.1.finite.ratio`, `CONV.cancel.before.specialize`。

原文依据：page 13; Proposition 6.1 proof；page 14; diagonal/product table and cancellation paragraph。

### R018 — specialization_scope

A 按七例拆分零参数列化简，B 合并列化简；两者的经典结论均限 n,k>=1。非零移位严格正指数论证只用于 C0,B0,B+,Bt。C_t 的 j=k,y=1 指数为0，必须通过有限比值与已证奇偶投影解释其特化。

涉及 canonical：`C6.2.6.1`, `C6.2.6.2.h`, `C6.2.6.2.hhat`, `C6.2.6.3`, `C6.2.columns.C0`, `C6.2.specialization.C0`, `C6.2.columns.Ct`, `C6.2.specialization.Ct`, `C6.2.columns.BC`, `C6.2.specialization.BC`, `C6.2.columns.B0`, `C6.2.specialization.B0`, `C6.2.columns.Bminus`, `C6.2.specialization.Bminus`, `C6.2.columns.Bt`, `C6.2.specialization.Bt`, `C6.2.columns.Bplus`, `C6.2.specialization.Bplus`, `C6.2.nonzero.shift.C0`, `C6.2.nonzero.shift.B0`, `C6.2.nonzero.shift.Bplus`, `C6.2.nonzero.shift.Bt`, `C6.2.Ct.exception`, `C6.2.Ct.route`。

原文依据：page 14; Corollary 6.2 including all three determinant identities；page 15; complete specialization proof。

## 单侧独立原子

以下各条已回源裁定，单侧为空不表示删去或未核实；其逐条 source_evidence 与内容见 canonical JSON：

- `CONV.variables`：A=['CONV.variables']；B=[]；原文第1页，(1.1)前。
- `CONV.finite.sums`：A=['CONV.finite.sums']；B=[]；原文第2页，(1.2)后。
- `WEYL.symmetric.normalization`：A=['WEYL.symmetric.normalization']；B=[]；原文第3页，case table 后。
- `T3.1.alpha`：A=['T3.1.alpha']；B=[]；原文第7页，Theorem 3.1 proof end。
- `T3.1.beta`：A=['T3.1.beta']；B=[]；原文第7页，Theorem 3.1 proof end。
- `P5.1.parity.projector`：A=['P5.1.parity.projector']；B=[]；原文第11页，Proposition 5.1 parity paragraph。
- `COEFF.endpoints`：A=[]；B=['COEFF.endpoints']；原文第1页，(1.1), constant and leading coefficients。
- `KERNEL.Lambda.center`：A=[]；B=['KERNEL.Lambda.center']；原文第8页，Lemma 3.3 proof, first sentence。
- `L3.3.pairing.C`：A=[]；B=['L3.3.pairing.C']；原文第8页，Lemma 3.3 proof, C。
- `L3.3.pairing.B`：A=[]；B=['L3.3.pairing.B']；原文第8页，Lemma 3.3 proof, B。
- `L5.2.shift.proof`：A=[]；B=['L5.2.shift.proof']；原文第11页，first sentence of proof。
- `L5.2.reflection.proof`：A=[]；B=['L5.2.reflection.proof']；原文第11页，last paragraph of proof。
- `L5.4.expansion`：A=[]；B=['L5.4.expansion']；原文第12页，first sentence of proof。
- `P5.5.bracket.eval`：A=[]；B=['P5.5.bracket.eval']；原文第13页，implicit in finite-column evaluation。
- `SYMMETRIZER.proof`：A=[]；B=['WEYL.symmetrizer.recurrence']；原文第3页，paragraph after symmetrizer。
- `T3.1.rank.YZ`：A=[]；B=['T3.1.ranks']；原文第6页，first sentence of proof。
- `L3.3.pairing.plus.partition`：A=[]；B=['L3.3.pairing.plus']；原文第8页，Lemma 3.3 proof, plus。
- `P4.1.BC.tau.weight`：A=[]；B=['P4.1.weight.BC']；原文第9页，last paragraph, affine sign BC。
- `P4.2.Bminus.tau.weight`：A=[]；B=['P4.2.weight.Bminus']；原文第10页，last paragraph sign distinction。

## 全量逐项对齐

以下表格按 canonical 原子列出 A/B 引用和关系；具体命题、前提、边界与原文定位在 `canonical_claims.json`，逐项 B 复合原子的完整拆分在本报告 JSON 的 `paper_b_alignment`。

| Canonical ID | 类别 | 页 | A 原子 | B 原子 | 关系 |
|---|---|---:|---|---|---|
| `CONV.variables` | convention | 1 | `CONV.variables` |  | source_only |
| `DEF.Edot` | definition | 1 | `DEF.Edot` | `DEF.Edot` | equivalent |
| `DEF.Eddot` | definition | 1 | `DEF.Eddot` | `DEF.Eddot` | equivalent |
| `CONV.edot.zero` | convention | 1 | `CONV.edot.zero` | `CONV.dot.zero` | equivalent |
| `CONV.eddot.zero` | convention | 1 | `CONV.eddot.zero` | `CONV.ddot.zero` | equivalent |
| `COEFF.edot.palindrome` | statement | 1 | `COEFF.edot.palindrome` | `COEFF.dot.palindrome` | equivalent |
| `COEFF.eddot.palindrome` | statement | 1 | `COEFF.eddot.palindrome` | `COEFF.ddot.palindrome` | equivalent |
| `COEFF.eddot.sum` | statement | 1 | `COEFF.eddot.sum` | `COEFF.convolution` | equivalent |
| `DEF.Lambda` | definition | 1 | `DEF.Lambda` | `DEF.Lambda` | equivalent |
| `DEF.h` | definition | 1 | `DEF.h` | `DEF.h` | equivalent |
| `DEF.hplus` | definition | 1 | `DEF.hplus` | `DEF.hplus` | equivalent |
| `DEF.hhat` | definition | 1 | `DEF.hhat` | `DEF.hhat` | equivalent |
| `DEF.J` | definition | 2 | `DEF.J` | `DEF.J` | equivalent |
| `CONV.weight.slot` | convention | 2 | `CONV.weight.slot` | `CONV.weight.slot` | equivalent |
| `DEF.even.lattice` | definition | 2 | `DEF.even.lattice` | `DEF.even.lattice` | equivalent |
| `CONV.empty.det` | convention | 2 | `CONV.empty.det` | `CONV.empty.det` | equivalent |
| `CONV.empty.sum` | convention | 2 | `CONV.empty.sum` | `CONV.empty.vector`, `CONV.empty.noeval` | component_of |
| `CONV.field.t` | convention | 2 | `CONV.field.t` | `CONV.coefficient.field` | component_of |
| `CONV.field.tau` | convention | 2 | `CONV.field.tau` | `CONV.coefficient.field`, `CONV.sqrt` | component_of |
| `CONV.finite.sums` | convention | 2 | `CONV.finite.sums` |  | source_only |
| `A.1.3` | statement | 2 | `A.1.3` | `A.1.3` | equivalent |
| `A.1.4` | statement | 2 | `A.1.4` | `A.1.4` | equivalent |
| `A.1.5` | statement | 2 | `A.1.5` | `A.1.5` | equivalent |
| `A.1.6` | statement | 2 | `A.1.6` | `A.1.6` | equivalent |
| `A.1.7` | statement | 2 | `A.1.7` | `A.1.7` | equivalent |
| `A.1.8` | statement | 2 | `A.1.8` | `A.1.8` | equivalent |
| `A.Bplus.widthzero` | statement | 2 | `A.Bplus.widthzero` | `A.widthzero.Bplus` | equivalent |
| `B.1.9` | statement | 2 | `B.1.9` | `B.1.9` | equivalent |
| `B.widthzero` | statement | 2 | `B.widthzero` | `B.widthzero.Bt` | equivalent |
| `DEF.case.C0` | definition | 3 | `DEF.case.C0` | `DEF.case.labels` | component_of |
| `DEF.rho.C0` | definition | 3 | `DEF.rho.C0` | `DEF.rho.C0` | equivalent |
| `DEF.nu0.C0` | definition | 3 | `DEF.nu0.C0` | `DEF.nu.zero.C0` | equivalent |
| `DEF.case.Ct` | definition | 3 | `DEF.case.Ct` | `DEF.case.labels` | component_of |
| `DEF.rho.Ct` | definition | 3 | `DEF.rho.Ct` | `DEF.rho.Ct` | equivalent |
| `DEF.nu0.Ct` | definition | 3 | `DEF.nu0.Ct` | `DEF.nu.zero.Ct` | equivalent |
| `DEF.case.BC` | definition | 3 | `DEF.case.BC` | `DEF.case.labels` | component_of |
| `DEF.rho.BC` | definition | 3 | `DEF.rho.BC` | `DEF.rho.BC` | equivalent |
| `DEF.nu0.BC` | definition | 3 | `DEF.nu0.BC` | `DEF.nu.zero.BC` | equivalent |
| `DEF.case.B0` | definition | 3 | `DEF.case.B0` | `DEF.case.labels` | component_of |
| `DEF.rho.B0` | definition | 3 | `DEF.rho.B0` | `DEF.rho.B0` | equivalent |
| `DEF.nu0.B0` | definition | 3 | `DEF.nu0.B0` | `DEF.nu.zero.B0` | equivalent |
| `DEF.case.Bminus` | definition | 3 | `DEF.case.Bminus` | `DEF.case.labels` | component_of |
| `DEF.rho.Bminus` | definition | 3 | `DEF.rho.Bminus` | `DEF.rho.Bminus` | equivalent |
| `DEF.nu0.Bminus` | definition | 3 | `DEF.nu0.Bminus` | `DEF.nu.zero.Bminus` | equivalent |
| `DEF.case.Bplus` | definition | 3 | `DEF.case.Bplus` | `DEF.case.labels` | component_of |
| `DEF.rho.Bplus` | definition | 3 | `DEF.rho.Bplus` | `DEF.rho.Bplus` | equivalent |
| `DEF.nu0.Bplus` | definition | 3 | `DEF.nu0.Bplus` | `DEF.nu.zero.Bplus` | equivalent |
| `DEF.case.Bt` | definition | 3 | `DEF.case.Bt` | `DEF.case.labels` | component_of |
| `DEF.rho.Bt` | definition | 3 | `DEF.rho.Bt` | `DEF.rho.Bt` | equivalent |
| `DEF.nu0.Bt` | definition | 3 | `DEF.nu0.Bt` | `DEF.nu.zero.Bt` | equivalent |
| `DEF.pochhammer` | definition | 3 | `DEF.pochhammer` | `DEF.Pochhammer` | equivalent |
| `DEF.Vn` | definition | 3 | `DEF.Vn` | `DEF.Vn` | equivalent |
| `DEF.Wn` | definition | 3 | `DEF.Wn` | `DEF.Wn` | equivalent |
| `DEF.nu.positive` | definition | 3 | `DEF.nu.positive` | `DEF.nu.positive` | equivalent |
| `DEF.P.weylsum` | definition | 3 | `DEF.P.weylsum` | `DEF.Weyl.sum` | equivalent |
| `SYMMETRIZER` | statement | 3 | `SYMMETRIZER` | `WEYL.symmetrizer` | equivalent |
| `SYMMETRIZER.recurrence` | proof_step | 3 | `SYMMETRIZER.recurrence` | `WEYL.symmetrizer.recurrence` | component_of |
| `WEYL.symmetric.normalization` | convention | 3 | `WEYL.symmetric.normalization` |  | source_only |
| `WEYL.inversion.reduction` | statement | 3 | `WEYL.inversion.reduction` | `WEYL.inversion.sum` | equivalent |
| `DEF.Nt` | definition | 3 | `DEF.Nt` | `DEF.Nt` | equivalent |
| `DEF.fr.first` | definition | 3 | `DEF.fr.first` | `DEF.fr.first` | equivalent |
| `DEF.fr.rest` | definition | 3 | `DEF.fr.rest` | `DEF.fr.rest` | equivalent |
| `L2.1.2.3` | statement | 4 | `L2.1.2.3` | `L2.1.2.3` | equivalent |
| `L2.1.2.4` | statement | 4 | `L2.1.2.4` | `L2.1.2.4` | equivalent |
| `L2.1.2.5` | statement | 4 | `L2.1.2.5` | `L2.1.2.5` | equivalent |
| `L2.1.first.alternating` | proof_step | 4 | `L2.1.first.alternating` | `L2.1.divisibility` | component_of |
| `L2.1.first.reflection` | proof_step | 4 | `L2.1.first.reflection` | `L2.1.reflection.2.3` | equivalent |
| `L2.1.first.degree` | proof_step | 4 | `L2.1.first.degree` | `L2.1.degree` | component_of |
| `L2.1.first.constant` | proof_step | 4 | `L2.1.first.constant` | `L2.1.constant` | component_of |
| `L2.1.second.alternating` | proof_step | 4 | `L2.1.second.alternating` | `L2.1.divisibility` | component_of |
| `L2.1.second.reflection` | proof_step | 4 | `L2.1.second.reflection` | `L2.1.reflection.2.4` | equivalent |
| `L2.1.second.degree` | proof_step | 4 | `L2.1.second.degree` | `L2.1.degree` | component_of |
| `L2.1.second.constant` | proof_step | 4 | `L2.1.second.constant` | `L2.1.constant` | component_of |
| `L2.1.third.alternating` | proof_step | 4 | `L2.1.third.alternating` | `L2.1.divisibility` | component_of |
| `L2.1.third.reflection` | proof_step | 4 | `L2.1.third.reflection` | `L2.1.reflection.2.5` | equivalent |
| `L2.1.third.degree` | proof_step | 4 | `L2.1.third.degree` | `L2.1.degree` | component_of |
| `L2.1.third.constant` | proof_step | 4 | `L2.1.third.constant` | `L2.1.constant` | component_of |
| `L2.1.second.rowfactor` | proof_step | 4 | `L2.1.second.rowfactor` | `L2.1.rowfactors` | component_of |
| `L2.1.third.rowfactor` | proof_step | 4 | `L2.1.third.rowfactor` | `L2.1.rowfactors` | component_of |
| `L2.1.Gauss` | proof_step | 4 | `L2.1.Gauss` | `L2.1.divisibility` | component_of |
| `DEF.phi` | definition | 4 | `DEF.phi` | `DEF.phi` | equivalent |
| `DEF.psi` | definition | 4 | `DEF.psi` | `DEF.psi` | equivalent |
| `DEF.C` | definition | 4 | `DEF.C` | `DEF.Cfun` | equivalent |
| `DEF.L.basis` | definition | 4 | `DEF.L.basis` | `DEF.L` | equivalent |
| `DEF.fold.C.positive` | definition | 4 | `DEF.fold.C.positive` | `DEF.fold.C.positive` | equivalent |
| `DEF.fold.C.zero` | definition | 4 | `DEF.fold.C.zero` | `DEF.fold.C.zero` | equivalent |
| `DEF.fold.C.negative` | definition | 4 | `DEF.fold.C.negative` | `DEF.fold.C.negative` | equivalent |
| `DEF.fold.B.positive` | definition | 4 | `DEF.fold.B.positive` | `DEF.fold.B.positive` | equivalent |
| `DEF.fold.B.nonpositive` | definition | 4 | `DEF.fold.B.nonpositive` | `DEF.fold.B.nonpositive` | equivalent |
| `DEF.fold.plus.large` | definition | 4 | `DEF.fold.plus.large` | `DEF.fold.plus.high` | equivalent |
| `DEF.fold.plus.center` | definition | 4 | `DEF.fold.plus.center` | `DEF.fold.plus.center` | equivalent |
| `DEF.fold.plus.nonpositive` | definition | 4 | `DEF.fold.plus.nonpositive` | `DEF.fold.plus.nonpositive` | equivalent |
| `CONV.fold.range` | convention | 4 | `CONV.fold.range` | `CONV.fold.range` | equivalent |
| `DEF.Phi.C` | definition | 4 | `DEF.Phi.C` | `DEF.Phi.C` | equivalent |
| `DEF.Phi.B` | definition | 4 | `DEF.Phi.B` | `DEF.Phi.B` | equivalent |
| `DEF.Phi.plus.first` | definition | 4 | `DEF.Phi.plus.first` | `DEF.Phi.plus.first` | equivalent |
| `DEF.Phi.plus.rest` | definition | 4 | `DEF.Phi.plus.rest` | `DEF.Phi.plus.rest` | equivalent |
| `FOLD.eval.C` | statement | 4 | `FOLD.eval.C` | `EVAL.fold.C` | equivalent |
| `FOLD.eval.B` | statement | 4 | `FOLD.eval.B` | `EVAL.fold.B` | equivalent |
| `FOLD.eval.plus` | statement | 4 | `FOLD.eval.plus` | `EVAL.fold.plus` | equivalent |
| `DEF.chi.first` | definition | 5 | `DEF.chi.first` | `DEF.chi` | component_of |
| `DEF.chi.rest` | definition | 5 | `DEF.chi.rest` | `DEF.chi` | component_of |
| `WEYL.denominator.C` | statement | 4 | `WEYL.denominator.C` | `WEYL.delta.C` | equivalent |
| `WEYL.denominator.monic.C` | proof_step | 5 | `WEYL.denominator.monic.C` | `WEYL.delta.vandermonde` | component_of |
| `WEYL.denominator.inversion.C` | statement | 5 | `WEYL.denominator.inversion.C` | `WEYL.delta.inversion.C` | equivalent |
| `WEYL.denominator.B` | statement | 4 | `WEYL.denominator.B` | `WEYL.delta.B` | equivalent |
| `WEYL.denominator.monic.B` | proof_step | 5 | `WEYL.denominator.monic.B` | `WEYL.delta.vandermonde` | component_of |
| `WEYL.denominator.inversion.B` | statement | 5 | `WEYL.denominator.inversion.B` | `WEYL.delta.inversion.B` | equivalent |
| `WEYL.denominator.plus` | statement | 4 | `WEYL.denominator.plus` | `WEYL.delta.plus` | equivalent |
| `WEYL.denominator.monic.plus` | proof_step | 5 | `WEYL.denominator.monic.plus` | `WEYL.delta.vandermonde` | component_of |
| `WEYL.denominator.inversion.plus` | statement | 5 | `WEYL.denominator.inversion.plus` | `WEYL.delta.inversion.plus` | equivalent |
| `DEF.u.C.first` | definition | 5 | `DEF.u.C.first` | `DEF.u.first` | component_of |
| `DEF.u.C.rest` | definition | 5 | `DEF.u.C.rest` | `DEF.u.rest` | component_of |
| `DEF.u.B.first` | definition | 5 | `DEF.u.B.first` | `DEF.u.first` | component_of |
| `DEF.u.B.rest` | definition | 5 | `DEF.u.B.rest` | `DEF.u.rest` | component_of |
| `DEF.u.+.first` | definition | 5 | `DEF.u.+.first` | `DEF.u.first` | component_of |
| `DEF.u.+.rest` | definition | 5 | `DEF.u.+.rest` | `DEF.u.rest` | component_of |
| `DEF.utilde.C.first` | definition | 5 | `DEF.utilde.C.first` | `DEF.utilde.first` | component_of |
| `DEF.utilde.C.rest` | definition | 5 | `DEF.utilde.C.rest` | `DEF.utilde.rest` | component_of |
| `DEF.utilde.B.first` | definition | 5 | `DEF.utilde.B.first` | `DEF.utilde.first` | component_of |
| `DEF.utilde.B.rest` | definition | 5 | `DEF.utilde.B.rest` | `DEF.utilde.rest` | component_of |
| `DEF.V.C0` | definition | 5 | `DEF.V.C0` | `DEF.V.C0` | equivalent |
| `P2.2.ratio.C0` | statement | 5 | `P2.2.ratio.C0` | `P2.2.ratio.C0` | equivalent |
| `P2.2.minor.C0` | statement | 5 | `P2.2.minor.C0` | `P2.2.minor` | component_of |
| `DEF.V.Ct` | definition | 5 | `DEF.V.Ct` | `DEF.V.Ct` | equivalent |
| `P2.2.ratio.Ct` | statement | 5 | `P2.2.ratio.Ct` | `P2.2.ratio.Ct` | equivalent |
| `P2.2.minor.Ct` | statement | 5 | `P2.2.minor.Ct` | `P2.2.minor` | component_of |
| `DEF.V.BC` | definition | 5 | `DEF.V.BC` | `DEF.V.BC` | equivalent |
| `P2.2.ratio.BC` | statement | 5 | `P2.2.ratio.BC` | `P2.2.ratio.BC` | equivalent |
| `P2.2.minor.BC` | statement | 5 | `P2.2.minor.BC` | `P2.2.minor` | component_of |
| `DEF.V.B0` | definition | 5 | `DEF.V.B0` | `DEF.V.B0` | equivalent |
| `P2.2.ratio.B0` | statement | 5 | `P2.2.ratio.B0` | `P2.2.ratio.B0` | equivalent |
| `P2.2.minor.B0` | statement | 5 | `P2.2.minor.B0` | `P2.2.minor` | component_of |
| `DEF.V.Bminus` | definition | 5 | `DEF.V.Bminus` | `DEF.V.Bminus` | equivalent |
| `P2.2.ratio.Bminus` | statement | 5 | `P2.2.ratio.Bminus` | `P2.2.ratio.Bminus` | equivalent |
| `P2.2.minor.Bminus` | statement | 5 | `P2.2.minor.Bminus` | `P2.2.minor` | component_of |
| `DEF.V.Bplus` | definition | 5 | `DEF.V.Bplus` | `DEF.V.Bplus` | equivalent |
| `P2.2.ratio.Bplus` | statement | 5 | `P2.2.ratio.Bplus` | `P2.2.ratio.Bplus` | equivalent |
| `P2.2.minor.Bplus` | statement | 5 | `P2.2.minor.Bplus` | `P2.2.minor` | component_of |
| `DEF.V.Bt` | definition | 5 | `DEF.V.Bt` | `DEF.V.Bt` | equivalent |
| `P2.2.ratio.Bt` | statement | 5 | `P2.2.ratio.Bt` | `P2.2.ratio.Bt` | equivalent |
| `P2.2.minor.Bt` | statement | 5 | `P2.2.minor.Bt` | `P2.2.minor` | component_of |
| `P2.2.fold.C0` | proof_step | 5 | `P2.2.fold.C0` | `P2.2.fold.C0` | component_of |
| `P2.2.fold.BC` | proof_step | 5 | `P2.2.fold.BC` | `P2.2.fold.BC` | equivalent |
| `P2.2.fold.Ct` | proof_step | 5 | `P2.2.fold.Ct` | `P2.2.fold.Ct` | equivalent |
| `P2.2.fold.B0` | proof_step | 5 | `P2.2.fold.B0` | `P2.2.fold.B0` | equivalent |
| `P2.2.fold.Bt` | proof_step | 5 | `P2.2.fold.Bt` | `P2.2.fold.Bt` | equivalent |
| `P2.2.fold.Bminus` | proof_step | 6 | `P2.2.fold.Bminus` | `P2.2.fold.Bminus` | component_of |
| `P2.2.fold.Bplus.first` | proof_step | 6 | `P2.2.fold.Bplus.first` | `P2.2.fold.Bplus` | component_of |
| `P2.2.fold.Bplus.rest` | proof_step | 6 | `P2.2.fold.Bplus.rest` | `P2.2.fold.Bplus` | component_of |
| `P2.2.triangular.leading` | proof_step | 6 | `P2.2.triangular.leading` | `P2.2.leading.rows` | component_of |
| `P2.2.triangular.lower` | proof_step | 6 | `P2.2.triangular.lower` | `P2.2.leading.rows` | component_of |
| `CONV.sections3to5` | convention | 6 | `CONV.sections3to5` | `CONV.sections3to5` | equivalent |
| `DEF.Q0` | definition | 6 | `DEF.Q0` | `DEF.Q0` | equivalent |
| `DEF.index.J` | definition | 6 | `DEF.index.J` | `DEF.index.J` | equivalent |
| `DEF.H` | definition | 6 | `DEF.H` | `DEF.H` | equivalent |
| `DEF.I` | definition | 6 | `DEF.I` | `DEF.I` | equivalent |
| `DEF.omega` | definition | 6 | `DEF.omega` | `DEF.omega` | equivalent |
| `DEF.zeta` | definition | 6 | `DEF.zeta` | `DEF.zeta` | equivalent |
| `CONV.subset.order` | convention | 6 | `CONV.subset.order` | `CONV.minor.order` | component_of |
| `CONV.minor.columns` | convention | 6 | `CONV.minor.columns` | `CONV.minor.order` | component_of |
| `CONV.minor.rows` | convention | 6 | `CONV.minor.rows` | `CONV.minor.order` | component_of |
| `T3.1.transfer` | statement | 6 | `T3.1.transfer` | `T3.1.transfer` | equivalent |
| `T3.1.rank.X` | proof_step | 6 | `T3.1.rank.X` | `T3.1.ranks` | component_of |
| `T3.1.rank.U` | proof_step | 6 | `T3.1.rank.U` | `T3.1.ranks` | component_of |
| `T3.1.kernel` | proof_step | 6 | `T3.1.kernel` | `T3.1.ranks` | component_of |
| `T3.1.topforms` | proof_step | 6 | `T3.1.topforms` | `T3.1.topforms` | equivalent |
| `T3.1.epsilon` | definition | 6 | `T3.1.epsilon` | `T3.1.epsilon` | equivalent |
| `T3.1.complement.sign` | proof_step | 6 | `T3.1.complement.sign` | `T3.1.laplace` | equivalent |
| `T3.1.minors.X` | proof_step | 6 | `T3.1.minors.X` | `T3.1.complement.X` | equivalent |
| `T3.1.minors.Y` | proof_step | 6 | `T3.1.minors.Y` | `T3.1.complement.Y` | component_of |
| `T3.1.CauchyBinet` | proof_step | 6 | `T3.1.CauchyBinet` | `T3.1.CauchyBinet` | equivalent |
| `T3.1.epsilon.Q0` | proof_step | 7 | `T3.1.epsilon.Q0` | `T3.1.normalizing.signs` | component_of |
| `T3.1.epsilon.H` | proof_step | 7 | `T3.1.epsilon.H` | `T3.1.normalizing.signs` | component_of |
| `T3.1.alpha` | proof_step | 7 | `T3.1.alpha` |  | source_only |
| `T3.1.beta` | proof_step | 7 | `T3.1.beta` |  | source_only |
| `T3.1.normalized` | statement | 7 | `T3.1.normalized` | `TRANSFER.normalized` | equivalent |
| `L3.2.symmetry.Lambda` | statement | 7 | `L3.2.symmetry.Lambda` | `KERNEL.reflection.Lambda` | equivalent |
| `L3.2.symmetry.h` | statement | 7 | `L3.2.symmetry.h` | `KERNEL.reflection.h` | equivalent |
| `L3.2.symmetry.hplus` | statement | 7 | `L3.2.symmetry.hplus` | `KERNEL.reflection.hplus` | equivalent |
| `L3.2.palindrome.form.h` | statement | 7 | `L3.2.palindrome.form.h` | `KERNEL.rewrite.h` | equivalent |
| `L3.2.palindrome.form.hplus` | statement | 7 | `L3.2.palindrome.form.hplus` | `KERNEL.rewrite.hplus` | equivalent |
| `L3.2.D.C` | definition | 7 | `L3.2.D.C` | `DEF.D.C` | equivalent |
| `L3.2.D.B` | definition | 7 | `L3.2.D.B` | `DEF.D.B` | equivalent |
| `L3.2.D.plus` | definition | 7 | `L3.2.D.plus` | `DEF.D.plus` | equivalent |
| `L3.2.kernel.C` | statement | 7 | `L3.2.kernel.C` | `L3.2.kernel.C` | equivalent |
| `L3.2.minor.C` | statement | 7 | `L3.2.minor.C` | `L3.2.minor.C` | equivalent |
| `L3.2.kernel.B` | statement | 7 | `L3.2.kernel.B` | `L3.2.kernel.B` | equivalent |
| `L3.2.minor.B` | statement | 7 | `L3.2.minor.B` | `L3.2.minor.B` | equivalent |
| `L3.2.kernel.plus` | statement | 7 | `L3.2.kernel.plus` | `L3.2.kernel.plus` | equivalent |
| `L3.2.minor.plus` | statement | 7 | `L3.2.minor.plus` | `L3.2.minor.plus` | equivalent |
| `L3.2.generating.C` | proof_step | 7 | `L3.2.generating.C` | `L3.2.generating.C` | equivalent |
| `L3.2.generating.vanish.C` | proof_step | 7 | `L3.2.generating.vanish.C` | `L3.2.root` | component_of |
| `L3.2.generating.B` | proof_step | 7 | `L3.2.generating.B` | `L3.2.generating.B` | equivalent |
| `L3.2.generating.vanish.B` | proof_step | 7 | `L3.2.generating.vanish.B` | `L3.2.root` | component_of |
| `L3.2.generating.plus` | proof_step | 7 | `L3.2.generating.plus` | `L3.2.generating.plus` | equivalent |
| `L3.2.generating.vanish.plus` | proof_step | 7 | `L3.2.generating.vanish.plus` | `L3.2.root` | component_of |
| `L3.2.pair.C` | proof_step | 7 | `L3.2.pair.C` | `L3.2.pairing.C` | equivalent |
| `L3.2.pair.B` | proof_step | 7 | `L3.2.pair.B` | `L3.2.pairing.B` | equivalent |
| `L3.2.pair.plus` | proof_step | 7 | `L3.2.pair.plus` | `L3.2.pairing.plus` | equivalent |
| `L3.2.support.C` | proof_step | 7 | `L3.2.support.C` | `L3.2.support.C` | component_of |
| `L3.2.support.B` | proof_step | 7 | `L3.2.support.B` | `L3.2.support.B` | component_of |
| `L3.2.support.plus` | proof_step | 7 | `L3.2.support.plus` | `L3.2.support.plus` | component_of |
| `L3.2.lastblock.C` | proof_step | 7 | `L3.2.lastblock.C` | `L3.2.block.C` | equivalent |
| `L3.2.lastblock.B` | proof_step | 7 | `L3.2.lastblock.B` | `L3.2.block.B` | equivalent |
| `L3.2.lastblock.plus` | proof_step | 7 | `L3.2.lastblock.plus` | `L3.2.block.plus` | equivalent |
| `L3.2.triangular.C` | proof_step | 7 | `L3.2.triangular.C` | `L3.2.triangular.CB` | component_of |
| `L3.2.triangular.B` | proof_step | 7 | `L3.2.triangular.B` | `L3.2.triangular.CB` | component_of |
| `L3.2.triangular.plus` | proof_step | 7 | `L3.2.triangular.plus` | `L3.2.triangular.plus` | component_of |
| `L3.3.fold.C` | definition | 8 | `L3.3.fold.C` | `DEF.affine.fold.C` | equivalent |
| `L3.3.fold.B` | definition | 8 | `L3.3.fold.B` | `DEF.affine.fold.B` | equivalent |
| `L3.3.fold.plus.center` | definition | 8 | `L3.3.fold.plus.center` | `DEF.affine.fold.plus.center` | equivalent |
| `L3.3.fold.plus.rest` | definition | 8 | `L3.3.fold.plus.rest` | `DEF.affine.fold.plus.rest` | equivalent |
| `L3.3.unfold.C` | statement | 8 | `L3.3.unfold.C` | `L3.3.unfold.C` | equivalent |
| `L3.3.unfold.B` | statement | 8 | `L3.3.unfold.B` | `L3.3.unfold.B` | equivalent |
| `L3.3.unfold.plus` | statement | 8 | `L3.3.unfold.plus` | `L3.3.unfold.plus` | equivalent |
| `L3.3.center.once` | proof_step | 8 | `L3.3.center.once` | `L3.3.pairing.plus` | component_of |
| `AFFINE.row.support` | statement | 8 | `AFFINE.row.support` | `FINITE.rows.bound` | equivalent |
| `AFFINE.row.support.edot` | proof_step | 8 | `AFFINE.row.support.edot` | `FINITE.rows.specialization` | component_of |
| `AFFINE.multilinearity` | statement | 8 | `AFFINE.multilinearity` | `FINITE.det.multilinear` | equivalent |
| `AFFINE.exponent.nonnegative` | statement | 8 | `AFFINE.exponent.nonnegative` | `PARAM.exponents.nonnegative` | equivalent |
| `AFFINE.B0.exponent.integral` | proof_step | 8 | `AFFINE.B0.exponent.integral` | `PARAM.exponents.integral.B0` | equivalent |
| `AFFINE.tau.exponent` | convention | 8 | `AFFINE.tau.exponent` | `PARAM.exponents.sqrt` | component_of |
| `AFFINE.polynomial` | statement | 8 | `AFFINE.polynomial` | `PARAM.polynomial` | equivalent |
| `P4.1.K.C0` | definition | 9 | `P4.1.K.C0` | `P4.1.K.C0` | equivalent |
| `P4.1.K.BC` | definition | 9 | `P4.1.K.BC` | `P4.1.K.BC` | equivalent |
| `P4.1.b.residue` | definition | 9 | `P4.1.b.residue` | `P4.1.b.support` | equivalent |
| `P4.1.b.outside` | definition | 9 | `P4.1.b.outside` | `P4.1.b.off` | equivalent |
| `P4.1.c` | definition | 9 | `P4.1.c` | `P4.1.c` | equivalent |
| `P4.1.quasiperiod` | proof_step | 9 | `P4.1.quasiperiod` | `P4.1.quasiperiod` | equivalent |
| `P4.1.reflection.odd` | proof_step | 9 | `P4.1.reflection.odd` | `P4.1.reflection.odd` | equivalent |
| `P4.1.reflection.affine` | proof_step | 9 | `P4.1.reflection.affine` | `P4.1.reflection.affine` | equivalent |
| `P4.1.C0.firstcolumn` | proof_step | 9 | `P4.1.C0.firstcolumn` | `P4.1.C0.first` | equivalent |
| `P4.1.C0.restcolumns` | proof_step | 9 | `P4.1.C0.restcolumns` | `P4.1.C0.rest` | equivalent |
| `P4.1.C0.kernel` | proof_step | 9 | `P4.1.C0.kernel` | `P4.1.C0.kernel` | component_of |
| `P4.1.BC.firstcolumn` | proof_step | 9 | `P4.1.BC.firstcolumn` | `P4.1.BC.first` | equivalent |
| `P4.1.BC.restcolumns` | proof_step | 9 | `P4.1.BC.restcolumns` | `P4.1.BC.rest` | equivalent |
| `P4.1.BC.kernel` | proof_step | 9 | `P4.1.BC.kernel` | `P4.1.BC.kernel` | equivalent |
| `P4.1.residues.disjoint` | proof_step | 9 | `P4.1.residues.disjoint` | `P4.1.block` | component_of |
| `P4.1.CI.entries` | proof_step | 9 | `P4.1.CI.entries` | `P4.1.block` | component_of |
| `P4.1.CI.det` | proof_step | 9 | `P4.1.CI.det` | `P4.1.block` | component_of |
| `P4.1.A` | definition | 9 | `P4.1.A` | `P4.1.A` | equivalent |
| `P4.1.pairing` | proof_step | 9 | `P4.1.pairing` | `P4.1.pairing` | equivalent |
| `P4.1.sign.C0` | proof_step | 9 | `P4.1.sign.C0` | `P4.1.weight.C0` | equivalent |
| `P4.1.det.C0` | proof_step | 9 | `P4.1.det.C0` | `P4.1.normalization` | component_of |
| `P4.1.C0.result` | statement | 9 | `P4.1.C0.result` | `P4.1.C0` | equivalent |
| `P4.1.sign.BC` | proof_step | 9 | `P4.1.sign.BC` | `P4.1.weight.BC` | component_of |
| `P4.1.det.BC` | proof_step | 9 | `P4.1.det.BC` | `P4.1.normalization` | component_of |
| `P4.1.BC.result` | statement | 9 | `P4.1.BC.result` | `P4.1.BC` | equivalent |
| `P4.2.K.B0` | definition | 9 | `P4.2.K.B0` | `P4.2.K.B0` | equivalent |
| `P4.2.K.Bminus` | definition | 9 | `P4.2.K.Bminus` | `P4.2.K.Bminus` | equivalent |
| `P4.2.b.residue` | definition | 9 | `P4.2.b.residue` | `P4.2.b.support` | equivalent |
| `P4.2.b.outside` | definition | 9 | `P4.2.b.outside` | `P4.2.b.off` | equivalent |
| `P4.2.gamma` | definition | 9 | `P4.2.gamma` | `P4.2.gamma` | equivalent |
| `P4.2.quasiperiod` | proof_step | 10 | `P4.2.quasiperiod` | `P4.2.quasiperiod` | equivalent |
| `P4.2.reflection.finite` | proof_step | 10 | `P4.2.reflection.finite` | `P4.2.reflection.shift` | equivalent |
| `P4.2.reflection.affine` | proof_step | 10 | `P4.2.reflection.affine` | `P4.2.reflection.affine`, `P4.2.parity.sign` | component_of |
| `P4.2.reflection.factor` | proof_step | 10 | `P4.2.reflection.factor` | `P4.2.parity.sign` | component_of |
| `P4.2.B0.firstcolumn` | proof_step | 10 | `P4.2.B0.firstcolumn` | `P4.2.B0.first` | equivalent |
| `P4.2.B0.restcolumns` | proof_step | 10 | `P4.2.B0.restcolumns` | `P4.2.B0.rest` | equivalent |
| `P4.2.Bminus.columns` | proof_step | 10 | `P4.2.Bminus.columns` | `P4.2.Bminus.columns` | equivalent |
| `P4.2.kernel.B0` | proof_step | 10 | `P4.2.kernel.B0` | `P4.2.kernel` | component_of |
| `P4.2.kernel.Bminus` | proof_step | 10 | `P4.2.kernel.Bminus` | `P4.2.kernel` | component_of |
| `P4.2.CI.direct` | proof_step | 10 | `P4.2.CI.direct` | `P4.2.block.direct` | component_of |
| `P4.2.CI.reflected` | proof_step | 10 | `P4.2.CI.reflected` | `P4.2.block.direct` | component_of |
| `P4.2.CI.entries` | proof_step | 10 | `P4.2.CI.entries` | `P4.2.block` | component_of |
| `P4.2.CI.det` | proof_step | 10 | `P4.2.CI.det` | `P4.2.block` | component_of |
| `P4.2.A` | definition | 10 | `P4.2.A` | `P4.2.pairing` | component_of |
| `P4.2.pairing` | proof_step | 10 | `P4.2.pairing` | `P4.2.pairing` | component_of |
| `P4.2.sign.B0` | proof_step | 10 | `P4.2.sign.B0` | `P4.2.weight.B0` | component_of |
| `P4.2.det.B0` | proof_step | 10 | `P4.2.det.B0` | `P4.2.normalization` | component_of |
| `P4.2.B0.result` | statement | 9 | `P4.2.B0.result` | `P4.2.B0` | equivalent |
| `P4.2.sign.Bminus` | proof_step | 10 | `P4.2.sign.Bminus` | `P4.2.weight.Bminus` | component_of |
| `P4.2.det.Bminus` | proof_step | 10 | `P4.2.det.Bminus` | `P4.2.normalization` | component_of |
| `P4.2.Bminus.result` | statement | 9 | `P4.2.Bminus.result` | `P4.2.Bminus` | equivalent |
| `P5.1.K` | definition | 10 | `P5.1.K` | `P5.1.K` | equivalent |
| `P5.1.b.residue` | definition | 10 | `P5.1.b.residue` | `P5.1.b.support` | equivalent |
| `P5.1.b.outside` | definition | 10 | `P5.1.b.outside` | `P5.1.b.off` | equivalent |
| `P5.1.c` | definition | 10 | `P5.1.c` | `P5.1.c` | equivalent |
| `P5.1.quasiperiod` | proof_step | 10 | `P5.1.quasiperiod` | `P5.1.quasiperiod` | equivalent |
| `P5.1.reflection.odd` | proof_step | 10 | `P5.1.reflection.odd` | `P5.1.reflection.odd` | equivalent |
| `P5.1.reflection.affine` | proof_step | 10 | `P5.1.reflection.affine` | `P5.1.reflection.affine` | equivalent |
| `P5.1.column` | proof_step | 10 | `P5.1.column` | `P5.1.kernel` | component_of |
| `P5.1.kernel` | proof_step | 10 | `P5.1.kernel` | `P5.1.kernel` | component_of |
| `P5.1.fixed.residue` | proof_step | 10 | `P5.1.fixed.residue` | `P5.1.fixed.residue` | equivalent |
| `P5.1.nonfixed.residue` | proof_step | 11 | `P5.1.nonfixed.residue` | `P5.1.block` | component_of |
| `P5.1.CI.entries` | proof_step | 11 | `P5.1.CI.entries` | `P5.1.block` | component_of |
| `P5.1.CI.det` | proof_step | 11 | `P5.1.CI.det` | `P5.1.block` | component_of |
| `P5.1.a` | definition | 11 | `P5.1.a` | `P5.1.a` | equivalent |
| `P5.1.Aplus` | definition | 11 | `P5.1.Aplus` | `P5.1.Aplus` | equivalent |
| `P5.1.Aminus` | definition | 11 | `P5.1.Aminus` | `P5.1.Aminus` | equivalent |
| `P5.1.pairing` | proof_step | 11 | `P5.1.pairing` | `P5.1.pairing` | equivalent |
| `P5.1.halfdet` | proof_step | 11 | `P5.1.halfdet` | `P5.1.half.det`, `P5.1.even.lattice` | component_of |
| `P5.1.parity.projector` | proof_step | 11 | `P5.1.parity.projector` |  | source_only |
| `P5.1.parity.det` | proof_step | 11 | `P5.1.parity.det` | `P5.1.parity.projector` | equivalent |
| `P5.1.lastcolumn.exponent` | proof_step | 11 | `P5.1.lastcolumn.exponent` | `P5.1.involution.exponent` | component_of |
| `P5.1.lastcolumn.argument` | proof_step | 11 | `P5.1.lastcolumn.argument` | `P5.1.involution.exponent` | component_of |
| `P5.1.lastcolumn.antisymmetry` | proof_step | 11 | `P5.1.lastcolumn.antisymmetry` | `P5.1.involution.sign` | component_of |
| `P5.1.lastcolumn.zero` | proof_step | 11 | `P5.1.lastcolumn.zero` | `P5.1.involution.sign`, `P5.1.even.lattice` | component_of |
| `P5.1.result` | statement | 10 | `P5.1.result` | `P5.1.identity`, `P5.1.even.lattice` | component_of |
| `L5.2.b.residue` | definition | 11 | `L5.2.b.residue` | `DEF.shared.b.support` | equivalent |
| `L5.2.b.outside` | definition | 11 | `L5.2.b.outside` | `DEF.shared.b.off` | equivalent |
| `L5.2.Gamma` | definition | 11 | `L5.2.Gamma` | `DEF.shared.Gamma` | equivalent |
| `L5.2.quasiperiod` | statement | 11 | `L5.2.quasiperiod` | `L5.2.quasiperiod` | equivalent |
| `L5.2.symmetry` | statement | 11 | `L5.2.symmetry` | `L5.2.center.symmetry` | equivalent |
| `L5.2.reflection` | statement | 11 | `L5.2.reflection` | `L5.2.affine.reflection` | equivalent |
| `L5.2.fixedcenter` | statement | 11 | `L5.2.fixedcenter` | `L5.2.fixed.zero` | equivalent |
| `L5.2.shift.reflected` | proof_step | 11 | `L5.2.shift.reflected` | `L5.2.shift.right` | equivalent |
| `L5.2.shift.backward` | proof_step | 11 | `L5.2.shift.backward` | `L5.2.shift.left` | equivalent |
| `P5.3.C` | definition | 12 | `P5.3.C` | `P5.3.C` | equivalent |
| `P5.3.center.eval` | proof_step | 12 | `P5.3.center.eval` | `P5.3.center` | equivalent |
| `P5.3.bracket.eval` | proof_step | 12 | `P5.3.bracket.eval` | `P5.3.bracket.eval` | component_of |
| `P5.3.firstcolumn` | proof_step | 12 | `P5.3.firstcolumn` | `P5.3.first.column` | equivalent |
| `P5.3.restcolumns` | proof_step | 12 | `P5.3.restcolumns` | `P5.3.rest.columns` | equivalent |
| `P5.3.kernel` | proof_step | 12 | `P5.3.kernel` | `P5.3.kernel` | equivalent |
| `P5.3.CI.center` | proof_step | 12 | `P5.3.CI.center` | `P5.3.block.center` | equivalent |
| `P5.3.CI.direct` | proof_step | 12 | `P5.3.CI.direct` | `P5.3.block.rest` | component_of |
| `P5.3.CI.reflected` | proof_step | 12 | `P5.3.CI.reflected` | `P5.3.block.rest` | component_of |
| `P5.3.CI.entries` | proof_step | 12 | `P5.3.CI.entries` | `P5.3.block` | component_of |
| `P5.3.CI.det` | proof_step | 12 | `P5.3.CI.det` | `P5.3.block` | component_of |
| `P5.3.doubling.location` | proof_step | 12 | `P5.3.doubling.location` | `P5.3.doubling.source` | equivalent |
| `P5.3.A` | definition | 12 | `P5.3.A` | `P5.3.pairing` | component_of |
| `P5.3.pairing` | proof_step | 12 | `P5.3.pairing` | `P5.3.pairing` | component_of |
| `P5.3.pairing.center.once` | proof_step | 12 | `P5.3.pairing.center.once` | `P5.3.pairing` | component_of |
| `P5.3.halfdet` | proof_step | 12 | `P5.3.halfdet` | `P5.3.normalization` | component_of |
| `P5.3.result` | statement | 12 | `P5.3.result` | `P5.3.identity`, `P5.3.normalization` | component_of |
| `Bt.hhat.sum` | statement | 12 | `Bt.hhat.sum` | `KERNEL.hhat.shift` | equivalent |
| `L5.4.a` | definition | 12 | `L5.4.a` | `DEF.adjacent.a` | equivalent |
| `L5.4.c` | definition | 12 | `L5.4.c` | `DEF.adjacent.c` | equivalent |
| `L5.4.gamma` | definition | 12 | `L5.4.gamma` | `DEF.adjacent.gamma` | equivalent |
| `L5.4.a.support` | proof_step | 12 | `L5.4.a.support` | `ADJACENT.support` | equivalent |
| `L5.4.c.symmetry` | proof_step | 12 | `L5.4.c.symmetry` | `ADJACENT.shift.symmetry` | equivalent |
| `L5.4.5.3` | statement | 12 | `L5.4.5.3` | `L5.4.5.3` | equivalent |
| `L5.4.5.4` | statement | 12 | `L5.4.5.4` | `L5.4.5.4` | equivalent |
| `L5.4.5.5` | statement | 12 | `L5.4.5.5` | `L5.4.5.5` | equivalent |
| `L5.4.fixedcenter` | statement | 12 | `L5.4.fixedcenter` | `L5.4.fixed.zero` | equivalent |
| `L5.4.reflection.expanded` | proof_step | 12 | `L5.4.reflection.expanded` | `L5.4.reflection.proof` | equivalent |
| `P5.5.C` | definition | 13 | `P5.5.C` | `P5.5.C` | equivalent |
| `P5.5.firstcolumn` | proof_step | 13 | `P5.5.firstcolumn` | `P5.5.first.column` | equivalent |
| `P5.5.restcolumns` | proof_step | 13 | `P5.5.restcolumns` | `P5.5.rest.columns` | equivalent |
| `P5.5.kernel` | proof_step | 13 | `P5.5.kernel` | `P5.5.kernel` | equivalent |
| `P5.5.CI.direct` | proof_step | 13 | `P5.5.CI.direct` | `P5.5.block.a.direct` | equivalent |
| `P5.5.CI.reflected` | proof_step | 13 | `P5.5.CI.reflected` | `P5.5.block.a.reflected` | equivalent |
| `P5.5.CI.entries` | proof_step | 13 | `P5.5.CI.entries` | `P5.5.block.entries` | equivalent |
| `P5.5.CI.bidiagonal` | proof_step | 13 | `P5.5.CI.bidiagonal` | `P5.5.block.triangular` | component_of |
| `P5.5.CI.det` | proof_step | 13 | `P5.5.CI.det` | `P5.5.block.triangular` | component_of |
| `P5.5.DJ.undoubled` | proof_step | 13 | `P5.5.DJ.undoubled` | `P5.5.no.D.doubling` | component_of |
| `P5.5.pairing.m` | proof_step | 13 | `P5.5.pairing.m` | `P5.5.pairing.unfold` | equivalent |
| `P5.5.pairing.y` | proof_step | 13 | `P5.5.pairing.y` | `P5.5.pairing.shift` | equivalent |
| `P5.5.A` | definition | 13 | `P5.5.A` | `P5.5.pairing.hhat` | component_of |
| `P5.5.pairing.hhat` | proof_step | 13 | `P5.5.pairing.hhat` | `P5.5.pairing.hhat` | component_of |
| `P5.5.halfdet` | proof_step | 13 | `P5.5.halfdet` | `P5.5.normalization` | component_of |
| `P5.5.result` | statement | 13 | `P5.5.result` | `P5.5.identity`, `P5.5.normalization` | component_of |
| `P6.1.C0` | statement | 13 | `P6.1.C0` | `P6.1.C0` | equivalent |
| `P6.1.Ct` | statement | 13 | `P6.1.Ct` | `P6.1.Ct` | equivalent |
| `P6.1.BC` | statement | 13 | `P6.1.BC` | `P6.1.BC` | equivalent |
| `P6.1.B0` | statement | 13 | `P6.1.B0` | `P6.1.B0` | equivalent |
| `P6.1.Bminus` | statement | 13 | `P6.1.Bminus` | `P6.1.Bminus` | equivalent |
| `P6.1.Bplus` | statement | 13 | `P6.1.Bplus` | `P6.1.Bplus` | equivalent |
| `P6.1.Bt` | statement | 13 | `P6.1.Bt` | `P6.1.Bt` | equivalent |
| `P6.1.finite.ratio` | proof_step | 13 | `P6.1.finite.ratio` | `P6.1.finite.zero` | equivalent |
| `P6.1.triangular` | proof_step | 13 | `P6.1.triangular` | `P6.1.triangular` | equivalent |
| `P6.1.diagonal.C0` | proof_step | 14 | `P6.1.diagonal.C0` | `P6.1.diagonal.C0` | component_of |
| `P6.1.product.C0` | proof_step | 14 | `P6.1.product.C0` | `P6.1.diagonal.C0` | component_of |
| `P6.1.diagonal.BC` | proof_step | 14 | `P6.1.diagonal.BC` | `P6.1.diagonal.BC` | component_of |
| `P6.1.product.BC` | proof_step | 14 | `P6.1.product.BC` | `P6.1.diagonal.BC` | component_of |
| `P6.1.diagonal.B0` | proof_step | 14 | `P6.1.diagonal.B0` | `P6.1.diagonal.B0` | component_of |
| `P6.1.product.B0` | proof_step | 14 | `P6.1.product.B0` | `P6.1.diagonal.B0` | component_of |
| `P6.1.diagonal.Ct` | proof_step | 14 | `P6.1.diagonal.Ct` | `P6.1.diagonal.Ct` | component_of |
| `P6.1.product.Ct` | proof_step | 14 | `P6.1.product.Ct` | `P6.1.diagonal.Ct` | component_of |
| `P6.1.diagonal.Bt` | proof_step | 14 | `P6.1.diagonal.Bt` | `P6.1.diagonal.Bt` | component_of |
| `P6.1.product.Bt` | proof_step | 14 | `P6.1.product.Bt` | `P6.1.diagonal.Bt` | component_of |
| `P6.1.diagonal.Bminus` | proof_step | 14 | `P6.1.diagonal.Bminus` | `P6.1.diagonal.Bminus` | component_of |
| `P6.1.product.Bminus` | proof_step | 14 | `P6.1.product.Bminus` | `P6.1.diagonal.Bminus` | component_of |
| `P6.1.diagonal.Bplus` | proof_step | 14 | `P6.1.diagonal.Bplus` | `P6.1.diagonal.Bplus` | component_of |
| `P6.1.product.Bplus` | proof_step | 14 | `P6.1.product.Bplus` | `P6.1.diagonal.Bplus` | component_of |
| `P6.1.Bt.firstcolumn` | proof_step | 14 | `P6.1.Bt.firstcolumn` | `P6.1.Bt.first` | equivalent |
| `P6.1.Bt.restcolumns` | proof_step | 14 | `P6.1.Bt.restcolumns` | `P6.1.Bt.rest` | equivalent |
| `P6.1.BC.firstcolumn` | proof_step | 14 | `P6.1.BC.firstcolumn` | `P6.1.BC.first` | equivalent |
| `P6.1.BC.restcolumns` | proof_step | 14 | `P6.1.BC.restcolumns` | `P6.1.BC.rest` | equivalent |
| `P6.1.Bplus.center` | proof_step | 14 | `P6.1.Bplus.center` | `P6.1.Bplus.center` | equivalent |
| `P6.1.extend.B0` | statement | 13 | `P6.1.extend.B0` | `P6.1.A.endpoints`, `P6.1.empty.affine` | component_of |
| `P6.1.extend.Bminus` | statement | 13 | `P6.1.extend.Bminus` | `P6.1.A.endpoints`, `P6.1.empty.affine` | component_of |
| `P6.1.extend.C0` | statement | 13 | `P6.1.extend.C0` | `P6.1.A.endpoints`, `P6.1.empty.affine` | component_of |
| `P6.1.extend.Ct` | statement | 13 | `P6.1.extend.Ct` | `P6.1.A.endpoints`, `P6.1.empty.affine` | component_of |
| `P6.1.extend.BC` | statement | 13 | `P6.1.extend.BC` | `P6.1.A.endpoints`, `P6.1.empty.affine` | component_of |
| `CONV.cancel.before.specialize` | convention | 14 | `CONV.cancel.before.specialize` | `P6.1.rational.cancellation` | component_of |
| `C6.2.6.1` | statement | 14 | `C6.2.6.1` | `C6.2.6.1` | equivalent |
| `C6.2.6.2.h` | statement | 14 | `C6.2.6.2.h` | `C6.2.6.2.dot` | equivalent |
| `C6.2.6.2.hhat` | statement | 14 | `C6.2.6.2.hhat` | `C6.2.6.2.ddot` | equivalent |
| `C6.2.6.3` | statement | 14 | `C6.2.6.3` | `C6.2.6.3` | equivalent |
| `C6.2.columns.C0` | proof_step | 15 | `C6.2.columns.C0` | `C6.2.columns.zero` | component_of |
| `C6.2.specialization.C0` | statement | 14 | `C6.2.specialization.C0` | `C6.2.specialize.C0` | equivalent |
| `C6.2.columns.Ct` | proof_step | 15 | `C6.2.columns.Ct` | `C6.2.columns.zero` | component_of |
| `C6.2.specialization.Ct` | statement | 14 | `C6.2.specialization.Ct` | `C6.2.specialize.Ct` | equivalent |
| `C6.2.columns.BC` | proof_step | 15 | `C6.2.columns.BC` | `C6.2.columns.zero` | component_of |
| `C6.2.specialization.BC` | statement | 14 | `C6.2.specialization.BC` | `C6.2.specialize.BC` | equivalent |
| `C6.2.columns.B0` | proof_step | 15 | `C6.2.columns.B0` | `C6.2.columns.zero` | component_of |
| `C6.2.specialization.B0` | statement | 14 | `C6.2.specialization.B0` | `C6.2.specialize.B0` | equivalent |
| `C6.2.columns.Bminus` | proof_step | 15 | `C6.2.columns.Bminus` | `C6.2.columns.zero` | component_of |
| `C6.2.specialization.Bminus` | statement | 14 | `C6.2.specialization.Bminus` | `C6.2.specialize.Bminus` | equivalent |
| `C6.2.columns.Bt` | proof_step | 15 | `C6.2.columns.Bt` | `C6.2.columns.zero` | component_of |
| `C6.2.specialization.Bt` | statement | 14 | `C6.2.specialization.Bt` | `C6.2.specialize.Bt` | equivalent |
| `C6.2.columns.Bplus` | proof_step | 15 | `C6.2.columns.Bplus` | `C6.2.columns.zero` | component_of |
| `C6.2.specialization.Bplus` | statement | 14 | `C6.2.specialization.Bplus` | `C6.2.specialize.Bplus` | equivalent |
| `C6.2.nonzero.shift.C0` | proof_step | 15 | `C6.2.nonzero.shift.C0` | `C6.2.nonzero.shifts.C0` | equivalent |
| `C6.2.nonzero.shift.B0` | proof_step | 15 | `C6.2.nonzero.shift.B0` | `C6.2.nonzero.shifts.B0` | equivalent |
| `C6.2.nonzero.shift.Bplus` | proof_step | 15 | `C6.2.nonzero.shift.Bplus` | `C6.2.nonzero.shifts.Bplus` | equivalent |
| `C6.2.nonzero.shift.Bt` | proof_step | 15 | `C6.2.nonzero.shift.Bt` | `C6.2.nonzero.shifts.Bt` | equivalent |
| `C6.2.Ct.exception` | proof_step | 15 | `C6.2.Ct.exception` | `C6.2.Ct.exception` | equivalent |
| `C6.2.Ct.route` | proof_step | 15 | `C6.2.Ct.route` | `C6.2.Ct.parity` | equivalent |
| `COEFF.endpoints` | proof_step | 1 |  | `COEFF.endpoints` | source_only |
| `KERNEL.Lambda.center` | proof_step | 8 |  | `KERNEL.Lambda.center` | source_only |
| `L3.3.pairing.C` | proof_step | 8 |  | `L3.3.pairing.C` | source_only |
| `L3.3.pairing.B` | proof_step | 8 |  | `L3.3.pairing.B` | source_only |
| `L5.2.shift.proof` | proof_step | 11 |  | `L5.2.shift.proof` | source_only |
| `L5.2.reflection.proof` | proof_step | 11 |  | `L5.2.reflection.proof` | source_only |
| `L5.4.expansion` | proof_step | 12 |  | `L5.4.expansion` | source_only |
| `P5.5.bracket.eval` | proof_step | 13 |  | `P5.5.bracket.eval` | source_only |
| `SYMMETRIZER.proof` | proof_step | 3 |  | `WEYL.symmetrizer.recurrence` | source_only |
| `T3.1.rank.YZ` | proof_step | 6 |  | `T3.1.ranks` | source_only |
| `L3.3.pairing.plus.partition` | proof_step | 8 |  | `L3.3.pairing.plus` | source_only |
| `P4.1.BC.tau.weight` | proof_step | 9 |  | `P4.1.weight.BC` | source_only |
| `P4.2.Bminus.tau.weight` | proof_step | 10 |  | `P4.2.weight.Bminus` | source_only |

## 验收结果

- A/B 原始 atom ID 均存在、均唯一；全量集合覆盖率分别为100%。
- canonical ID 全部唯一；每条至少一侧非空，条内没有重复 atom 引用。
- canonical route 已转为存在的 canonical ID；A 的原始叙述性 route 在 JSON 报告完整保留。
- 每条有冻结原文 hash、页码和定位；没有依赖其他审计结果。
- 所有输入 hash 在生成后复验不变；全部 declarations 暂为空。
- 未解决规范争议：0。

此结论只认证规范与原文的对齐；不认证任何 Lean 实现、声明覆盖或证明通过。
