# Lean-only 数学逆向还原

审阅者：`/root/lean_reverse`，独立、全新上下文。仅读取本报告输入清单的三个 packet 文件。未读取论文、规范、Lean 源码、README 或其他代理结论。本报告说明 Lean 实际表达及声明覆盖范围，不给出论文语义忠实性结论。

## 输入与覆盖

原环境 `fidelity/runs/implementation-export/environment.json` 的 SHA256 为 `bb40867d389b3c2f430e59596fafa479e085e4b396bf45c23949f81143cd6165`，该路径与哈希来自 packet，原文件未读取。过滤后 packet 环境 SHA256 为 `75f647e067cab5c38ae1def4de6ce5be712b41e2ecdbaaff0b6474d25cea0fd0`。全部 2140 条声明的完整 `type` UTF-8 SHA256 均与导出 `type_hash` 一致；86 个 module 与全部 namespace 的声明 ID 索引保存在 JSON。

297 条 `AffineDualJT.paper_` 前缀声明已全部保留完整类型及哈希；其中排除编译辅助项有 211 条公共数学入口，50 条是最终 `paper_theorem/prop/lemma/cor`。这 50 条逐项审读，其类型与定义闭包共 80 个项目声明；所有 211 条公共 `paper_` 的类型/对象闭包共 356 个项目声明，其中 109 个有定义体。完整定义体、项目依赖和逐条类型均原样放入 JSON；类型/定义的人工解释范围和其余未逐项解释的 ID 分别列在 coverage 中。定理证明体在导出中是 `definition=null`，没有把证明常量依赖当作完整证明项审查。

导出中所有 axiom 名称的并集只有 `Classical.choice`、`Quot.sound`、`propext`；不存在未收录的 `AffineDualJT.*` 类型/值依赖。这里未重新运行编译，亦不认证编译器或导出器。

## 下标与系数对象

所有 `Fin k` 下标零基；`paperIndex(i)=(i.val:ℤ)+1`。以下将其写成 `I=i+1`、`J=j+1`；宽度 `k`、变量数 `n` 均为自然数。核的自变量及仿射求和变量是整数。

`CoeffSystem R n` 只需交换环，含整数系数 `eDot,eDdot` 和七项证明字段：分别在 `[0,2n]`、`[0,2n+1]` 外为零；`eDot(2n-r)=eDot(r)`、`eDdot(2n+1-r)=eDdot(r)`；`eDdot(r)=eDot(r)+eDot(r-1)`。它没有常数项为 1 的字段。经典实例由

\[
 E(T)=\prod_{a\in\mathrm{Fin}(n)}(1+x_aT)(1+x_a^{-1}T),\qquad \ddot E(T)=(1+T)E(T)
\]

构造。`intCoeff(P,r)` 对负整数取 0，否则取 `P.coeff(r.toNat)`。

\[
\begin{aligned}
h_i(m)&=e_{n-I+m}+e_{n+I+m-1},\\
h_i^+(m)&=e_{n-I+m}+e_{n+I+m-2},\\
\widehat h_i(m)&=\ddot e_{n-I+m}+\ddot e_{n+I+m-1},\\
\lambda_i(m)&=e_{n-I+m}-e_{n+I+m}.
\end{aligned}
\]

这些核每行均有有限支撑。公开关系含 `h(1-m)=h(m)`、`hPlus(2-m)=hPlus(m)`、`lambda(-m)=-lambda(m)`、`lambda(0)=0`、`hHat(m)=h(m)+h(m-1)`。对 `h,hPlus,lambda`，`m>n+k` 时取 0。整数下标不使用自然数截断。

## JK、JKEven 与有限性

精确矩阵项是

\[
 M(y)_{ij}=w_j(y_i)\,F_i(J-Ky_i),\qquad y:\mathrm{Fin}(k)\to\mathbb Z.
\]

因此 `JK(K,w,F)=∑ᶠ_y det M(y)`；`JKEven` 用内层对命题的 `finsum` 保留满足 `Even(∑i y_i)` 的向量。它要求分量**总和**偶数。`JKOn` 同样以任意谓词 `L(y)` 过滤。

这是代数 `finsum`，没有解析收敛含义。定义本身允许任意整数 `K`；当 `K≠0` 且各 `F_i` 有有限支撑时，`weighted_shift_hasFiniteSupport` 与 `jkMatrix_det_hasFiniteSupport` 证明权移函数和行列式项都有有限支撑。`det_finsum_eq_JK` 在同样条件下给出

\[
\det_{ij}\Big(\sum_y^f w_j(y)F_i(J-Ky)\Big)=JK(K,w,F).
\]

`k=0` 时空行列式为 1，`JK=JKEven=1`，包括 `K=0`。没有把正宽度有限性中 `K≠0` 推广到任意 `K`。

`JKEven_projector` 需 `[Field F] [CharZero F]`、`K≠0`、核各行有限支撑，结论为

\[
 JKEven(K,w,f)=\tfrac12\{JK(K,w,f)+JK(K,(-1)^y w,f)\}.
\]

## Weyl 求和及七种对象

`x:Fin n→Fˣ`，所以所有变量自带非零性。令 `u_a=x_a^{-1}` 当 `η_a=true`，否则 `u_a=x_a`。置换作用是 `weylVariables(x,σ,η,a)=u_{σ(a)}`。定义的被加项为

\[
 S(q,k,\rho;u)=\prod_a u_a^{-k}\rho(u_a)\prod_{a<b}
 \frac{(q u_a-u_b)(1-q u_a u_b)}{(u_a-u_b)(1-u_a u_b)}.
\]

`weylSum` 对全部 `σ∈Perm(Fin n)` 和全部 `η:Fin n→Bool` 作有限和，再除以 `V_n(q)ν`，其中

\[
 V_n(q)=\prod_{r=0}^{n-1}\sum_{l=0}^{r}q^l.
\]

`Admissible(x,q,ν)` 是结构，四个字段逐项为：`V_n(q)ν≠0`；对所有 `η`、`a≠b`，`u_a-u_b≠0`；同样范围 `1-u_a u_b≠0`；对所有 `η,a`，`1-u_a²≠0`。`Field` 为必需类型类，`CharZero` 并非这个结构的字段。

| 对象 | q | rho(z) | ν |
|---|---:|---|---|
| B0 | t | 1/(1-z) | 1 |
| BC | τ² | (1+τz)/(1-z²) | 1 |
| Bminus | τ² | (1+τz)/(1-z) | νBminus |
| Bplus | t | 1 | νBplus |
| Bt | t | (1-tz)/(1-z) | νCt |
| C0 | t | 1/(1-z²) | 1 |
| Ct | t | (1-tz²)/(1-z²) | νCt |

`(a;q)_n=∏_(r=0)^(n-1)(1-aq^r)`。三种 ν 在 `k>0` 时均为 1；在 `k=0` 时分别是 `(τ;τ²)_n`、`(-1;t)_n`、`(-t;t)_n`。`Bt` 确实使用 `νCt`。

`reducedWeyl` 仅保留取逆选择 η 的和，并去掉上式 `(q u_a-u_b)/(u_a-u_b)` 部分。七个 `Red*` 将表中 q、rho 代入它，不除以 ν。`weylSum_eq_reducedWeyl` 需 `[Field F] [CharZero F]` 和 `Admissible(x,q,ν)`，结论是 `weylSum=reducedWeyl/ν`。

## 固定有理函数域与一般域前提

`PaperField n=FractionRing(MvPolynomial(Fin(n+1)) ℚ)`。`paperVariable a` 是独立不定元 `X_a` 在分式域中的像；`paperParameter=X_0`；`paperVariables n a` 是 `X_(a+1)` 对应的单位。故参数和变量并非任意实数、复数或可独立自由指定的域元素。

`paper_admissible`、`paper_admissible_squared`、带三种 ν 的版本以及参数零版本，均在这个固定域中证明对应 `Admissible`；另有三个 Δ 与 `Nt(1,x)` 非零声明。固定域天然带特征零结构，因此最终 `paper_*` 中没有显示 `Field/CharZero/Admissible` 并不表示通用版本无需这些条件。

一般域最终 `theorem_A/B` 统一有 `{F:Type u} [Field F] [CharZero F] {n k:ℕ}`、`x:Fin n→Fˣ`、域参数，并要求 `n>0`、对应 `Δ≠0`、对应 `Admissible`。`Bplus` 和 `Bt` 的半系数公式另要求 `k>0`。Bminus 用 `Admissible(x,τ²,νBminus(n,k,τ))`，Ct 用 `Admissible(x,t,νCt(n,k,t))`，其余为表中 q 和 ν=1。全部完整隐式绑定、前提和 pp.all 类型逐条保存在 JSON。内部 `ordinary_BC_identity`、`ordinary_Bminus_identity` 只要 `[Field F]`；Section4 包装和最终 ExternalHL 桥接声明仍显式带 `CharZero`，没有将内部较弱条件替换成公开最终声明的范围。

## 最终仿射公式的精确范围

以下在固定 `PaperField n`，`x=paperVariables n`、参数 `t/τ=paperParameter n`、`c=classicalCoefficients x`。除表中额外条件，主定理均要求 `n>0`。

| paper 入口 | 左端 | 右端 | 额外宽度条件 |
|---|---|---|---|
| theorem_A_1_3 | B0 | JK(2k+1, (-1)^y t^(((2k+1)y²-(2J-1)y)/2), h) | 无 |
| theorem_A_1_4 | Bminus | JK(2k, τ^(2ky²-(2J-1)y), h) | 无 |
| theorem_A_1_5 | Bplus | 1/2 JK(2k, (-1)^y t^(ky²-(J-1)y), hPlus) | k>0 |
| theorem_A_1_6 | C0 | JK(2k+2, t^((k+1)y²-Jy), lambda) | 无 |
| theorem_A_1_7 | Ct | JKEven(2k, t^(ky²-Jy), lambda) | 无 |
| theorem_A_1_8 | BC | JK(2k+1, (-1)^y τ^((2k+1)y²-2Jy), lambda) | 无 |
| theorem_B_1_9 | Bt | 1/2 JK(2k, (-1)^y t^(ky²-(J-1)y), hHat) | k>0 |

表中权重的 J 是 **列号 j+1**，而 `JK` 定义中 y 是对应行的 `y_i`；不能改成逐列向量。`paper_prop_4/5` 是相同右端但全部要求 `n>0,k>0`。七条 `paper_prop_2_2` 同样要求 `n>0,k>0`，给出 ExternalHL 等于 `det(Phi*V)/Delta`。八条 `paper_lemma_5_2/5_4` 是 `Gamma,bBplus,cBt,gammaBt` 的具体整数平移、反射及固定点关系，完整公式在后附入口清单中。

B0 的 `/2` 是 **整数除法**，不是域内有理指数；`B0_exponent_numerator_even` 和 `B0_exponent_exact` 对任意整数 k,j,y 证明整除，`B0_exponent_cast` 将它转到 ℚ 的半整数系数写法。所有七组权重最终指数均为整数，已证对 `j:Fin k` 和 `y:ℤ` 非负。

## Weyl 矩阵与有限列

`phi_m(z)=z^m-z^(-m)`、`psi_m(z)=z^m-z^(1-m)`、`Cfun_m(z)=z^m+z^(-m)`，指数均为 ℤ。`PhiC/PhiB` 第 p 列用 `phi_(p+1)/psi_(p+1)`；`PhiPlus` 第 0 列为 1，其余第 p 列用 `Cfun_p`。Δ 是相应 n×n 首 n 列行列式，`Nt(q,z)=∏_(a<b)(z_a-z_b)(1-qz_a z_b)`。

`bracketB(m,p)` 在 `m=P` 取1，在 `1-m=P` 取-1，其他0；`bracketC` 在 `m=P` 取1，在 `m=-P` 取-1，其他0，`P=p+1`。`bracketPlus(1,p)` 在 p=0 取2、其余0；m≠1 时，在 m=P 或 2-m=P 取1，其他0。首列常数1与中心括号2均为定义的一部分。

有限 V 的维数为 `(n+k)×n`。零基列号 r、整数括号参数下，`uS(r)` 的 r=0 分支是 `bracketS(k+1)`；r>0 分支是 `bracketS(k+r+1)+t^r bracketS(k+1-r)`；S=B,C,Plus。tilde 两种把括号下标各减1。VB0=uB，VC0=uC，VBplus=uPlus；VBC=uC(τ²)+τuCTilde(τ²)；VBt=uB(t)-t uBTilde(t)；VBminus=bracketB(k+r+1)+τ^(2r+1)bracketB(k-r)；VCt=bracketC(k+r+1)-t^(r+1)bracketC(k-r-1)。首列特殊分支防止多算同一项。

## T3.1 的实际命题

只要 `[Field F]`，任意 `n,k:ℕ`，矩阵维数为 `X:n×(n+k)`、`Y:(n+k)×n`、`U,Z:(n+k)×k`。假设

\[
 XU=0,\quad Y^T Z=0,\quad \det X_0\ne0,\quad\det U_{n:}\ne0,
 \quad\det Y_{k:}\ne0,\quad\det Z_{:k}\ne0.
\]

这里 X₀ 取 X 的前 n 列；U_(n:) 取 U 的行 n,…,n+k−1；Y_(k:) 取 Y 的行 k,…,k+n−1；Z_(:k) 取 Z 的前 k 行。两种尾块起点不可混同。结论为

\[
 \det(XY)=(-1)^{nk}\frac{\det X_0\det Y_{k:}}{\det U_{n:}\det Z_{:k}}\det(U^TZ).
\]

没有 `CharZero`、正宽度或额外秩参数；但四个指定子式非零均在前提中。`theorem_3_1_cleared` 虽清掉分母，仍保留四个非零前提。`normalized_transfer_3_1` 以 `det lastRowsY(V)=1` 替代该非零前提。

值常量依赖确实包含 `paper_cauchy_binet`、其 complement_sum、`paper_XU_finset_complement_relation` 和 `paper_YZ_finset_complement_relation`。Cauchy–Binet 的求和域是所有 **恰有 n 个元素** 的 `Fin l` 子集；补集版以 `Fin(n+k)` 的 n 元子集为索引，取其 k 元补集。子集均按递增顺序枚举。`paperEpsilon(Q)=(-1)^(∑r(q_r-r))`，`paperFinsetSplit` 先补集、后 Q；固定 split 是 Fin k⊕Fin n。两个商同构由 X、Yᵀ 诱导，分别从 `F^(n+k)/range U`、`F^(n+k)/range Z` 到 `F^n`，作用为 `[v]↦Xv`、`[v]↦Yᵀv`。公开商空间作用公式、互补子式比例关系及 top alternating form 关系全列于 JSON。

## alternant 及缩放辅助命题

对于零基 r∈Fin n，`fColumn` 在 r=0 为 `z^(n-1)`，在 r>0 为 `z^(n-r-1)+t^r z^(n+r-1)`；Ct 列是 `z^(n-r-1)-t^(r+1)z^(n+r+1)`；Bminus 列是 `z^(n-r-1)+τ^(2r+1)z^(n+r)`。此处幂指数是自然数，减法采用 Nat 截断，Fin n 范围保证数学上预期的非负性。

`lemma_2_1_eq_2_3/4/5` 在任意域和任意参数（包括零）下分别证明行列式是 `Nt(t,z)`、`∏a(1-t z_a²)Nt(t,z)`、`∏a(1+τz_a)Nt(τ²,z)`。没有 `CharZero` 或 z_a 非零要求。

导出的 `paper_*` 多项式 helper 所用 pairIndex 是 `Σa:Fin n,{b // a<b}`，card=n(n−1)/2；每对有差因子 X_a−X_b 和倒数因子 1−tX_aX_b；Bminus/Ct 再加入每行的 1+τX_a / 1−tX_a²。全积整除、两两互素及总次数等式的非零参数前提逐条保留。basic、Bminus、Ct 的次数上界分别为 `3C(n,2)`、`3C(n,2)+n`、`3C(n,2)+2n`。`PaperScaledPoly=Polynomial(MvPolynomial(Fin n)F)`，`paperScaleHom` 将每个 X_a 替为 sX_a；在 s 的次数 n(n−1)/2 的系数是下降 Vandermonde，确定标量商。零参数另有不带非零前提的 factorization_zero 声明。对应证明常量依赖可确认使用这些中间结果；无法据此声称匹配未知论文的证明路线。

## 零宽度与零参数

七条一般 `prop_6_1_*` 在相应 `Admissible`、`Field+CharZero` 下给出宽度0的 ExternalHL 对象等于1。七条 `paper_prop_6_1_*` 仍显式要求 n>0；两条最终 `paper_theorem_A_Bplus_width_zero`、`paper_theorem_B_Bt_width_zero` 对任意 n（包括0）成立。带半系数的主公式没有推广到 k=0；Lean 还证明 `2⁻¹≠1`。

Red 对象在 k=0 时并非全部等于1：B0、BC、C0 为1；Bminus 为 `(τ;τ²)_n`；Bplus 为 `(-1;t)_n`；Bt、Ct 为 `(-t;t)_n`，各需对应 Δ 非零。ExternalHL 的 ν 正是这些端点归一化的一部分。

参数零的七条 `paper_cor_6_2_*_zero` 都要求 n>0、k>0，给出 Weyl 商行列式；另五条 `paper_cor_6_2_eq_*` 给出该商与 k×k 核行列式的关系，包括 h 与 `(1/2)hHat`、Bplus 商与 `(1/2)hPlus`。全部绑定和公式后附。

Ct 不能把所有非零 y 的零参数权重直接删去：在 k>0、y≠0 时，`ky²-Jy=0` 当且仅当 J=k 且 y=1。`Ct_last_column_sum_zero`、`Ct_unsigned_JK_zero` 与偶投影给出参数零桥接。公开一般 Ct 零参数商声明另需 Field、CharZero、n>0、k>0、ΔC≠0、Admissible(x,0,1)。

`parameterJKPolynomial` 把权重替成常数系数乘 X 的自然数次幂。`eval_parameterJKPolynomial` 要 K≠0、每行核有限支撑。`polynomial_eval_zero_of_nonzero` 和 `reducedWeyl_eq_JK_zero_of_nonzero` 的零参数延拓需 `[Infinite F]`；后者另有 K≠0、d≠0、自然数指数函数与核有限支撑。独立的 `ordinary_BC_zero`、`ordinary_Bminus_zero` 已对任意域陈述，不能将辅助延拓的 Infinite 前提误算成它们的最终前提。

## 未决边界

没有论文比较证据，因此不作语义忠实性 pass。没有重跑 Lean，也未逐项取得 theorem 的证明体。标准库和 Mathlib 常量的定义未由此 packet 展开。复杂商同构的外延由公开 apply 声明确定，未把全部类型类与逆映射见证代码逐字校读。内部尚未逐项解释的完整 ID 在 JSON coverage 中公开列出；它们仍有精确类型、哈希和依赖索引。以下附件是机器从已获准 packet 提取的原样声明，不能将原样保存一概视作人工审阅。

## 实际读取文件

- `fidelity/packets/lean_reverse-20261030T172606Z-c8fef66f/PROMPT.txt` — `fea2ac523e7099222801fa4f766a4d3b8e910330b0f3c9e3a5816f5af717b1c9`
- `fidelity/packets/lean_reverse-20261030T172606Z-c8fef66f/manifest.json` — `ae2662d67e6517f80296c9b84bf42fb3381e340ccf16823c5bfce91f3e145637`
- `fidelity/packets/lean_reverse-20261030T172606Z-c8fef66f/implementation_environment.json` — `75f647e067cab5c38ae1def4de6ce5be712b41e2ecdbaaff0b6474d25cea0fd0`

## 50 个最终入口的完整编译声明

### `AffineDualJT.paper_cor_6_2_B0_zero`

SHA256 `feb1d850082e0a2004070964c84023861ea0625cc885e9cf70886cf84a042b21`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      AffineDualJT.ExternalHL.B0 (AffineDualJT.paperVariables n) 0 k =
        (Matrix.of fun a r =>
              AffineDualJT.psi (↑k + AffineDualJT.paperIndex r) ↑(AffineDualJT.paperVariables n a)).det /
          AffineDualJT.DeltaB (AffineDualJT.paperVariables n)
```

### `AffineDualJT.paper_cor_6_2_BC_zero`

SHA256 `289366b340a8ef74602d9f7f845a1c47f88c26b21be78cdbdcc28c31b83684d4`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      AffineDualJT.ExternalHL.BC (AffineDualJT.paperVariables n) 0 k =
        (Matrix.of fun a r =>
              AffineDualJT.phi (↑k + AffineDualJT.paperIndex r) ↑(AffineDualJT.paperVariables n a)).det /
          AffineDualJT.DeltaC (AffineDualJT.paperVariables n)
```

### `AffineDualJT.paper_cor_6_2_Bminus_zero`

SHA256 `bca9394a6728c37cdf1813abff8296b99c4755b20eb178debbcb047a416e7957`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      AffineDualJT.ExternalHL.Bminus (AffineDualJT.paperVariables n) 0 k =
        (Matrix.of fun a r =>
              AffineDualJT.psi (↑k + AffineDualJT.paperIndex r) ↑(AffineDualJT.paperVariables n a)).det /
          AffineDualJT.DeltaB (AffineDualJT.paperVariables n)
```

### `AffineDualJT.paper_cor_6_2_Bplus_zero`

SHA256 `421531377795f6f281819b0b2cc59fd507b0f00a0b1dde78d1c4d9c2dda91138`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      AffineDualJT.ExternalHL.Bplus (AffineDualJT.paperVariables n) 0 k =
        (Matrix.of fun a r =>
              AffineDualJT.Cfun (↑k + AffineDualJT.paperIndex r - 1) ↑(AffineDualJT.paperVariables n a)).det /
          AffineDualJT.DeltaPlus (AffineDualJT.paperVariables n)
```

### `AffineDualJT.paper_cor_6_2_Bt_zero`

SHA256 `d6b361d9dabb600e2edeabc9e33adf5f04655691effdccc531bc9ad306108975`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      AffineDualJT.ExternalHL.Bt (AffineDualJT.paperVariables n) 0 k =
        (Matrix.of fun a r =>
              AffineDualJT.psi (↑k + AffineDualJT.paperIndex r) ↑(AffineDualJT.paperVariables n a)).det /
          AffineDualJT.DeltaB (AffineDualJT.paperVariables n)
```

### `AffineDualJT.paper_cor_6_2_C0_zero`

SHA256 `f1cd1c666fbc6c7e8f7ff4a1e0c4c31adc8acbac0db1c3ff78d183070e759e5d`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      AffineDualJT.ExternalHL.C0 (AffineDualJT.paperVariables n) 0 k =
        (Matrix.of fun a r =>
              AffineDualJT.phi (↑k + AffineDualJT.paperIndex r) ↑(AffineDualJT.paperVariables n a)).det /
          AffineDualJT.DeltaC (AffineDualJT.paperVariables n)
```

### `AffineDualJT.paper_cor_6_2_Ct_zero`

SHA256 `b58d839ba65d326e29417a9ecec6fe1887647680a86fb1f875fbfc715c3aab3e`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      AffineDualJT.ExternalHL.Ct (AffineDualJT.paperVariables n) 0 k =
        (Matrix.of fun a r =>
              AffineDualJT.phi (↑k + AffineDualJT.paperIndex r) ↑(AffineDualJT.paperVariables n a)).det /
          AffineDualJT.DeltaC (AffineDualJT.paperVariables n)
```

### `AffineDualJT.paper_cor_6_2_eq_6_1`

SHA256 `7064f12717f3efd6c6493cb12c6cf66954b2e3790f15c64ff63b7d707de9b213`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      (Matrix.of fun a r => AffineDualJT.phi (↑k + AffineDualJT.paperIndex r) ↑(AffineDualJT.paperVariables n a)).det /
          AffineDualJT.DeltaC (AffineDualJT.paperVariables n) =
        Matrix.det fun i j =>
          AffineDualJT.lambdaKernel (AffineDualJT.classicalCoefficients (AffineDualJT.paperVariables n)) i
            (AffineDualJT.paperIndex j)
```

### `AffineDualJT.paper_cor_6_2_eq_6_2a`

SHA256 `3ecc74ca6c5b9fe36b496a772298eb20d641025bb52e5f33dbe6b6448ed4fb0c`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      (Matrix.of fun a r => AffineDualJT.psi (↑k + AffineDualJT.paperIndex r) ↑(AffineDualJT.paperVariables n a)).det /
          AffineDualJT.DeltaB (AffineDualJT.paperVariables n) =
        Matrix.det fun i j =>
          AffineDualJT.hKernel (AffineDualJT.classicalCoefficients (AffineDualJT.paperVariables n)) i
            (AffineDualJT.paperIndex j)
```

### `AffineDualJT.paper_cor_6_2_eq_6_2b`

SHA256 `b031220b4ced7299c8616b49a5852253fc169db3b4329f426428e5abfa58dfb2`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      (Matrix.det fun i j =>
          AffineDualJT.hKernel (AffineDualJT.classicalCoefficients (AffineDualJT.paperVariables n)) i
            (AffineDualJT.paperIndex j)) =
        2⁻¹ *
          Matrix.det fun i j =>
            AffineDualJT.hHatKernel (AffineDualJT.classicalCoefficients (AffineDualJT.paperVariables n)) i
              (AffineDualJT.paperIndex j)
```

### `AffineDualJT.paper_cor_6_2_eq_6_2b_ratio`

SHA256 `568d2e9444b741a4705f23bcd169728ef3c9bf6aa58cc5f9827f565e35e45b97`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      (Matrix.of fun a r => AffineDualJT.psi (↑k + AffineDualJT.paperIndex r) ↑(AffineDualJT.paperVariables n a)).det /
          AffineDualJT.DeltaB (AffineDualJT.paperVariables n) =
        2⁻¹ *
          Matrix.det fun i j =>
            AffineDualJT.hHatKernel (AffineDualJT.classicalCoefficients (AffineDualJT.paperVariables n)) i
              (AffineDualJT.paperIndex j)
```

### `AffineDualJT.paper_cor_6_2_eq_6_3`

SHA256 `ed5e7224572e0c190018ace4667966c3fb0d5c5684311dcf991b2f8816177992`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      (Matrix.of fun a r =>
              AffineDualJT.Cfun (↑k + AffineDualJT.paperIndex r - 1) ↑(AffineDualJT.paperVariables n a)).det /
          AffineDualJT.DeltaPlus (AffineDualJT.paperVariables n) =
        2⁻¹ *
          Matrix.det fun i j =>
            AffineDualJT.hPlusKernel (AffineDualJT.classicalCoefficients (AffineDualJT.paperVariables n)) i
              (AffineDualJT.paperIndex j)
```

### `AffineDualJT.paper_lemma_5_2_affine`

SHA256 `ebecf565263c7a1c4d6157cb997cc195c407c31a241df88710ca510880d8060d`

```lean
∀ {n k : ℕ} (j : Fin k) (m : ℤ),
  AffineDualJT.Gamma (AffineDualJT.paperParameter n) j m =
    -AffineDualJT.paperParameter n ^ (m - ↑k - 1) *
      AffineDualJT.Gamma (AffineDualJT.paperParameter n) j (2 * ↑k + 2 - m)
```

### `AffineDualJT.paper_lemma_5_2_center`

SHA256 `c3986260e9ff4fdd4c0ae88f3cba9f37b382d8ba465aba544790166df91d3b06`

```lean
∀ {n k : ℕ} (j : Fin k) (m : ℤ),
  AffineDualJT.Gamma (AffineDualJT.paperParameter n) j (2 - m) = AffineDualJT.Gamma (AffineDualJT.paperParameter n) j m
```

### `AffineDualJT.paper_lemma_5_2_fixed`

SHA256 `6acf9f9906434824e1b2e753d8e57d454cd969cc5ff7b472c74565b34e76fc4f`

```lean
∀ {n k : ℕ} (j : Fin k), AffineDualJT.Gamma (AffineDualJT.paperParameter n) j (↑k + 1) = 0
```

### `AffineDualJT.paper_lemma_5_2_quasiperiod`

SHA256 `43142e01b12d0ba12e64645573481e922a003bc172f691430f06cc329ea11951`

```lean
∀ {n k : ℕ} (j : Fin k) (m : ℤ),
  AffineDualJT.bBplus (AffineDualJT.paperParameter n) j (m + 2 * ↑k) =
    -AffineDualJT.paperParameter n ^ (m + ↑k - 1) * AffineDualJT.bBplus (AffineDualJT.paperParameter n) j m
```

### `AffineDualJT.paper_lemma_5_4_eq_5_3`

SHA256 `1d58a93f76c24361a85ca4a2e480d1914f2be33330f3dcbe03e661a936852754`

```lean
∀ {n k : ℕ} (j : Fin k) (m : ℤ),
  AffineDualJT.cBt (AffineDualJT.paperParameter n) j m =
    AffineDualJT.Gamma (AffineDualJT.paperParameter n) j m -
      AffineDualJT.Gamma (AffineDualJT.paperParameter n) j (m + 1)
```

### `AffineDualJT.paper_lemma_5_4_eq_5_4`

SHA256 `0e0ea515dc4103e4f66d4fd79ec7230d41ca5691c5575611d505fd9dd2265a53`

```lean
∀ {n k : ℕ} (j : Fin k) (m : ℤ),
  AffineDualJT.gammaBt (AffineDualJT.paperParameter n) j m =
    (1 + AffineDualJT.paperParameter n) * AffineDualJT.Gamma (AffineDualJT.paperParameter n) j m -
        AffineDualJT.Gamma (AffineDualJT.paperParameter n) j (m + 1) -
      AffineDualJT.paperParameter n * AffineDualJT.Gamma (AffineDualJT.paperParameter n) j (m - 1)
```

### `AffineDualJT.paper_lemma_5_4_eq_5_5`

SHA256 `ff40cd5ba499d8268f3bd30dc21922c02b161ba1b0e02d2d741ced02ac0007e7`

```lean
∀ {n k : ℕ} (j : Fin k) (m : ℤ),
  AffineDualJT.gammaBt (AffineDualJT.paperParameter n) j m =
    -AffineDualJT.paperParameter n ^ (m - ↑k - 1) *
      AffineDualJT.gammaBt (AffineDualJT.paperParameter n) j (2 * ↑k + 2 - m)
```

### `AffineDualJT.paper_lemma_5_4_fixed`

SHA256 `2bd3f6f246b9d2958561cd18ae5745b0271b3c57932a76e42741dd7d2ac77080`

```lean
∀ {n k : ℕ} (j : Fin k), AffineDualJT.gammaBt (AffineDualJT.paperParameter n) j (↑k + 1) = 0
```

### `AffineDualJT.paper_prop_2_2_B0`

SHA256 `9cdd6c908b1d994aeae391e31d0faaa33fe6696a1620d2cb72f410fc802976fd`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      AffineDualJT.ExternalHL.B0 (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) k =
        (AffineDualJT.PhiB (AffineDualJT.paperVariables n) * AffineDualJT.VB0 (AffineDualJT.paperParameter n)).det /
          AffineDualJT.DeltaB (AffineDualJT.paperVariables n)
```

### `AffineDualJT.paper_prop_2_2_BC`

SHA256 `64917d57676ed7b113cd91c5c3a8bdb7777419eff179fb62b6776b623e1c6fa8`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      AffineDualJT.ExternalHL.BC (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) k =
        (AffineDualJT.PhiC (AffineDualJT.paperVariables n) * AffineDualJT.VBC (AffineDualJT.paperParameter n)).det /
          AffineDualJT.DeltaC (AffineDualJT.paperVariables n)
```

### `AffineDualJT.paper_prop_2_2_Bminus`

SHA256 `3bc9a4de4c2a68bbd5066a67743dc3bf11b4e370be09f729f13f77b45edb99e4`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      AffineDualJT.ExternalHL.Bminus (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) k =
        (AffineDualJT.PhiB (AffineDualJT.paperVariables n) * AffineDualJT.VBminus (AffineDualJT.paperParameter n)).det /
          AffineDualJT.DeltaB (AffineDualJT.paperVariables n)
```

### `AffineDualJT.paper_prop_2_2_Bplus`

SHA256 `c5b4ea0e4c909e0f73bf77f0394573faf408d258a18d327c4c4cf0a0138a6ed1`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      AffineDualJT.ExternalHL.Bplus (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) k =
        (AffineDualJT.PhiPlus (AffineDualJT.paperVariables n) *
              AffineDualJT.VBplus (AffineDualJT.paperParameter n)).det /
          AffineDualJT.DeltaPlus (AffineDualJT.paperVariables n)
```

### `AffineDualJT.paper_prop_2_2_Bt`

SHA256 `c9e202730ff11badbd945f074355be40485ede4f783841c32e22d9398d98c84e`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      AffineDualJT.ExternalHL.Bt (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) k =
        (AffineDualJT.PhiB (AffineDualJT.paperVariables n) * AffineDualJT.VBt (AffineDualJT.paperParameter n)).det /
          AffineDualJT.DeltaB (AffineDualJT.paperVariables n)
```

### `AffineDualJT.paper_prop_2_2_C0`

SHA256 `e4420d736e213dc711075dab0ef2bc5fe16de0a9c2d64379417eb707ff1c9860`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      AffineDualJT.ExternalHL.C0 (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) k =
        (AffineDualJT.PhiC (AffineDualJT.paperVariables n) * AffineDualJT.VC0 (AffineDualJT.paperParameter n)).det /
          AffineDualJT.DeltaC (AffineDualJT.paperVariables n)
```

### `AffineDualJT.paper_prop_2_2_Ct`

SHA256 `2cf30e12fae1a4366c3a18add2002230000f181fc84ff58a91763c6acc68fb4d`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      AffineDualJT.ExternalHL.Ct (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) k =
        (AffineDualJT.PhiC (AffineDualJT.paperVariables n) * AffineDualJT.VCt (AffineDualJT.paperParameter n)).det /
          AffineDualJT.DeltaC (AffineDualJT.paperVariables n)
```

### `AffineDualJT.paper_prop_4_1_BC`

SHA256 `0f859ae04e9da93cc214813f449ff8ccec1c9348402de53d1876fedbcf722f73`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      AffineDualJT.ExternalHL.BC (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) k =
        AffineDualJT.AffineDetSum.JK (2 * ↑k + 1)
          (fun j y =>
            (-1) ^ y * AffineDualJT.paperParameter n ^ ((2 * ↑k + 1) * y ^ 2 - 2 * AffineDualJT.paperIndex j * y))
          fun i m => AffineDualJT.lambdaKernel (AffineDualJT.classicalCoefficients (AffineDualJT.paperVariables n)) i m
```

### `AffineDualJT.paper_prop_4_1_C0`

SHA256 `bae2800a98f4eef67e7bfe88f1d035a103ceae6cb06929a1acaf0755ad3fb0e2`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      AffineDualJT.ExternalHL.C0 (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) k =
        AffineDualJT.AffineDetSum.JK (2 * ↑k + 2)
          (fun j y => AffineDualJT.paperParameter n ^ ((↑k + 1) * y ^ 2 - AffineDualJT.paperIndex j * y)) fun i m =>
          AffineDualJT.lambdaKernel (AffineDualJT.classicalCoefficients (AffineDualJT.paperVariables n)) i m
```

### `AffineDualJT.paper_prop_4_2_B0`

SHA256 `acdbfc613d96d75beeade880cf943f137cd09969d4a16033c18b481b746068df`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      AffineDualJT.ExternalHL.B0 (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) k =
        AffineDualJT.AffineDetSum.JK (2 * ↑k + 1)
          (fun j y =>
            (-1) ^ y *
              AffineDualJT.paperParameter n ^ (((2 * ↑k + 1) * y ^ 2 - (2 * AffineDualJT.paperIndex j - 1) * y) / 2))
          fun i m => AffineDualJT.hKernel (AffineDualJT.classicalCoefficients (AffineDualJT.paperVariables n)) i m
```

### `AffineDualJT.paper_prop_4_2_Bminus`

SHA256 `89aaa873ef6d9d5d19a1dd400e660e9caa8bf64bb8230aaeacef9b12e2d30377`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      AffineDualJT.ExternalHL.Bminus (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) k =
        AffineDualJT.AffineDetSum.JK (2 * ↑k)
          (fun j y => AffineDualJT.paperParameter n ^ (2 * ↑k * y ^ 2 - (2 * AffineDualJT.paperIndex j - 1) * y))
          fun i m => AffineDualJT.hKernel (AffineDualJT.classicalCoefficients (AffineDualJT.paperVariables n)) i m
```

### `AffineDualJT.paper_prop_5_1_Ct`

SHA256 `59e60f09cf832280bbbc17ebbc0f7a02801a40b0ca40abfb074acdbafb10cb25`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      AffineDualJT.ExternalHL.Ct (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) k =
        AffineDualJT.AffineDetSum.JKEven (2 * ↑k)
          (fun j y => AffineDualJT.paperParameter n ^ (↑k * y ^ 2 - AffineDualJT.paperIndex j * y)) fun i m =>
          AffineDualJT.lambdaKernel (AffineDualJT.classicalCoefficients (AffineDualJT.paperVariables n)) i m
```

### `AffineDualJT.paper_prop_5_3_Bplus`

SHA256 `ca70cb5dc07630a1eb961b2a1f3398d3e4db283d0db2c4a215db5566960d9803`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      AffineDualJT.ExternalHL.Bplus (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) k =
        2⁻¹ *
          AffineDualJT.AffineDetSum.JK (2 * ↑k)
            (fun j y => (-1) ^ y * AffineDualJT.paperParameter n ^ (↑k * y ^ 2 - (AffineDualJT.paperIndex j - 1) * y))
            fun i m => AffineDualJT.hPlusKernel (AffineDualJT.classicalCoefficients (AffineDualJT.paperVariables n)) i m
```

### `AffineDualJT.paper_prop_5_5_Bt`

SHA256 `298137b5bcba0aa8e1ff062183f4a19918456ed7d0be3fdbaf4fb95059ee8e66`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      AffineDualJT.ExternalHL.Bt (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) k =
        2⁻¹ *
          AffineDualJT.AffineDetSum.JK (2 * ↑k)
            (fun j y => (-1) ^ y * AffineDualJT.paperParameter n ^ (↑k * y ^ 2 - (AffineDualJT.paperIndex j - 1) * y))
            fun i m => AffineDualJT.hHatKernel (AffineDualJT.classicalCoefficients (AffineDualJT.paperVariables n)) i m
```

### `AffineDualJT.paper_prop_6_1_B0`

SHA256 `b658f7ec730e5bb40bba6a097842b7a6401ffee62832aafb9d77a140eb303bb0`

```lean
∀ {n : ℕ}, 0 < n → AffineDualJT.ExternalHL.B0 (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) 0 = 1
```

### `AffineDualJT.paper_prop_6_1_BC`

SHA256 `6556d6533e346ed02cb445e7ac62bf2cbda7067c58125248b56f5f84a91a6005`

```lean
∀ {n : ℕ}, 0 < n → AffineDualJT.ExternalHL.BC (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) 0 = 1
```

### `AffineDualJT.paper_prop_6_1_Bminus`

SHA256 `a290ff8f70000c1ecf064e8837c02a2a5c5c0664dd73c6ea4540ca234b73a913`

```lean
∀ {n : ℕ}, 0 < n → AffineDualJT.ExternalHL.Bminus (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) 0 = 1
```

### `AffineDualJT.paper_prop_6_1_Bplus`

SHA256 `2386732ec6816639ffb559c84f72a37f5871e3e9b059b7b670911d575fc5f120`

```lean
∀ {n : ℕ}, 0 < n → AffineDualJT.ExternalHL.Bplus (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) 0 = 1
```

### `AffineDualJT.paper_prop_6_1_Bt`

SHA256 `02a5857c60882041d2e6a5b3a2dd641042fedec7c4fb504aacad369e98b11b57`

```lean
∀ {n : ℕ}, 0 < n → AffineDualJT.ExternalHL.Bt (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) 0 = 1
```

### `AffineDualJT.paper_prop_6_1_C0`

SHA256 `540ec9f8592e1a8cf3940623d03e3b36af198c769e68f2ab52efe64ed73f4b1d`

```lean
∀ {n : ℕ}, 0 < n → AffineDualJT.ExternalHL.C0 (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) 0 = 1
```

### `AffineDualJT.paper_prop_6_1_Ct`

SHA256 `9f62b5c299a9eb1650051286f6f29a71dd8a60a4d1e86d85cfa74dbfede0af88`

```lean
∀ {n : ℕ}, 0 < n → AffineDualJT.ExternalHL.Ct (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) 0 = 1
```

### `AffineDualJT.paper_theorem_A_1_3`

SHA256 `a25bf01dd0319fcf6a89b182deb984c59e1e990d98fa521bf78e306b3f421685`

```lean
∀ {n k : ℕ},
  0 < n →
    AffineDualJT.ExternalHL.B0 (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) k =
      AffineDualJT.AffineDetSum.JK (2 * ↑k + 1)
        (fun j y =>
          (-1) ^ y *
            AffineDualJT.paperParameter n ^ (((2 * ↑k + 1) * y ^ 2 - (2 * AffineDualJT.paperIndex j - 1) * y) / 2))
        fun i m => AffineDualJT.hKernel (AffineDualJT.classicalCoefficients (AffineDualJT.paperVariables n)) i m
```

### `AffineDualJT.paper_theorem_A_1_4`

SHA256 `202e904f36f80521371897dcedc313d7d4ebd23ff152957a5a05725cb045270a`

```lean
∀ {n k : ℕ},
  0 < n →
    AffineDualJT.ExternalHL.Bminus (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) k =
      AffineDualJT.AffineDetSum.JK (2 * ↑k)
        (fun j y => AffineDualJT.paperParameter n ^ (2 * ↑k * y ^ 2 - (2 * AffineDualJT.paperIndex j - 1) * y))
        fun i m => AffineDualJT.hKernel (AffineDualJT.classicalCoefficients (AffineDualJT.paperVariables n)) i m
```

### `AffineDualJT.paper_theorem_A_1_5`

SHA256 `ca70cb5dc07630a1eb961b2a1f3398d3e4db283d0db2c4a215db5566960d9803`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      AffineDualJT.ExternalHL.Bplus (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) k =
        2⁻¹ *
          AffineDualJT.AffineDetSum.JK (2 * ↑k)
            (fun j y => (-1) ^ y * AffineDualJT.paperParameter n ^ (↑k * y ^ 2 - (AffineDualJT.paperIndex j - 1) * y))
            fun i m => AffineDualJT.hPlusKernel (AffineDualJT.classicalCoefficients (AffineDualJT.paperVariables n)) i m
```

### `AffineDualJT.paper_theorem_A_1_6`

SHA256 `b6795e98966800340d1ffb1a69eb836883bfd29a8640a65192cf96e088b89fd6`

```lean
∀ {n k : ℕ},
  0 < n →
    AffineDualJT.ExternalHL.C0 (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) k =
      AffineDualJT.AffineDetSum.JK (2 * ↑k + 2)
        (fun j y => AffineDualJT.paperParameter n ^ ((↑k + 1) * y ^ 2 - AffineDualJT.paperIndex j * y)) fun i m =>
        AffineDualJT.lambdaKernel (AffineDualJT.classicalCoefficients (AffineDualJT.paperVariables n)) i m
```

### `AffineDualJT.paper_theorem_A_1_7`

SHA256 `ba4baf9c3deaae38af816e3680a81879cc0b4d673ee97e439c42c82c54f9ea39`

```lean
∀ {n k : ℕ},
  0 < n →
    AffineDualJT.ExternalHL.Ct (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) k =
      AffineDualJT.AffineDetSum.JKEven (2 * ↑k)
        (fun j y => AffineDualJT.paperParameter n ^ (↑k * y ^ 2 - AffineDualJT.paperIndex j * y)) fun i m =>
        AffineDualJT.lambdaKernel (AffineDualJT.classicalCoefficients (AffineDualJT.paperVariables n)) i m
```

### `AffineDualJT.paper_theorem_A_1_8`

SHA256 `00f8a572911acb788ef008d5db15882358548f4fabb833b3fbd2ecf906b80255`

```lean
∀ {n k : ℕ},
  0 < n →
    AffineDualJT.ExternalHL.BC (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) k =
      AffineDualJT.AffineDetSum.JK (2 * ↑k + 1)
        (fun j y =>
          (-1) ^ y * AffineDualJT.paperParameter n ^ ((2 * ↑k + 1) * y ^ 2 - 2 * AffineDualJT.paperIndex j * y))
        fun i m => AffineDualJT.lambdaKernel (AffineDualJT.classicalCoefficients (AffineDualJT.paperVariables n)) i m
```

### `AffineDualJT.paper_theorem_A_Bplus_width_zero`

SHA256 `32bd439ea03fb2d370ddcdfbd99f2c7d213e5242b945f3f1fbde5c57e7bcb09a`

```lean
∀ {n : ℕ}, AffineDualJT.ExternalHL.Bplus (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) 0 = 1
```

### `AffineDualJT.paper_theorem_B_1_9`

SHA256 `298137b5bcba0aa8e1ff062183f4a19918456ed7d0be3fdbaf4fb95059ee8e66`

```lean
∀ {n k : ℕ},
  0 < n →
    0 < k →
      AffineDualJT.ExternalHL.Bt (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) k =
        2⁻¹ *
          AffineDualJT.AffineDetSum.JK (2 * ↑k)
            (fun j y => (-1) ^ y * AffineDualJT.paperParameter n ^ (↑k * y ^ 2 - (AffineDualJT.paperIndex j - 1) * y))
            fun i m => AffineDualJT.hHatKernel (AffineDualJT.classicalCoefficients (AffineDualJT.paperVariables n)) i m
```

### `AffineDualJT.paper_theorem_B_Bt_width_zero`

SHA256 `d7aa6f34a77457d9e5158d9b32ebf3cf6df3d9f0cbc71965ea737fad5424e262`

```lean
∀ {n : ℕ}, AffineDualJT.ExternalHL.Bt (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) 0 = 1
```

## 其余 paper_ 前缀声明完整类型（含编译辅助项）

### `AffineDualJT.paper_DeltaB_ne_zero`

SHA256 `94e3c96e0f542336fd164d2dbecac22c13b8ebc573cc150bd9823ae83d890a9e`

```lean
∀ (n : ℕ), AffineDualJT.DeltaB (AffineDualJT.paperVariables n) ≠ 0
```

### `AffineDualJT.paper_DeltaC_ne_zero`

SHA256 `39a594188e4ac90bd9538bbe53250d64cf78313f71b951d6fd100201ce655b80`

```lean
∀ (n : ℕ), AffineDualJT.DeltaC (AffineDualJT.paperVariables n) ≠ 0
```

### `AffineDualJT.paper_DeltaPlus_ne_zero`

SHA256 `03b21529ce8687fe77e719a0a8caee9d3cd4676ff7dd0cc976b3567031aff9d6`

```lean
∀ (n : ℕ), AffineDualJT.DeltaPlus (AffineDualJT.paperVariables n) ≠ 0
```

### `AffineDualJT.paper_Nt_one_ne_zero`

SHA256 `de050f2d88a626441e8c925618f2874ee0dd132cb685afbcf1f48362ea29202c`

```lean
∀ (n : ℕ), (AffineDualJT.Nt 1 fun a => ↑(AffineDualJT.paperVariables n a)) ≠ 0
```

### `AffineDualJT.paper_Nt_scale_lowest_coeff`

SHA256 `4c4e445b7f82f08c7ff154f0b70f895f8c357d891dd268905d63054e04ec53bd`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  (Polynomial.coeff (AffineDualJT.paperScaleHom (AffineDualJT.Nt (MvPolynomial.C t) MvPolynomial.X)))
      (n * (n - 1) / 2) =
    ∏ p, (MvPolynomial.X p.fst - MvPolynomial.X ↑p.snd)
```

### `AffineDualJT.paper_Vn_ne_zero`

SHA256 `2353da84fb0a3a80281f49fd4ff8e11caeb1f06c3d675680ff0ef8480d3d164c`

```lean
∀ {n : ℕ} (m : ℕ), AffineDualJT.ExternalHL.Vn m (AffineDualJT.paperParameter n) ≠ 0
```

### `AffineDualJT.paper_Vn_pow_ne_zero`

SHA256 `9c946e7bfd412b494a29276e9425fc15515792a8c0bb3d2b6e73f7224a32eec0`

```lean
∀ {n : ℕ} (m d : ℕ), 0 < d → AffineDualJT.ExternalHL.Vn m (AffineDualJT.paperParameter n ^ d) ≠ 0
```

### `AffineDualJT.paper_XU_complementary_minor_relation`

SHA256 `fe63429b13597a6f88c68973801873d0dac30acfc752b8601199e52020f9aec8`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (X : Matrix (Fin n) (Fin (n + k)) F) (U : Matrix (Fin (n + k)) (Fin k) F),
  X * U = 0 →
    (AffineDualJT.firstCols X).det ≠ 0 →
      (AffineDualJT.tailRowsAfterN U).det ≠ 0 →
        ∀ (p₀ p : Fin k ⊕ Fin n ≃ Fin (n + k)),
          (Matrix.of fun i j => X i (p (Sum.inr j))).det *
              (↑↑(Equiv.Perm.sign (p₀.trans (AffineDualJT.paperSplitRows n k).symm)) *
                (U.submatrix (fun i => p₀ (Sum.inl i)) id).det) =
            (Matrix.of fun i j => X i (p₀ (Sum.inr j))).det *
              (↑↑(Equiv.Perm.sign (p.trans (AffineDualJT.paperSplitRows n k).symm)) *
                (U.submatrix (fun i => p (Sum.inl i)) id).det)
```

### `AffineDualJT.paper_XU_coordinate_minor_relation`

SHA256 `679fff725ef763c3310c7fa52f1cb178c4ba8fcbfe1ce195424298759ea1e930`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (X : Matrix (Fin n) (Fin (n + k)) F) (U : Matrix (Fin (n + k)) (Fin k) F),
  X * U = 0 →
    (AffineDualJT.firstCols X).det ≠ 0 →
      (AffineDualJT.tailRowsAfterN U).det ≠ 0 →
        ∀ (p₀ p : Fin k ⊕ Fin n ≃ Fin (n + k)),
          (Matrix.of fun i j => X i (p (Sum.inr j))).det *
              (AffineDualJT.paperRowStack✝ (Matrix.of fun i c => U ((AffineDualJT.paperSplitRows n k) c) i)
                  (Matrix.of fun i c =>
                    AffineDualJT.paperCoordinateVector✝ (p₀ (Sum.inr i)) ((AffineDualJT.paperSplitRows n k) c))).det =
            (Matrix.of fun i j => X i (p₀ (Sum.inr j))).det *
              (AffineDualJT.paperRowStack✝ (Matrix.of fun i c => U ((AffineDualJT.paperSplitRows n k) c) i)
                  (Matrix.of fun i c =>
                    AffineDualJT.paperCoordinateVector✝ (p (Sum.inr i)) ((AffineDualJT.paperSplitRows n k) c))).det
```

### `AffineDualJT.paper_XU_finset_complement_relation`

SHA256 `f836a02b5bbed7c0df415347bed285621b9a336882ca84c37a731de1a820717b`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (X : Matrix (Fin n) (Fin (n + k)) F) (U : Matrix (Fin (n + k)) (Fin k) F),
  X * U = 0 →
    (AffineDualJT.firstCols X).det ≠ 0 →
      (AffineDualJT.tailRowsAfterN U).det ≠ 0 →
        ∀ (Q : Finset (Fin (n + k))) (hQ : Q.card = n),
          (Matrix.of fun i j => X i ((Q.orderEmbOfFin hQ) j)).det *
              ((-1) ^ (n * k) * (AffineDualJT.tailRowsAfterN U).det) =
            (AffineDualJT.firstCols X).det *
              (↑↑(Equiv.Perm.sign ((AffineDualJT.paperFinsetSplit Q hQ).trans (AffineDualJT.paperSplitRows n k).symm)) *
                (U.submatrix (fun i => (Qᶜ.orderEmbOfFin ⋯) i) id).det)
```

### `AffineDualJT.paper_XU_quotient_forms_proportional`

SHA256 `d32775364219f9489b5ad26b6fab07f3b15f2f997c25eef32023ace348dea5bc`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (X : Matrix (Fin n) (Fin (n + k)) F) (U : Matrix (Fin (n + k)) (Fin k) F)
  (hXU : X * U = 0) (hXQ0 : (AffineDualJT.firstCols X).det ≠ 0) (hUJ : (AffineDualJT.tailRowsAfterN U).det ≠ 0),
  ∃ s,
    U.mulVecLin.range.mkQ ∘ₗ s = LinearMap.id ∧
      AffineDualJT.paperFixedColumnDetAlternating U s =
        (((AffineDualJT.paperFixedColumnDetAlternating U s) fun i =>
              ((Pi.basisFun F (Fin n)).map (AffineDualJT.paper_matrix_quotient_equiv X U hXU hXQ0 hUJ).symm) i) /
            (AffineDualJT.paperImageTopForm (AffineDualJT.paper_matrix_quotient_equiv X U hXU hXQ0 hUJ)) fun i =>
              ((Pi.basisFun F (Fin n)).map (AffineDualJT.paper_matrix_quotient_equiv X U hXU hXQ0 hUJ).symm) i) •
          AffineDualJT.paperImageTopForm (AffineDualJT.paper_matrix_quotient_equiv X U hXU hXQ0 hUJ)
```

### `AffineDualJT.paper_XU_standard_complement_relation`

SHA256 `9f92fdecff2760c03ab7338792064d686bc52cb0e09bdc7e79252a4f61202fe3`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (X : Matrix (Fin n) (Fin (n + k)) F) (U : Matrix (Fin (n + k)) (Fin k) F),
  X * U = 0 →
    (AffineDualJT.firstCols X).det ≠ 0 →
      (AffineDualJT.tailRowsAfterN U).det ≠ 0 →
        ∀ (p : Fin k ⊕ Fin n ≃ Fin (n + k)),
          (Matrix.of fun i j => X i (p (Sum.inr j))).det * ((-1) ^ (n * k) * (AffineDualJT.tailRowsAfterN U).det) =
            (AffineDualJT.firstCols X).det *
              (↑↑(Equiv.Perm.sign (p.trans (AffineDualJT.paperSplitRows n k).symm)) *
                (U.submatrix (fun i => p (Sum.inl i)) id).det)
```

### `AffineDualJT.paper_YZ_complementary_minor_relation`

SHA256 `39a94c75ee383b7d09675561afbd7694c06b2d36296653668b6b7d2546ee0721`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (Y : Matrix (Fin (n + k)) (Fin n) F) (Z : Matrix (Fin (n + k)) (Fin k) F),
  Y.transpose * Z = 0 →
    (AffineDualJT.lastRowsY Y).det ≠ 0 →
      (AffineDualJT.firstRowsZ Z).det ≠ 0 →
        ∀ (p₀ p : Fin k ⊕ Fin n ≃ Fin (n + k)),
          (Matrix.of fun i j => Y (p (Sum.inr i)) j).det *
              (↑↑(Equiv.Perm.sign (p₀.trans (AffineDualJT.paperSplitRows n k).symm)) *
                (Z.submatrix (fun i => p₀ (Sum.inl i)) id).det) =
            (Matrix.of fun i j => Y (p₀ (Sum.inr i)) j).det *
              (↑↑(Equiv.Perm.sign (p.trans (AffineDualJT.paperSplitRows n k).symm)) *
                (Z.submatrix (fun i => p (Sum.inl i)) id).det)
```

### `AffineDualJT.paper_YZ_coordinate_minor_relation`

SHA256 `bdee99e6854fb9fb0f5f108dc5657294eb697589ac86fc4d3a240caddafdd684`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (Y : Matrix (Fin (n + k)) (Fin n) F) (Z : Matrix (Fin (n + k)) (Fin k) F),
  Y.transpose * Z = 0 →
    (AffineDualJT.lastRowsY Y).det ≠ 0 →
      (AffineDualJT.firstRowsZ Z).det ≠ 0 →
        ∀ (p₀ p : Fin k ⊕ Fin n ≃ Fin (n + k)),
          (Matrix.of fun i j => Y (p (Sum.inr i)) j).det *
              (AffineDualJT.paperRowStack✝ (Matrix.of fun i c => Z ((AffineDualJT.paperSplitRows n k) c) i)
                  (Matrix.of fun i c =>
                    AffineDualJT.paperCoordinateVector✝ (p₀ (Sum.inr i)) ((AffineDualJT.paperSplitRows n k) c))).det =
            (Matrix.of fun i j => Y (p₀ (Sum.inr i)) j).det *
              (AffineDualJT.paperRowStack✝ (Matrix.of fun i c => Z ((AffineDualJT.paperSplitRows n k) c) i)
                  (Matrix.of fun i c =>
                    AffineDualJT.paperCoordinateVector✝ (p (Sum.inr i)) ((AffineDualJT.paperSplitRows n k) c))).det
```

### `AffineDualJT.paper_YZ_finset_complement_relation`

SHA256 `2cb1bf19455962d1309be487a0c5b3478ca0d5ab6d0e729bc7705170e3071489`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (Y : Matrix (Fin (n + k)) (Fin n) F) (Z : Matrix (Fin (n + k)) (Fin k) F),
  Y.transpose * Z = 0 →
    (AffineDualJT.lastRowsY Y).det ≠ 0 →
      (AffineDualJT.firstRowsZ Z).det ≠ 0 →
        ∀ (Q : Finset (Fin (n + k))) (hQ : Q.card = n),
          (Matrix.of fun i j => Y ((Q.orderEmbOfFin hQ) i) j).det * (AffineDualJT.firstRowsZ Z).det =
            (AffineDualJT.lastRowsY Y).det *
              (↑↑(Equiv.Perm.sign ((AffineDualJT.paperFinsetSplit Q hQ).trans (AffineDualJT.paperSplitRows n k).symm)) *
                (Z.submatrix (fun i => (Qᶜ.orderEmbOfFin ⋯) i) id).det)
```

### `AffineDualJT.paper_YZ_quotient_forms_proportional`

SHA256 `1dbcc88e827361b4a4820b7d80acfc4f1cb435dd8de345975bb770c7d2fb5e52`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (Y : Matrix (Fin (n + k)) (Fin n) F) (Z : Matrix (Fin (n + k)) (Fin k) F)
  (hYTZ : Y.transpose * Z = 0) (hYH : (AffineDualJT.lastRowsY Y).det ≠ 0) (hZI : (AffineDualJT.firstRowsZ Z).det ≠ 0),
  ∃ s,
    Z.mulVecLin.range.mkQ ∘ₗ s = LinearMap.id ∧
      AffineDualJT.paperFixedColumnDetAlternating Z s =
        (((AffineDualJT.paperFixedColumnDetAlternating Z s) fun i =>
              ((Pi.basisFun F (Fin n)).map (AffineDualJT.paper_transpose_quotient_equiv Y Z hYTZ hYH hZI).symm) i) /
            (AffineDualJT.paperImageTopForm (AffineDualJT.paper_transpose_quotient_equiv Y Z hYTZ hYH hZI)) fun i =>
              ((Pi.basisFun F (Fin n)).map (AffineDualJT.paper_transpose_quotient_equiv Y Z hYTZ hYH hZI).symm) i) •
          AffineDualJT.paperImageTopForm (AffineDualJT.paper_transpose_quotient_equiv Y Z hYTZ hYH hZI)
```

### `AffineDualJT.paper_YZ_standard_complement_relation`

SHA256 `8f24a99372a697ae9b75eceb8c5ead8f270fb93ee8b7b39740a0ccaa22321b79`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (Y : Matrix (Fin (n + k)) (Fin n) F) (Z : Matrix (Fin (n + k)) (Fin k) F),
  Y.transpose * Z = 0 →
    (AffineDualJT.lastRowsY Y).det ≠ 0 →
      (AffineDualJT.firstRowsZ Z).det ≠ 0 →
        ∀ (p : Fin k ⊕ Fin n ≃ Fin (n + k)),
          (Matrix.of fun i j => Y (p (Sum.inr i)) j).det * (AffineDualJT.firstRowsZ Z).det =
            (AffineDualJT.lastRowsY Y).det *
              (↑↑(Equiv.Perm.sign (p.trans (AffineDualJT.paperSplitRows n k).symm)) *
                (Z.submatrix (fun i => p (Sum.inl i)) id).det)
```

### `AffineDualJT.paper_admissible`

SHA256 `c72e46e29c8ad10e5bea4ed6f3b238ece9ceb51fe7f494134656ed4323e5cbf7`

```lean
∀ (n : ℕ), AffineDualJT.ExternalHL.Admissible (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n) 1
```

### `AffineDualJT.paper_admissible_Bminus`

SHA256 `0f4f063746ffa326f2465fe41a9cf2cf703a5c4bef3ad78a82b08db67b90f0b2`

```lean
∀ (n k : ℕ),
  AffineDualJT.ExternalHL.Admissible (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n ^ 2)
    (AffineDualJT.ExternalHL.nuBminus n k (AffineDualJT.paperParameter n))
```

### `AffineDualJT.paper_admissible_Bplus`

SHA256 `5c5318ad1d3f9e7ccdb86a522a358a3f2946b71b967048973f47720222b7f154`

```lean
∀ (n k : ℕ),
  AffineDualJT.ExternalHL.Admissible (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n)
    (AffineDualJT.ExternalHL.nuBplus n k (AffineDualJT.paperParameter n))
```

### `AffineDualJT.paper_admissible_Ct`

SHA256 `7c01adf1e1ca1f4e01daf487fa3564396e0dc4d7fbbbab45ef459f65ad301ab4`

```lean
∀ (n k : ℕ),
  AffineDualJT.ExternalHL.Admissible (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n)
    (AffineDualJT.ExternalHL.nuCt n k (AffineDualJT.paperParameter n))
```

### `AffineDualJT.paper_admissible_of_normalization`

SHA256 `153d1e675f34a5a0eda67fd74560f567e25b2cdad73f8f74fbdddb6d0f1cbf29`

```lean
∀ {n : ℕ} (t ν : AffineDualJT.PaperField n),
  AffineDualJT.ExternalHL.Vn n t * ν ≠ 0 → AffineDualJT.ExternalHL.Admissible (AffineDualJT.paperVariables n) t ν
```

### `AffineDualJT.paper_admissible_squared`

SHA256 `aa365b001773a961accba5b4b2e905d499475e8a680129a6d84f990431a1da8e`

```lean
∀ (n : ℕ), AffineDualJT.ExternalHL.Admissible (AffineDualJT.paperVariables n) (AffineDualJT.paperParameter n ^ 2) 1
```

### `AffineDualJT.paper_admissible_zero`

SHA256 `e0cedefc640947cabb3c84d3f7e40b3b52185c5cc7dcb324a3c1b3933e70fdba`

```lean
∀ (n : ℕ), AffineDualJT.ExternalHL.Admissible (AffineDualJT.paperVariables n) 0 1
```

### `AffineDualJT.paper_alternant_pairIndex_card`

SHA256 `b2d80c6b1862f9d412fe8db0d64eafc1110d6c07b4f5e99f5c375fb7441195fe`

```lean
∀ {n : ℕ}, Fintype.card (AffineDualJT.paperAlternantPairIndex n) = ∑ a, Fintype.card { b // a < b }
```

### `AffineDualJT.paper_alternant_pairIndex_card_eq_triangular`

SHA256 `cf616f68c2101e9dcc692a5099bc7a182e20699e66a789086f9e9303a777e2b2`

```lean
∀ (n : ℕ), Fintype.card (AffineDualJT.paperAlternantPairIndex n) = n * (n - 1) / 2
```

### `AffineDualJT.paper_basic_alternant_totalDegree_le`

SHA256 `8c0fc93e02ded5daa38b40b1040aeba4e19a298324fd8fe633b7be16c08dcf62`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  (Matrix.of fun a r => AffineDualJT.fColumn (MvPolynomial.C t) r (MvPolynomial.X a)).det.totalDegree ≤
    3 * Fintype.card (AffineDualJT.paperAlternantPairIndex n)
```

### `AffineDualJT.paper_basic_alternant_vanish_under_reciprocal`

SHA256 `a753a6f6e81f0e8916ccee606eb6f18e61e1d75fe23e5fbfa1218ec7820ce6a0`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F) (z : Fin n → F) (a b : Fin n),
  a ≠ b → t ≠ 0 → z a ≠ 0 → z b = (t * z a)⁻¹ → (Matrix.of fun i r => AffineDualJT.fColumn t r (z i)).det = 0
```

### `AffineDualJT.paper_basic_column_degree_sum`

SHA256 `769e0c4f65771196f94e98ed1a567e4451ecc2ac3a7772257ba57fedb4c69749`

```lean
∀ (n : ℕ), ∑ r, (n + ↑r - 1) = 3 * (n * (n - 1) / 2)
```

### `AffineDualJT.paper_basic_difference_factor_dvd_any_pair`

SHA256 `b0fa701bd8b746810106bd80f869c94c9444b2697d588bdb35f7aaade971320b`

```lean
∀ {F : Type u_1} [inst : Field F] {N : ℕ} (t : F) (a b : Fin N),
  a ≠ b → MvPolynomial.X a - MvPolynomial.X b ∣ AffineDualJT.paperBasicAlternantPolynomial t
```

### `AffineDualJT.paper_basic_factor_degree_sum`

SHA256 `9529fef29f29af7d1a06a883746aa6e5f00c94b8adb62659a97c461137652206`

```lean
∀ {n : ℕ}, (∑ i, if i.snd = Bool.true then 2 else 1) = 3 * Fintype.card (AffineDualJT.paperAlternantPairIndex n)
```

### `AffineDualJT.paper_basic_factor_dvd_any_pair`

SHA256 `799e4762891ffa833e88b216c9cdcf6463731e347c4a1d30b66b626bd2b10ab2`

```lean
∀ {F : Type u_1} [inst : Field F] {N : ℕ} (t : F) (a b : Fin N),
  a ≠ b →
    t ≠ 0 → 1 - MvPolynomial.C t * MvPolynomial.X a * MvPolynomial.X b ∣ AffineDualJT.paperBasicAlternantPolynomial t
```

### `AffineDualJT.paper_basic_factor_pairwise_isRelPrime`

SHA256 `266fc3249f4d44cafe4502d0d0c25275542989217e21b36481e70a3ac48c94cd`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 → Pairwise fun i j => IsRelPrime (AffineDualJT.paperBasicFactor t i) (AffineDualJT.paperBasicFactor t j)
```

### `AffineDualJT.paper_basic_factor_product_eq_Nt`

SHA256 `63e3130682bf2cecd4dce7c8daaec64f3bd5dcdd4806c8ca2bc81ac68b57fea0`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  AffineDualJT.paperBasicFactorProduct t = AffineDualJT.Nt (MvPolynomial.C t) MvPolynomial.X
```

### `AffineDualJT.paper_basic_factor_product_totalDegree`

SHA256 `23e438b9d3c56b9477b0c32f09544afc78ac507383e1f0153fa3e96a57e1d71c`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 → (AffineDualJT.paperBasicFactorProduct t).totalDegree = ∑ i, if i.snd = Bool.true then 2 else 1
```

### `AffineDualJT.paper_basic_factor_product_totalDegree_eq`

SHA256 `f245a93629bc0680c8467e9cc5fc87a9ed1d285620061467654ff24295efb83a`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 →
    (AffineDualJT.paperBasicFactorProduct t).totalDegree = 3 * Fintype.card (AffineDualJT.paperAlternantPairIndex n)
```

### `AffineDualJT.paper_basic_factor_scale_lowest_coeff`

SHA256 `4cdba5ad19850c22bfc1bf95ae06b803af9295e50f48e4d58b45a548e8698edb`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  (Polynomial.coeff (AffineDualJT.paperScaleHom (AffineDualJT.paperBasicFactorProduct t))) (n * (n - 1) / 2) =
    ∏ p, (MvPolynomial.X p.fst - MvPolynomial.X ↑p.snd)
```

### `AffineDualJT.paper_basic_factor_totalDegree`

SHA256 `10e2987bf19010ce34dded3a49909ce5878588f105a9f07d01a5680d533596c9`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 →
    ∀ (i : AffineDualJT.paperBasicFactorIndex n),
      (AffineDualJT.paperBasicFactor t i).totalDegree = if i.snd = Bool.true then 2 else 1
```

### `AffineDualJT.paper_basic_factorization_by_lowest_part`

SHA256 `4d43b1b751c54bdb8f57f2d85fef4a156695f8e28196e79889314792493ede90`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 → AffineDualJT.paperBasicAlternantPolynomial t = AffineDualJT.paperBasicFactorProduct t
```

### `AffineDualJT.paper_basic_factorization_zero`

SHA256 `3285b3ca9c90f43af203dba6341a49ce97d1b8a9b8659a79ed3172b864e7fa45`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ},
  AffineDualJT.paperBasicAlternantPolynomial 0 = AffineDualJT.paperBasicFactorProduct 0
```

### `AffineDualJT.paper_basic_full_factor_product_dvd`

SHA256 `3af89d03fd50dda61f84aa9b820205f02e6418450d51a22b7644262b614eb5f3`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 → AffineDualJT.paperBasicFactorProduct t ∣ AffineDualJT.paperBasicAlternantPolynomial t
```

### `AffineDualJT.paper_basic_last_variable_difference_dvd`

SHA256 `9fb219730723221e0b0f86cf7d6c89dcaf7033639c8c9eae7bbf28dcf11c4d76`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F) (j : Fin n),
  MvPolynomial.X 0 - MvPolynomial.X j.succ ∣ AffineDualJT.paperBasicAlternantPolynomial t
```

### `AffineDualJT.paper_basic_last_variable_factor_dvd`

SHA256 `05c3aa0b414416cd946f6ebaa3edb1eaa18be3740f99eb99dbcfe39823473e4f`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F) (j : Fin n),
  t ≠ 0 → 1 - MvPolynomial.C t * MvPolynomial.X j.succ * MvPolynomial.X 0 ∣ AffineDualJT.paperBasicAlternantPolynomial t
```

### `AffineDualJT.paper_basic_lower_exponent_sum`

SHA256 `b22aecb46cf0a0f6cc68cd47d34b35546b9355c6e68ad1a9262ad8bbf3a35bf5`

```lean
∀ (n : ℕ), ∑ r, (n - (↑r + 1)) = n * (n - 1) / 2
```

### `AffineDualJT.paper_basic_row_proportional`

SHA256 `946daa33ada7996d0f781f2ea9a6a4a1acacde9884b1b0a0a9b7ec347434a03a`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F) (z : Fin n → F) (a b : Fin n),
  a ≠ b →
    t ≠ 0 →
      z a ≠ 0 →
        z b = (t * z a)⁻¹ →
          ∀ (r : Fin n),
            AffineDualJT.fColumn t r (z b) = (t * z a)⁻¹ ^ (n - 1) / z a ^ (n - 1) * AffineDualJT.fColumn t r (z a)
```

### `AffineDualJT.paper_basic_scale_lowest_coeff`

SHA256 `2cf508316c28a55d46f14582213bb703cc84d8f1e4035fa9bc9d9cd7a41d1696`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  (Polynomial.coeff (AffineDualJT.paperScaleHom (AffineDualJT.paperBasicAlternantPolynomial t))) (n * (n - 1) / 2) =
    (Matrix.of fun a r => MvPolynomial.X a ^ (n - (↑r + 1))).det
```

### `AffineDualJT.paper_basic_scaled_det_eval_zero`

SHA256 `e752c51b2020a7ac6fd09d20d40d365d21930e2de6c47b261b7102d43900725e`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  Polynomial.eval 0 (AffineDualJT.paperBasicScaledMatrix t).det =
    (Matrix.of fun a r => MvPolynomial.X a ^ (n - (↑r + 1))).det
```

### `AffineDualJT.paper_basic_scaled_reduced_eval_zero`

SHA256 `493f72ebdfa4c497090ec95dede4dfbbc3459e755f8d19a203a2d8e4348d16a1`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F) (a r : Fin n),
  Polynomial.eval 0 (AffineDualJT.paperBasicScaledReduced t a r) = MvPolynomial.X a ^ (n - (↑r + 1))
```

### `AffineDualJT.paper_bminusColumn_totalDegree_le`

SHA256 `fe6857a497a9db1def9ae510cce2b2dea6eed99c548f47c4520bafc276d875ae`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F) (a r : Fin n),
  (AffineDualJT.bminusAlternantColumn (MvPolynomial.C τ) r (MvPolynomial.X a)).totalDegree ≤ n + ↑r
```

### `AffineDualJT.paper_bminus_alternant_totalDegree_le`

SHA256 `6222b4cf2d234e7ab63140783bc990410a28668afc12366edf5cf2661ac9b840`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F),
  (Matrix.of fun a r => AffineDualJT.bminusAlternantColumn (MvPolynomial.C τ) r (MvPolynomial.X a)).det.totalDegree ≤
    3 * Fintype.card (AffineDualJT.paperAlternantPairIndex n) + n
```

### `AffineDualJT.paper_bminus_alternant_vanish_under_reciprocal`

SHA256 `132f2e9c790887278abf88968ae312c26a483590d3c95f8d9694d4445e6fa3e9`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F) (z : Fin n → F) (a b : Fin n),
  a ≠ b →
    τ ≠ 0 →
      z a ≠ 0 →
        0 < n → z b = (τ ^ 2 * z a)⁻¹ → (Matrix.of fun i r => AffineDualJT.bminusAlternantColumn τ r (z i)).det = 0
```

### `AffineDualJT.paper_bminus_column_degree_sum`

SHA256 `d7b0a125dd709c0db03eaad29b1f84864dcbae58c408fec257f523d254fa852f`

```lean
∀ (n : ℕ), ∑ r, (n + ↑r) = 3 * (n * (n - 1) / 2) + n
```

### `AffineDualJT.paper_bminus_column_extra_row_factor`

SHA256 `e22ad6d141f541df8e5acf029d736b96b5040265b65437b7a094b351ee0783ed`

```lean
∀ {R : Type u_2} [inst : CommRing R] {n : ℕ} (τ z : R) (r : Fin n),
  AffineDualJT.bminusAlternantColumn τ r z = (1 + τ * z) * AffineDualJT.paperBminusRowQuotient τ r z
```

### `AffineDualJT.paper_bminus_determinant_extra_row_factors`

SHA256 `331b1506806995f7ff8aa3bda0802b5fcbece0e242f4589d1da63e2e9303d96b`

```lean
∀ {R : Type u_2} [inst : CommRing R] {n : ℕ} (τ : R) (z : Fin n → R),
  (Matrix.of fun a r => AffineDualJT.bminusAlternantColumn τ r (z a)).det =
    (∏ a, (1 + τ * z a)) * (Matrix.of fun a r => AffineDualJT.paperBminusRowQuotient τ r (z a)).det
```

### `AffineDualJT.paper_bminus_difference_factor_dvd_any_pair`

SHA256 `4c70388c7ffde8c87c2da428bc8c142920864a29271460e5f14b79323fc875cf`

```lean
∀ {F : Type u_1} [inst : Field F] {N : ℕ} (t : F) (a b : Fin N),
  a ≠ b → MvPolynomial.X a - MvPolynomial.X b ∣ AffineDualJT.paperBminusAlternantPolynomial t
```

### `AffineDualJT.paper_bminus_factor_dvd_any_pair`

SHA256 `ff6cfc9d1d9e9c2065831528049b3c2cc1a5e725274e1443cd9a8c53e2f71496`

```lean
∀ {F : Type u_1} [inst : Field F] {N : ℕ} (τ : F) (a b : Fin N),
  a ≠ b →
    τ ≠ 0 →
      1 - MvPolynomial.C (τ ^ 2) * MvPolynomial.X a * MvPolynomial.X b ∣ AffineDualJT.paperBminusAlternantPolynomial τ
```

### `AffineDualJT.paper_bminus_factor_pairwise_isRelPrime`

SHA256 `7e136200f36a84ef166d15cce3bd19fd0a561c2da4c9d0b91d59cacce7f3d71d`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F),
  τ ≠ 0 → Pairwise fun i j => IsRelPrime (AffineDualJT.paperBminusFactor τ i) (AffineDualJT.paperBminusFactor τ j)
```

### `AffineDualJT.paper_bminus_factor_product_eq`

SHA256 `f99a4f9d1cdcff0012e12933670b34eecb0690ff560d56f9763394f23c1a5eb2`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F),
  AffineDualJT.paperBminusFactorProduct τ =
    (∏ a, (1 + MvPolynomial.C τ * MvPolynomial.X a)) * AffineDualJT.Nt (MvPolynomial.C (τ ^ 2)) MvPolynomial.X
```

### `AffineDualJT.paper_bminus_factor_product_totalDegree`

SHA256 `d12c32dbe1f76a79c20b20756580c97e74edf864539ccc6daa60bbb6c6914ae4`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F),
  τ ≠ 0 → (AffineDualJT.paperBminusFactorProduct τ).totalDegree = ∑ i, (AffineDualJT.paperBminusFactor τ i).totalDegree
```

### `AffineDualJT.paper_bminus_factor_product_totalDegree_eq`

SHA256 `286cbe538388e020275244710bae8842b0876f6befec82dc20fc7e108f72e013`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F),
  τ ≠ 0 →
    (AffineDualJT.paperBminusFactorProduct τ).totalDegree =
      3 * Fintype.card (AffineDualJT.paperAlternantPairIndex n) + n
```

### `AffineDualJT.paper_bminus_factor_scale_lowest_coeff`

SHA256 `e298df4c1ac7e75ad82771d653148dc1e0305c330c59ffc64fad267e8b06f5b1`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F),
  (Polynomial.coeff (AffineDualJT.paperScaleHom (AffineDualJT.paperBminusFactorProduct τ))) (n * (n - 1) / 2) =
    ∏ p, (MvPolynomial.X p.fst - MvPolynomial.X ↑p.snd)
```

### `AffineDualJT.paper_bminus_factorization_by_lowest_part`

SHA256 `67fb37483969eeb4173033db69217ab98ce9ff56da938112ccff80c1cf0cfc32`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F),
  τ ≠ 0 → AffineDualJT.paperBminusAlternantPolynomial τ = AffineDualJT.paperBminusFactorProduct τ
```

### `AffineDualJT.paper_bminus_factorization_zero`

SHA256 `f690ffaf706ae8401e88ef28ca9ba3668329aeedc0cea47b0734872d72585ff3`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ},
  AffineDualJT.paperBminusAlternantPolynomial 0 = AffineDualJT.paperBminusFactorProduct 0
```

### `AffineDualJT.paper_bminus_full_factor_product_dvd`

SHA256 `315e3bc63e2ffc61642eb02866e5eaef1e0d8fa69cf9bdf63985ac0f5c1af2fa`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F),
  τ ≠ 0 → AffineDualJT.paperBminusFactorProduct τ ∣ AffineDualJT.paperBminusAlternantPolynomial τ
```

### `AffineDualJT.paper_bminus_last_variable_difference_dvd`

SHA256 `b41cc5a9693870505e33b1146b49cab742d67e8a5ed2dfe989092d0c817ee6da`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F) (j : Fin n),
  MvPolynomial.X 0 - MvPolynomial.X j.succ ∣ AffineDualJT.paperBminusAlternantPolynomial t
```

### `AffineDualJT.paper_bminus_last_variable_factor_dvd`

SHA256 `001bace6efa0720a0448a256fa4987fdca481ec2b7b14e7c37349fac9ca014ec`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F) (j : Fin n),
  τ ≠ 0 →
    1 - MvPolynomial.C (τ ^ 2) * MvPolynomial.X j.succ * MvPolynomial.X 0 ∣
      AffineDualJT.paperBminusAlternantPolynomial τ
```

### `AffineDualJT.paper_bminus_row_factor_degreeOf_ne`

SHA256 `1666ea79ca729c837e3ed59bfeddd3fc39e229c3901c37578d42f74f239a197c`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F) (a x : Fin n),
  x ≠ a → MvPolynomial.degreeOf x (1 + MvPolynomial.C τ * MvPolynomial.X a) = 0
```

### `AffineDualJT.paper_bminus_row_factor_degreeOf_self`

SHA256 `1396fda5af26f384f2684bc0684d0c0931b59965babe435eda3f96551540a08a`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F),
  τ ≠ 0 → ∀ (a : Fin n), MvPolynomial.degreeOf a (1 + MvPolynomial.C τ * MvPolynomial.X a) = 1
```

### `AffineDualJT.paper_bminus_row_factor_irreducible`

SHA256 `1c98c01635e6c3565931f9f3b90340c5c7e8d8d8f64213389632ffc7c6324039`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F),
  τ ≠ 0 → ∀ (a : Fin n), Irreducible (1 + MvPolynomial.C τ * MvPolynomial.X a)
```

### `AffineDualJT.paper_bminus_row_factor_totalDegree`

SHA256 `cd88dfea522a500f4370948fd86cdeafcfced73206d4533da61d608b0a39aa12`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F),
  τ ≠ 0 → ∀ (a : Fin n), (1 + MvPolynomial.C τ * MvPolynomial.X a).totalDegree = 1
```

### `AffineDualJT.paper_bminus_row_isRelPrime_difference`

SHA256 `4ab005be7e84a82ef9b2d67f323c3d22aaa4134cf0a63751f2f0d4383ff374e2`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F) (a c d : Fin n),
  c ≠ d → IsRelPrime (1 + MvPolynomial.C τ * MvPolynomial.X a) (MvPolynomial.X c - MvPolynomial.X d)
```

### `AffineDualJT.paper_bminus_row_isRelPrime_reciprocal`

SHA256 `acc0949ad9bbe8b51628413a5f287d71b305aaa0be4b9b41bc674c9181e03008`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F),
  τ ≠ 0 →
    ∀ (a c d : Fin n),
      c ≠ d →
        IsRelPrime (1 + MvPolynomial.C τ * MvPolynomial.X a)
          (1 - MvPolynomial.C (τ ^ 2) * MvPolynomial.X c * MvPolynomial.X d)
```

### `AffineDualJT.paper_bminus_row_proportional`

SHA256 `b599979c5409757dc2607365cb1861ae6cec0abb091ebcd6d0af4c83558618de`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F) (z : Fin n → F) (a b : Fin n),
  a ≠ b →
    τ ≠ 0 →
      z a ≠ 0 →
        0 < n →
          z b = (τ ^ 2 * z a)⁻¹ →
            ∀ (r : Fin n),
              AffineDualJT.bminusAlternantColumn τ r (z b) =
                τ * (τ ^ 2 * z a)⁻¹ ^ n / z a ^ (n - 1) * AffineDualJT.bminusAlternantColumn τ r (z a)
```

### `AffineDualJT.paper_bminus_rows_isRelPrime`

SHA256 `7a822d4970ffbfacc7cf014522bd09bf15f978f52a069552633f20379e45431e`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F),
  τ ≠ 0 →
    ∀ (a b : Fin n),
      a ≠ b → IsRelPrime (1 + MvPolynomial.C τ * MvPolynomial.X a) (1 + MvPolynomial.C τ * MvPolynomial.X b)
```

### `AffineDualJT.paper_bminus_scale_lowest_coeff`

SHA256 `7e5f10fc10358b0543b1d7f79fe24cf9cf4656a22464fb699e28ca70f72aef4b`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F),
  (Polynomial.coeff (AffineDualJT.paperScaleHom (AffineDualJT.paperBminusAlternantPolynomial τ))) (n * (n - 1) / 2) =
    (Matrix.of fun a r => MvPolynomial.X a ^ (n - (↑r + 1))).det
```

### `AffineDualJT.paper_bminus_scaled_det_eval_zero`

SHA256 `2d1cb2ae586fafcb57b5955b5a0d3d831a1c6128cc4494b32242e1f805818c12`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F),
  Polynomial.eval 0 (AffineDualJT.paperBminusScaledMatrix τ).det =
    (Matrix.of fun a r => MvPolynomial.X a ^ (n - (↑r + 1))).det
```

### `AffineDualJT.paper_bminus_scaled_reduced_eval_zero`

SHA256 `96335d56719bdb6c0dc302bc9342e4ef17101290e5fd5d7c46831e7b679bc245`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F) (a r : Fin n),
  Polynomial.eval 0 (AffineDualJT.paperBminusScaledReduced τ a r) = MvPolynomial.X a ^ (n - (↑r + 1))
```

### `AffineDualJT.paper_cauchy_binet`

SHA256 `ae451458b4870d70f8f3a95767161be6d0da755b8b53f1835f0d8bfbbea77d8f`

```lean
∀ {F : Type u_1} [inst : Field F] {n l : ℕ} (A : Matrix (Fin n) (Fin l) F) (B : Matrix (Fin l) (Fin n) F),
  (A * B).det = ∑ Q, (A.submatrix id ⇑((↑Q).orderEmbOfFin ⋯)).det * (B.submatrix (⇑((↑Q).orderEmbOfFin ⋯)) id).det
```

### `AffineDualJT.paper_cauchy_binet_complement_sum`

SHA256 `555159d247747442f27633affd72f10f33fd05244b26f3533eb3e3bfd937ecb8`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (U Z : Matrix (Fin (n + k)) (Fin k) F),
  ∑ Q, (U.submatrix (⇑((↑Q)ᶜ.orderEmbOfFin ⋯)) id).det * (Z.submatrix (⇑((↑Q)ᶜ.orderEmbOfFin ⋯)) id).det =
    (U.transpose * Z).det
```

### `AffineDualJT.paper_cauchy_binet_fixed_subset`

SHA256 `015a0f5f382de5d54db49a65ea48045f6e7abc9b40c8677b5c2174e61957fb51`

```lean
∀ {F : Type u_1} [inst : Field F] {n l : ℕ} (A : Matrix (Fin n) (Fin l) F) (B : Matrix (Fin l) (Fin n) F)
  (Q : Finset (Fin l)) (hQ : Q.card = n),
  ∑ σ, (∏ i, B ((Q.orderEmbOfFin hQ) (σ i)) i) * (A.submatrix id fun i => (Q.orderEmbOfFin hQ) (σ i)).det =
    (A.submatrix id ⇑(Q.orderEmbOfFin hQ)).det * (B.submatrix (⇑(Q.orderEmbOfFin hQ)) id).det
```

### `AffineDualJT.paper_coeff_row_mul_X_pow`

SHA256 `4c5d62a20f57bc3292d9b7e402185073fbbaffd515de897806f0ad3c523c3bb2`

```lean
∀ {R : Type u_2} [inst : CommSemiring R] (f g : Polynomial R) (d : ℕ),
  (f * (Polynomial.X ^ d * g)).coeff d = (f * g).coeff 0
```

### `AffineDualJT.paper_coordinate_augmented_det`

SHA256 `79aa11ef434d7a13bb49f6587023790b7dbde94c034f40d179b7ebb6a2059f8e`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (U : Matrix (Fin (n + k)) (Fin k) F) (p : Fin k ⊕ Fin n ≃ Fin (n + k)),
  (AffineDualJT.paperRowStack✝ (Matrix.of fun i c => U ((AffineDualJT.paperSplitRows n k) c) i)
        (Matrix.of fun i c =>
          AffineDualJT.paperCoordinateVector✝ (p (Sum.inr i)) ((AffineDualJT.paperSplitRows n k) c))).det =
    ↑↑(Equiv.Perm.sign (p.trans (AffineDualJT.paperSplitRows n k).symm)) * (U.submatrix (fun j => p (Sum.inl j)) id).det
```

### `AffineDualJT.paper_ctColumn_totalDegree_le`

SHA256 `ab7e734c6ffb72671aa63e1206dbe7db649e4bfde1d6a61dd49345eecbade281`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F) (a r : Fin n),
  (AffineDualJT.ctAlternantColumn (MvPolynomial.C t) r (MvPolynomial.X a)).totalDegree ≤ n + ↑r + 1
```

### `AffineDualJT.paper_ct_alternant_totalDegree_le`

SHA256 `10a353dbe1b427a359ceb9415610df8599b653913eedb9a71c2d3c5cfefde9e7`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  (Matrix.of fun a r => AffineDualJT.ctAlternantColumn (MvPolynomial.C t) r (MvPolynomial.X a)).det.totalDegree ≤
    3 * Fintype.card (AffineDualJT.paperAlternantPairIndex n) + 2 * n
```

### `AffineDualJT.paper_ct_alternant_vanish_under_reciprocal`

SHA256 `3032b74756d117fbd349bda10f6e7a439c919cec2f6567e5b3136d8a6f1b968a`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F) (z : Fin n → F) (a b : Fin n),
  a ≠ b →
    t ≠ 0 →
      z a ≠ 0 → 0 < n → z b = (t * z a)⁻¹ → (Matrix.of fun i r => AffineDualJT.ctAlternantColumn t r (z i)).det = 0
```

### `AffineDualJT.paper_ct_column_degree_sum`

SHA256 `a48793165a7624486ea07b721aa789032ff91bbea87f0deb69cd45f38d8d89f5`

```lean
∀ (n : ℕ), ∑ r, (n + ↑r + 1) = 3 * (n * (n - 1) / 2) + 2 * n
```

### `AffineDualJT.paper_ct_column_extra_row_factor`

SHA256 `61ebe902aea5dfd66e352c41f8793aaf4a93c1f46853abbded65b109cc2c1639`

```lean
∀ {R : Type u_2} [inst : CommRing R] {n : ℕ} (t z : R) (r : Fin n),
  AffineDualJT.ctAlternantColumn t r z = (1 - t * z ^ 2) * AffineDualJT.paperCtRowQuotient t r z
```

### `AffineDualJT.paper_ct_determinant_extra_row_factors`

SHA256 `c068b6c8112e697f17f1e84829c729512d11e9ff844e33c058d0e3aa8cba3404`

```lean
∀ {R : Type u_2} [inst : CommRing R] {n : ℕ} (t : R) (z : Fin n → R),
  (Matrix.of fun a r => AffineDualJT.ctAlternantColumn t r (z a)).det =
    (∏ a, (1 - t * z a ^ 2)) * (Matrix.of fun a r => AffineDualJT.paperCtRowQuotient t r (z a)).det
```

### `AffineDualJT.paper_ct_difference_factor_dvd_any_pair`

SHA256 `1eec3e72ffe835da132bbc10786409172361d855210f2a4e2135d35e650cda19`

```lean
∀ {F : Type u_1} [inst : Field F] {N : ℕ} (t : F) (a b : Fin N),
  a ≠ b → MvPolynomial.X a - MvPolynomial.X b ∣ AffineDualJT.paperCtAlternantPolynomial t
```

### `AffineDualJT.paper_ct_factor_dvd_any_pair`

SHA256 `3c51c01331ba1e97457665d075dfbce2eb50844aecdec7536e7ec43e38d79cb1`

```lean
∀ {F : Type u_1} [inst : Field F] {N : ℕ} (t : F) (a b : Fin N),
  a ≠ b → t ≠ 0 → 1 - MvPolynomial.C t * MvPolynomial.X a * MvPolynomial.X b ∣ AffineDualJT.paperCtAlternantPolynomial t
```

### `AffineDualJT.paper_ct_factor_pairwise_isRelPrime`

SHA256 `68f6d1597becd6354562704a7809270a7486a651df514033a1ca0e5b1b2669ac`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 → Pairwise fun i j => IsRelPrime (AffineDualJT.paperCtFactor t i) (AffineDualJT.paperCtFactor t j)
```

### `AffineDualJT.paper_ct_factor_product_eq`

SHA256 `908a7efd4fb43a6ca856a39c03e3229997504881073b9bc9ecc4b4016f025899`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  AffineDualJT.paperCtFactorProduct t =
    (∏ a, (1 - MvPolynomial.C t * MvPolynomial.X a ^ 2)) * AffineDualJT.Nt (MvPolynomial.C t) MvPolynomial.X
```

### `AffineDualJT.paper_ct_factor_product_totalDegree`

SHA256 `13792afb6df00137c7e9fe54da295f1fe9ab7deddc222d8a20698d62c8e5ce65`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 → (AffineDualJT.paperCtFactorProduct t).totalDegree = ∑ i, (AffineDualJT.paperCtFactor t i).totalDegree
```

### `AffineDualJT.paper_ct_factor_product_totalDegree_eq`

SHA256 `d0091101eb705f6026c1c350b941f3a148d45dc7807b92952e09d95fb0bac445`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 →
    (AffineDualJT.paperCtFactorProduct t).totalDegree =
      3 * Fintype.card (AffineDualJT.paperAlternantPairIndex n) + 2 * n
```

### `AffineDualJT.paper_ct_factor_scale_lowest_coeff`

SHA256 `df0a24b18e6bc86a6949f4554f63610b3cfdb678dd09406feba773ad4abcf278`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  (Polynomial.coeff (AffineDualJT.paperScaleHom (AffineDualJT.paperCtFactorProduct t))) (n * (n - 1) / 2) =
    ∏ p, (MvPolynomial.X p.fst - MvPolynomial.X ↑p.snd)
```

### `AffineDualJT.paper_ct_factorization_by_lowest_part`

SHA256 `1e589caa1058ba8d6d724b9f24057abf88669f68e49628c62323839f3797ebc1`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 → AffineDualJT.paperCtAlternantPolynomial t = AffineDualJT.paperCtFactorProduct t
```

### `AffineDualJT.paper_ct_factorization_zero`

SHA256 `b647518bcd088c491c6802613f1927e087890c041064689e675d10935952b8d8`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ},
  AffineDualJT.paperCtAlternantPolynomial 0 = AffineDualJT.paperCtFactorProduct 0
```

### `AffineDualJT.paper_ct_full_factor_product_dvd`

SHA256 `0bd9a90825a2cc4f7a5842df778510a9c1667fcedb600a13b9eff5c40df8e3b7`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 → AffineDualJT.paperCtFactorProduct t ∣ AffineDualJT.paperCtAlternantPolynomial t
```

### `AffineDualJT.paper_ct_last_variable_difference_dvd`

SHA256 `4dd3068d1f24af1dc42987cd1db7acd1a57630d289571ddbcbc3d9b632262bc9`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F) (j : Fin n),
  MvPolynomial.X 0 - MvPolynomial.X j.succ ∣ AffineDualJT.paperCtAlternantPolynomial t
```

### `AffineDualJT.paper_ct_last_variable_factor_dvd`

SHA256 `63a4102d0f487b53eab1f52ccc60ed49f964810702339921ae9290d51c0a7e29`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F) (j : Fin n),
  t ≠ 0 → 1 - MvPolynomial.C t * MvPolynomial.X j.succ * MvPolynomial.X 0 ∣ AffineDualJT.paperCtAlternantPolynomial t
```

### `AffineDualJT.paper_ct_row_factor_degreeOf_ne`

SHA256 `dd6e332a7d8485c46121a063176437d68a21f1bb9b6856387d4096f3286c7c90`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F) (a x : Fin n),
  x ≠ a → MvPolynomial.degreeOf x (1 - MvPolynomial.C t * MvPolynomial.X a ^ 2) = 0
```

### `AffineDualJT.paper_ct_row_factor_degreeOf_self`

SHA256 `a4376641c826e1337207e665aedec4060a1bbcb1273802d65683397bf8c748d4`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 → ∀ (a : Fin n), MvPolynomial.degreeOf a (1 - MvPolynomial.C t * MvPolynomial.X a ^ 2) = 2
```

### `AffineDualJT.paper_ct_row_factor_totalDegree`

SHA256 `ddf39b7a7bf02dabfb605d5fd2d7028c8bc8f1d6bf936ee5f29388fde96e9a59`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 → ∀ (a : Fin n), (1 - MvPolynomial.C t * MvPolynomial.X a ^ 2).totalDegree = 2
```

### `AffineDualJT.paper_ct_row_isRelPrime_difference`

SHA256 `ab81b87b7569340a90a5de90b09110bd3d39ccfdf4ee088cc7f2ff6216cb02e9`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 →
    ∀ (a c d : Fin n),
      c ≠ d → IsRelPrime (1 - MvPolynomial.C t * MvPolynomial.X a ^ 2) (MvPolynomial.X c - MvPolynomial.X d)
```

### `AffineDualJT.paper_ct_row_isRelPrime_reciprocal`

SHA256 `ba8accfc9f36025bd4e6d46619a9b70207b4d1cd67cd20d892c9df98d5df2f9a`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 →
    ∀ (a b : Fin n),
      a ≠ b →
        IsRelPrime (1 - MvPolynomial.C t * MvPolynomial.X a ^ 2)
          (1 - MvPolynomial.C t * MvPolynomial.X a * MvPolynomial.X b)
```

### `AffineDualJT.paper_ct_row_isRelPrime_reciprocal_any`

SHA256 `d657c52e0e822420092df93e644bee5d44910856ca71bd1a83263d5adf6e474e`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 →
    ∀ (a c d : Fin n),
      c ≠ d →
        IsRelPrime (1 - MvPolynomial.C t * MvPolynomial.X a ^ 2)
          (1 - MvPolynomial.C t * MvPolynomial.X c * MvPolynomial.X d)
```

### `AffineDualJT.paper_ct_row_isRelPrime_sum`

SHA256 `bb681eb0b1ba6908ac5af7683dc1c9ff9e40cb4dffa41ebf1646bd7c841fedac`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 →
    ∀ (a b : Fin n),
      a ≠ b → IsRelPrime (1 - MvPolynomial.C t * MvPolynomial.X a ^ 2) (MvPolynomial.X a + MvPolynomial.X b)
```

### `AffineDualJT.paper_ct_row_proportional`

SHA256 `6dd31a511214a08c058380cf38a02108c319ad55e38ee89a1fc3d58477732a0b`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F) (z : Fin n → F) (a b : Fin n),
  a ≠ b →
    t ≠ 0 →
      z a ≠ 0 →
        0 < n →
          z b = (t * z a)⁻¹ →
            ∀ (r : Fin n),
              AffineDualJT.ctAlternantColumn t r (z b) =
                -(t * z a)⁻¹ ^ n / z a ^ n * AffineDualJT.ctAlternantColumn t r (z a)
```

### `AffineDualJT.paper_ct_rows_isRelPrime`

SHA256 `1922939e0c14d3b17ef62f1e7db4f11dfa89edf5c1ee555f79540123ca2b7863`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 →
    ∀ (a b : Fin n),
      a ≠ b → IsRelPrime (1 - MvPolynomial.C t * MvPolynomial.X a ^ 2) (1 - MvPolynomial.C t * MvPolynomial.X b ^ 2)
```

### `AffineDualJT.paper_ct_scale_lowest_coeff`

SHA256 `22aa55c051f343dae795981a90413a923fbf55d9f38bddd1431d0fcd270baa8e`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  (Polynomial.coeff (AffineDualJT.paperScaleHom (AffineDualJT.paperCtAlternantPolynomial t))) (n * (n - 1) / 2) =
    (Matrix.of fun a r => MvPolynomial.X a ^ (n - (↑r + 1))).det
```

### `AffineDualJT.paper_ct_scaled_det_eval_zero`

SHA256 `de07482dd8ce8e0a79d0c30cfe6997c5bd6c79632e40116eb6d22dbd22ea21b8`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  Polynomial.eval 0 (AffineDualJT.paperCtScaledMatrix t).det =
    (Matrix.of fun a r => MvPolynomial.X a ^ (n - (↑r + 1))).det
```

### `AffineDualJT.paper_ct_scaled_reduced_eval_zero`

SHA256 `6224a9932186c69ebf51ba26fe090f1bb6527801fbc3c321f0cab8dff2472690`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F) (a r : Fin n),
  Polynomial.eval 0 (AffineDualJT.paperCtScaledReduced t a r) = MvPolynomial.X a ^ (n - (↑r + 1))
```

### `AffineDualJT.paper_descending_vandermonde_eq_pair_product`

SHA256 `09156043f774e371ef0357a0c1cc9829f7d64d87ac386df2ae986d67b3e183b2`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ},
  (Matrix.of fun a r => MvPolynomial.X a ^ (n - (↑r + 1))).det = ∏ p, (MvPolynomial.X p.fst - MvPolynomial.X ↑p.snd)
```

### `AffineDualJT.paper_det_mul_fixed_image_fiber`

SHA256 `0f95531e46ad336a42b5b31bea4765629e9af5f077dda279c1a218a496d16950`

```lean
∀ {F : Type u_1} [inst : Field F] {n l : ℕ} (A : Matrix (Fin n) (Fin l) F) (B : Matrix (Fin l) (Fin n) F)
  (Q : Finset (Fin l)) (hQ : Q.card = n),
  ∑ f with Function.Injective f ∧ Finset.image f Finset.univ = Q, (∏ i, B (f i) i) * (A.submatrix id f).det =
    ∑ σ, (∏ i, B ((Q.orderEmbOfFin hQ) (σ i)) i) * (A.submatrix id fun i => (Q.orderEmbOfFin hQ) (σ i)).det
```

### `AffineDualJT.paper_det_mul_injective_intermediate`

SHA256 `e2ecd955da93cedd9f98efb2175d81d8c4ec6f901fbd98a657421e5441cefb1d`

```lean
∀ {F : Type u_1} [inst : Field F] {n l : ℕ} (A : Matrix (Fin n) (Fin l) F) (B : Matrix (Fin l) (Fin n) F),
  (A * B).det = ∑ f with Function.Injective f, (∏ i, B (f i) i) * (A.submatrix id f).det
```

### `AffineDualJT.paper_det_mul_intermediate_expansion`

SHA256 `b291880c486dccbb81b22de7f2231d79011e7085f66bfd6ce8cd5f005fbdc048`

```lean
∀ {F : Type u_1} [inst : Field F] {n l : ℕ} (A : Matrix (Fin n) (Fin l) F) (B : Matrix (Fin l) (Fin n) F),
  (A * B).det = ∑ f, ∑ σ, ↑↑(Equiv.Perm.sign σ) * ∏ i, A (σ i) (f i) * B (f i) i
```

### `AffineDualJT.paper_det_mul_intermediate_minors`

SHA256 `7b75faa8890e49d333c135234e6baab40856c3dc774c2d893b4a6a190976dffe`

```lean
∀ {F : Type u_1} [inst : Field F] {n l : ℕ} (A : Matrix (Fin n) (Fin l) F) (B : Matrix (Fin l) (Fin n) F),
  (A * B).det = ∑ f, (∏ i, B (f i) i) * (A.submatrix id f).det
```

### `AffineDualJT.paper_det_totalDegree_le_sum_column_bounds`

SHA256 `91f1a46383b557819c7c7fe6aae443741cafebb20ec38a775364a9bb6e51bedc`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (M : Matrix (Fin n) (Fin n) (MvPolynomial (Fin n) F)) (d : Fin n → ℕ),
  (∀ (i j : Fin n), (M i j).totalDegree ≤ d j) → M.det.totalDegree ≤ ∑ j, d j
```

### `AffineDualJT.paper_difference_factor_degreeOf_left`

SHA256 `bdcedf2463b280fee3fef4997cef716c57eb0f55708ed9390a3074e33125fb37`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (a b : Fin n),
  a ≠ b → MvPolynomial.degreeOf a (MvPolynomial.X a - MvPolynomial.X b) = 1
```

### `AffineDualJT.paper_difference_factor_degreeOf_outside`

SHA256 `b2ac0b37f012605e14d0edc1f8df8494d76eaa5553278245d619bf8e9da2d480`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (a b x : Fin n),
  x ≠ a → x ≠ b → MvPolynomial.degreeOf x (MvPolynomial.X a - MvPolynomial.X b) = 0
```

### `AffineDualJT.paper_difference_factor_degreeOf_right`

SHA256 `310e43378c0535b6114557693d77fe184a1c02e673f3c80164c7d78449851563`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (a b : Fin n),
  a ≠ b → MvPolynomial.degreeOf b (MvPolynomial.X a - MvPolynomial.X b) = 1
```

### `AffineDualJT.paper_difference_factor_irreducible`

SHA256 `698e7dddb018bc3441059f0e90bf09cae524959b9288c35c152f378e47e33dfc`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (a b : Fin n), a ≠ b → Irreducible (MvPolynomial.X a - MvPolynomial.X b)
```

### `AffineDualJT.paper_difference_factor_totalDegree`

SHA256 `9b492571dfb6612f3133dda2683d7ae99611e16e53e95176d3776c4fe7e59b6c`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (a b : Fin n), a ≠ b → (MvPolynomial.X a - MvPolynomial.X b).totalDegree = 1
```

### `AffineDualJT.paper_difference_isRelPrime_difference`

SHA256 `e3c0cba2af9d1a914e18139f9f57385fd133685229feff04e4c6f9a0a59141fd`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (a b c d : Fin n),
  a < b → c < d → a ≠ c ∨ b ≠ d → IsRelPrime (MvPolynomial.X a - MvPolynomial.X b) (MvPolynomial.X c - MvPolynomial.X d)
```

### `AffineDualJT.paper_fColumn_totalDegree_le`

SHA256 `fd63476330a999c29e1703611701c201a4004d6d045a6be86e678a92542d066f`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F) (a r : Fin n),
  (AffineDualJT.fColumn (MvPolynomial.C t) r (MvPolynomial.X a)).totalDegree ≤ n + ↑r - 1
```

### `AffineDualJT.paper_fin_upper_card`

SHA256 `c4ff927df7c0f654e255e1de5d8235b51e7880f441f551ba0dc8933d6d78b9c4`

```lean
∀ (n : ℕ) (a : Fin n), Fintype.card { b // a < b } = n - (↑a + 1)
```

### `AffineDualJT.paper_matrix_image_in_kernel`

SHA256 `dd018527bfec1f29223d67aa9862d3908ec5bf28d66dec4c6039c5be7120aeda`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (X : Matrix (Fin n) (Fin (n + k)) F) (U : Matrix (Fin (n + k)) (Fin k) F),
  X * U = 0 → U.mulVecLin.range ≤ X.mulVecLin.ker
```

### `AffineDualJT.paper_matrix_quotient_equiv`

SHA256 `a94e00eebfade4872659c4dc91686eb3771ee8ff0bfe18ab92d10c46e0a2e9c0`

```lean
{F : Type u_1} →
  [inst : Field F] →
    {n k : ℕ} →
      (X : Matrix (Fin n) (Fin (n + k)) F) →
        (U : Matrix (Fin (n + k)) (Fin k) F) →
          X * U = 0 →
            (AffineDualJT.firstCols X).det ≠ 0 →
              (AffineDualJT.tailRowsAfterN U).det ≠ 0 → ((Fin (n + k) → F) ⧸ U.mulVecLin.range) ≃ₗ[F] Fin n → F
```

### `AffineDualJT.paper_matrix_quotient_equiv_coordinate_apply`

SHA256 `865b66a49f883e328f7d85669113a6c975c1bcba52d5cea6c7f8a20b74b73520`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (X : Matrix (Fin n) (Fin (n + k)) F) (U : Matrix (Fin (n + k)) (Fin k) F)
  (hXU : X * U = 0) (hXQ0 : (AffineDualJT.firstCols X).det ≠ 0) (hUJ : (AffineDualJT.tailRowsAfterN U).det ≠ 0)
  (j : Fin (n + k)),
  (AffineDualJT.paper_matrix_quotient_equiv X U hXU hXQ0 hUJ)
      (U.mulVecLin.range.mkQ (AffineDualJT.paperCoordinateVector✝ j)) =
    X.col j
```

### `AffineDualJT.paper_matrix_quotient_equiv_mkQ_apply`

SHA256 `004876cf8f0155d772e0e262d326f2bb9dd27e099cb46a947e693e4307b440a0`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (X : Matrix (Fin n) (Fin (n + k)) F) (U : Matrix (Fin (n + k)) (Fin k) F)
  (hXU : X * U = 0) (hXQ0 : (AffineDualJT.firstCols X).det ≠ 0) (hUJ : (AffineDualJT.tailRowsAfterN U).det ≠ 0)
  (v : Fin (n + k) → F),
  (AffineDualJT.paper_matrix_quotient_equiv X U hXU hXQ0 hUJ) (U.mulVecLin.range.mkQ v) = X.mulVecLin v
```

### `AffineDualJT.paper_matrix_range_eq_kernel`

SHA256 `66655dec7c2ff608ecf3a2605df5d8e6ab360a824e3986067e0560acf430dbfc`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (X : Matrix (Fin n) (Fin (n + k)) F) (U : Matrix (Fin (n + k)) (Fin k) F),
  X * U = 0 →
    (AffineDualJT.firstCols X).det ≠ 0 → (AffineDualJT.tailRowsAfterN U).det ≠ 0 → U.mulVecLin.range = X.mulVecLin.ker
```

### `AffineDualJT.paper_nuBminus_ne_zero`

SHA256 `20b294c56e04888d8ccb672c2abdbe24fc5c9840f388fc850b9a090807aefa7d`

```lean
∀ {n : ℕ} (m k : ℕ), AffineDualJT.ExternalHL.nuBminus m k (AffineDualJT.paperParameter n) ≠ 0
```

### `AffineDualJT.paper_nuBplus_ne_zero`

SHA256 `ee868a0d9b761f074a994e0d29d31966d7325ccaa14406b9282226c8776b0510`

```lean
∀ {n : ℕ} (m k : ℕ), AffineDualJT.ExternalHL.nuBplus m k (AffineDualJT.paperParameter n) ≠ 0
```

### `AffineDualJT.paper_nuCt_ne_zero`

SHA256 `236c312bcc7f7354959123e663d4f7724ff66d385337fbe0418b8116a857d5a9`

```lean
∀ {n : ℕ} (m k : ℕ), AffineDualJT.ExternalHL.nuCt m k (AffineDualJT.paperParameter n) ≠ 0
```

### `AffineDualJT.paper_pochhammer_Bminus_ne_zero`

SHA256 `729beb3079f4889df4a6277eb97bc61ed43e6be5719d306ae66091ac30753efe`

```lean
∀ {n : ℕ} (m : ℕ),
  AffineDualJT.ExternalHL.pochhammer m (AffineDualJT.paperParameter n) (AffineDualJT.paperParameter n ^ 2) ≠ 0
```

### `AffineDualJT.paper_pochhammer_Bplus_ne_zero`

SHA256 `c0a3b5e9ae1c7883e944f1fad89fce26d974293a289220a526c865fae85793b8`

```lean
∀ {n : ℕ} (m : ℕ), AffineDualJT.ExternalHL.pochhammer m (-1) (AffineDualJT.paperParameter n) ≠ 0
```

### `AffineDualJT.paper_pochhammer_Ct_ne_zero`

SHA256 `4c37c97494ea4d94d0a444a54b4019260b349ebaca7b2a6809b350ede4aca5e0`

```lean
∀ {n : ℕ} (m : ℕ),
  AffineDualJT.ExternalHL.pochhammer m (-AffineDualJT.paperParameter n) (AffineDualJT.paperParameter n) ≠ 0
```

### `AffineDualJT.paper_quotient_coordinate_minor_relation`

SHA256 `0f8f1a83b99c856890925affc1a82f11939ac8c4e4a6e01da9ca036cf0f5ccaa`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (M : Matrix (Fin n) (Fin (n + k)) F) (U : Matrix (Fin (n + k)) (Fin k) F)
  (E : ((Fin (n + k) → F) ⧸ U.mulVecLin.range) ≃ₗ[F] Fin n → F),
  (∀ (j : Fin (n + k)), E (U.mulVecLin.range.mkQ (AffineDualJT.paperCoordinateVector✝ j)) = M.col j) →
    ∀ (p₀ p : Fin k ⊕ Fin n ≃ Fin (n + k)),
      (Matrix.of fun i j => M i (p (Sum.inr j))).det *
          (AffineDualJT.paperRowStack✝ (Matrix.of fun i c => U ((AffineDualJT.paperSplitRows n k) c) i)
              (Matrix.of fun i c =>
                AffineDualJT.paperCoordinateVector✝ (p₀ (Sum.inr i)) ((AffineDualJT.paperSplitRows n k) c))).det =
        (Matrix.of fun i j => M i (p₀ (Sum.inr j))).det *
          (AffineDualJT.paperRowStack✝ (Matrix.of fun i c => U ((AffineDualJT.paperSplitRows n k) c) i)
              (Matrix.of fun i c =>
                AffineDualJT.paperCoordinateVector✝ (p (Sum.inr i)) ((AffineDualJT.paperSplitRows n k) c))).det
```

### `AffineDualJT.paper_quotient_has_linear_section`

SHA256 `a1acc209b5ea268645189e82c9bd38f749a4be1171fc50374b7a8715363d950f`

```lean
∀ {F : Type u_1} {V : Type u_2} [inst : Field F] [inst_1 : AddCommGroup V] [inst_2 : Module F V] (S : Submodule F V),
  ∃ s, S.mkQ ∘ₗ s = LinearMap.id
```

### `AffineDualJT.paper_quotient_induced_map_injective`

SHA256 `72ccec4a2053c9551b9994bade3109cdd2c8c3748e52a1f8f8e71071b99bf761`

```lean
∀ {F : Type u_1} {V : Type u_2} {W : Type u_3} [inst : Field F] [inst_1 : AddCommGroup V] [inst_2 : Module F V]
  [inst_3 : AddCommGroup W] [inst_4 : Module F W] (S : Submodule F V) (f : V →ₗ[F] W) (hS : S = f.ker),
  Function.Injective ⇑(S.liftQ f ⋯)
```

### `AffineDualJT.paper_quotient_top_forms_proportional`

SHA256 `e0702504f203eb6eac41f6b8957bdbc87882bcc3fa66b14e911276521aa8a569`

```lean
∀ {F : Type u_1} {Q : Type u_2} [inst : Field F] [inst_1 : AddCommGroup Q] [inst_2 : Module F Q] {n k : ℕ}
  (e : Q ≃ₗ[F] Fin n → F) (U : Matrix (Fin (n + k)) (Fin k) F) (s : Q →ₗ[F] Fin (n + k) → F),
  AffineDualJT.paperFixedColumnDetAlternating U s =
    (((AffineDualJT.paperFixedColumnDetAlternating U s) fun i => ((Pi.basisFun F (Fin n)).map e.symm) i) /
        (AffineDualJT.paperImageTopForm e) fun i => ((Pi.basisFun F (Fin n)).map e.symm) i) •
      AffineDualJT.paperImageTopForm e
```

### `AffineDualJT.paper_reciprocal_factor_degreeOf_left`

SHA256 `f9323a428eed7b8fbdb4a33df0983866da955ed1b047f77ab73198dca8350739`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 →
    ∀ (a b : Fin n), a ≠ b → MvPolynomial.degreeOf a (1 - MvPolynomial.C t * MvPolynomial.X a * MvPolynomial.X b) = 1
```

### `AffineDualJT.paper_reciprocal_factor_degreeOf_outside`

SHA256 `498c7db73c72b6938ac805f51f69bf3819bf6c4685f666a6134a8e66a8e6b673`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 →
    ∀ (a b x : Fin n),
      x ≠ a → x ≠ b → MvPolynomial.degreeOf x (1 - MvPolynomial.C t * MvPolynomial.X a * MvPolynomial.X b) = 0
```

### `AffineDualJT.paper_reciprocal_factor_degreeOf_right`

SHA256 `8ef5ef7ee221f2d4dd92eb2696b81260604fd8917f2f9becb600f08f5e47a476`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 →
    ∀ (a b : Fin n), a ≠ b → MvPolynomial.degreeOf b (1 - MvPolynomial.C t * MvPolynomial.X a * MvPolynomial.X b) = 1
```

### `AffineDualJT.paper_reciprocal_factor_irreducible`

SHA256 `7af26a88c5f5aa067bb818bc8af9604750f02c31625fe2791acf129e572e06eb`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 → ∀ (a b : Fin n), a ≠ b → Irreducible (1 - MvPolynomial.C t * MvPolynomial.X a * MvPolynomial.X b)
```

### `AffineDualJT.paper_reciprocal_factor_totalDegree`

SHA256 `6213c5244a6701483ac58f74b5c5bb31717ccefc778235023e819b05d4e4b495`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 → ∀ (a b : Fin n), (1 - MvPolynomial.C t * MvPolynomial.X a * MvPolynomial.X b).totalDegree = 2
```

### `AffineDualJT.paper_reciprocal_isRelPrime_difference`

SHA256 `92c8ba0d9ce21d057d7f881a7192feb165edce6f8f8b239e7f4755452a1dbaac`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 →
    ∀ (a b c d : Fin n),
      a ≠ b →
        c ≠ d →
          IsRelPrime (1 - MvPolynomial.C t * MvPolynomial.X a * MvPolynomial.X b) (MvPolynomial.X c - MvPolynomial.X d)
```

### `AffineDualJT.paper_reciprocal_isRelPrime_reciprocal`

SHA256 `f297cd48ba3aba9b76d3fa89c512b9c7d6b93b754371e74aca0deac99db1fde9`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  t ≠ 0 →
    ∀ (a b c d : Fin n),
      a < b →
        c < d →
          a ≠ c ∨ b ≠ d →
            IsRelPrime (1 - MvPolynomial.C t * MvPolynomial.X a * MvPolynomial.X b)
              (1 - MvPolynomial.C t * MvPolynomial.X c * MvPolynomial.X d)
```

### `AffineDualJT.paper_scalar_quotient_of_dvd_of_totalDegree_le`

SHA256 `96c6b42cc91478fa049c68119d14fbb44c41a6cb7c288c2a11f561010b146624`

```lean
∀ {F : Type u_1} [inst : Field F] {σ : Type u_2} (p q : MvPolynomial σ F),
  p ∣ q → p ≠ 0 → q ≠ 0 → q.totalDegree ≤ p.totalDegree → ∃ c, q = p * MvPolynomial.C c
```

### `AffineDualJT.paper_scale_Nt`

SHA256 `dee42b72befad061e5308ca90ad71a4c32a6fb4fc8e5dc4cc8c4ab3aafba6237`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  AffineDualJT.paperScaleHom (AffineDualJT.Nt (MvPolynomial.C t) MvPolynomial.X) =
    Polynomial.X ^ Fintype.card (AffineDualJT.paperAlternantPairIndex n) * ∏ p, AffineDualJT.paperBasicScaledNtRest t p
```

### `AffineDualJT.paper_scale_basic_alternant`

SHA256 `69f9eaedbd5b7c028e18d8576ad80eff7408a4496567f9e167c4d14caed8f50a`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  AffineDualJT.paperScaleHom (AffineDualJT.paperBasicAlternantPolynomial t) =
    Polynomial.X ^ (n * (n - 1) / 2) * (AffineDualJT.paperBasicScaledMatrix t).det
```

### `AffineDualJT.paper_scale_bminusColumn`

SHA256 `64618130dd1f57d53c887c0f55c8ff494eece476ce9ee071ff012cc65f772f2f`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F) (a r : Fin n),
  AffineDualJT.paperScaleHom (AffineDualJT.bminusAlternantColumn (MvPolynomial.C τ) r (MvPolynomial.X a)) =
    Polynomial.X ^ (n - (↑r + 1)) * AffineDualJT.paperBminusScaledReduced τ a r
```

### `AffineDualJT.paper_scale_bminus_alternant`

SHA256 `eb4b6ea7c65c9093f085326e9b6fafb4c2abf26be82036913202423e41a2fd7f`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F),
  AffineDualJT.paperScaleHom (AffineDualJT.paperBminusAlternantPolynomial τ) =
    Polynomial.X ^ (n * (n - 1) / 2) * (AffineDualJT.paperBminusScaledMatrix τ).det
```

### `AffineDualJT.paper_scale_ctColumn`

SHA256 `e8d78f1b08a45986caca05708028a852a93bb1ea0f5227908c532212dc0184ca`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F) (a r : Fin n),
  AffineDualJT.paperScaleHom (AffineDualJT.ctAlternantColumn (MvPolynomial.C t) r (MvPolynomial.X a)) =
    Polynomial.X ^ (n - (↑r + 1)) * AffineDualJT.paperCtScaledReduced t a r
```

### `AffineDualJT.paper_scale_ct_alternant`

SHA256 `c294f879d0dccb6c885a5c06391e50e46cccc17d95ed50a26ad4c42d5eca6919`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F),
  AffineDualJT.paperScaleHom (AffineDualJT.paperCtAlternantPolynomial t) =
    Polynomial.X ^ (n * (n - 1) / 2) * (AffineDualJT.paperCtScaledMatrix t).det
```

### `AffineDualJT.paper_scale_fColumn`

SHA256 `df9ed605b0423db36878480ef09423c8ec1bb983691a05b6448adbcc157261ea`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F) (a r : Fin n),
  AffineDualJT.paperScaleHom (AffineDualJT.fColumn (MvPolynomial.C t) r (MvPolynomial.X a)) =
    Polynomial.X ^ (n - (↑r + 1)) * AffineDualJT.paperBasicScaledReduced t a r
```

### `AffineDualJT.paper_sum_factor_degreeOf_right`

SHA256 `5f11a78cce21304ea83e50db0c04928081bbc2022082d649cadacce8d63e4c2e`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (a b : Fin n),
  a ≠ b → MvPolynomial.degreeOf b (MvPolynomial.X a + MvPolynomial.X b) = 1
```

### `AffineDualJT.paper_sum_factor_irreducible`

SHA256 `8379920e0b283101fbdb8aeac25961b0516ee1ef4d1998d14fb8935b22353fc3`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (a b : Fin n), a ≠ b → Irreducible (MvPolynomial.X a + MvPolynomial.X b)
```

### `AffineDualJT.paper_transpose_quotient_equiv`

SHA256 `56ee69ca06f16ba8e50127c11bf1b82fe0fb0c3e13069c33e3fe42decd2466d5`

```lean
{F : Type u_1} →
  [inst : Field F] →
    {n k : ℕ} →
      (Y : Matrix (Fin (n + k)) (Fin n) F) →
        (Z : Matrix (Fin (n + k)) (Fin k) F) →
          Y.transpose * Z = 0 →
            (AffineDualJT.lastRowsY Y).det ≠ 0 →
              (AffineDualJT.firstRowsZ Z).det ≠ 0 → ((Fin (n + k) → F) ⧸ Z.mulVecLin.range) ≃ₗ[F] Fin n → F
```

### `AffineDualJT.paper_transpose_quotient_equiv_coordinate_apply`

SHA256 `7b7e4726a90f96b942b958d3311e34a70ab48f9b7f504573349f512f23548c5e`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (Y : Matrix (Fin (n + k)) (Fin n) F) (Z : Matrix (Fin (n + k)) (Fin k) F)
  (hYTZ : Y.transpose * Z = 0) (hYH : (AffineDualJT.lastRowsY Y).det ≠ 0) (hZI : (AffineDualJT.firstRowsZ Z).det ≠ 0)
  (j : Fin (n + k)),
  (AffineDualJT.paper_transpose_quotient_equiv Y Z hYTZ hYH hZI)
      (Z.mulVecLin.range.mkQ (AffineDualJT.paperCoordinateVector✝ j)) =
    Y.transpose.col j
```

### `AffineDualJT.paper_transpose_range_eq_kernel`

SHA256 `927188b38a84092723e9d8f6eddf9a74cc348b9649198db4b7547644a0648851`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (Y : Matrix (Fin (n + k)) (Fin n) F) (Z : Matrix (Fin (n + k)) (Fin k) F),
  Y.transpose * Z = 0 →
    (AffineDualJT.lastRowsY Y).det ≠ 0 →
      (AffineDualJT.firstRowsZ Z).det ≠ 0 → Z.mulVecLin.range = Y.transpose.mulVecLin.ker
```

### `AffineDualJT.paper_Vn_pow_ne_zero._proof_1_1`

SHA256 `b8b9ea88bb4e3b2bdd008273038fc84c9e251779fd6a1819f726f570f0b59a23`

```lean
∀ {n : ℕ} (d : ℕ), ¬0 < n + 1 → False
```

### `AffineDualJT.paper_XU_standard_complement_relation._proof_1_1`

SHA256 `e88df4696a77d56f1efe1ccb788b0f995c187c75e532b490c18ca67517988d90`

```lean
∀ {n k : ℕ} (j : Fin n), ¬↑j < n + k → False
```

### `AffineDualJT.paper_XU_standard_complement_relation._proof_1_2`

SHA256 `4dcc1ee114768a120ee0766288db380dfc25007fdcd559ce54453cbcbcf3d9af`

```lean
∀ {n k : ℕ} (i : Fin k), ¬n + ↑i < n + k → False
```

### `AffineDualJT.paper_YZ_standard_complement_relation._proof_1_1`

SHA256 `84b79b7127e34f62375746008580ba7d200398af7920f8e14ed1f215441dacdd`

```lean
∀ {n k : ℕ} (i : Fin n), ¬k + ↑i < n + k → False
```

### `AffineDualJT.paper_YZ_standard_complement_relation._proof_1_3`

SHA256 `c8fdb43d991d1088d14a31e8adcf8678a8d37703fbb5a67b15f72ef335fc0db6`

```lean
∀ {n k : ℕ} (i : Fin k), ¬↑i < n + k → False
```

### `AffineDualJT.paper_alternant_pairIndex_card_eq_triangular._proof_1_1`

SHA256 `e6af2801e2d8894e5c5d06638c61dde2756ed8f8a774afd014077478d5400721`

```lean
∀ (n i : ℕ), i < n → ¬n - (i + 1) = n - 1 - i → False
```

### `AffineDualJT.paper_basic_column_degree_sum._proof_1_1`

SHA256 `33088598317107af7f11c3ea729b1609c5cee6f65fa45df51e31c1512830141b`

```lean
∀ (n i : ℕ), i < n → ¬n + i - 1 = n - 1 + i → False
```

### `AffineDualJT.paper_basic_difference_factor_dvd_any_pair._proof_1_1`

SHA256 `7e850048aca6228074db6158098b21ed088fa2f9695a4ccec3c7ba107b194432`

```lean
∀ (n : ℕ) (a b : Fin (n + 1)),
  0 < ↑((Equiv.symm (Equiv.swap 0 b)) a) → ¬↑((Equiv.symm (Equiv.swap 0 b)) a) - 1 < n → False
```

### `AffineDualJT.paper_basic_difference_factor_dvd_any_pair._proof_1_2`

SHA256 `7b8f0bdc8d1b4fcbfb9070aab15d777168045ffea4aa8155260ef7ac6cbf01d3`

```lean
∀ (n : ℕ) (a b : Fin (n + 1)),
  0 < ↑((Equiv.symm (Equiv.swap 0 b)) a) →
    ¬↑((Equiv.symm (Equiv.swap 0 b)) a) - 1 + 1 = ↑((Equiv.symm (Equiv.swap 0 b)) a) → False
```

### `AffineDualJT.paper_basic_factor_dvd_any_pair._proof_1_1`

SHA256 `7e850048aca6228074db6158098b21ed088fa2f9695a4ccec3c7ba107b194432`

```lean
∀ (n : ℕ) (a b : Fin (n + 1)),
  0 < ↑((Equiv.symm (Equiv.swap 0 b)) a) → ¬↑((Equiv.symm (Equiv.swap 0 b)) a) - 1 < n → False
```

### `AffineDualJT.paper_basic_factor_dvd_any_pair._proof_1_2`

SHA256 `7b8f0bdc8d1b4fcbfb9070aab15d777168045ffea4aa8155260ef7ac6cbf01d3`

```lean
∀ (n : ℕ) (a b : Fin (n + 1)),
  0 < ↑((Equiv.symm (Equiv.swap 0 b)) a) →
    ¬↑((Equiv.symm (Equiv.swap 0 b)) a) - 1 + 1 = ↑((Equiv.symm (Equiv.swap 0 b)) a) → False
```

### `AffineDualJT.paper_basic_factor_pairwise_isRelPrime._simp_1_1`

SHA256 `263978eaae881a43cc3b87cf8ebdea40d0ca750f85d3b63f8e7d38d628f27955`

```lean
∀ {α : Type u_1} {β : α → Type u_4} {a₁ a₂ : α} {b₁ : β a₁} {b₂ : β a₂}, (⟨a₁, b₁⟩ = ⟨a₂, b₂⟩) = (a₁ = a₂ ∧ b₁ ≍ b₂)
```

### `AffineDualJT.paper_basic_factor_pairwise_isRelPrime._simp_1_3`

SHA256 `ac55820fdb298de402e162f71b9bf108ee9214580af36ca5ef30fd99d9278a0b`

```lean
∀ {α : Type u_1} [inst : CommMonoid α] {x y : α}, IsRelPrime x y = IsRelPrime y x
```

### `AffineDualJT.paper_basic_lower_exponent_sum._proof_1_1`

SHA256 `e6af2801e2d8894e5c5d06638c61dde2756ed8f8a774afd014077478d5400721`

```lean
∀ (n i : ℕ), i < n → ¬n - (i + 1) = n - 1 - i → False
```

### `AffineDualJT.paper_basic_row_proportional._simp_1_1`

SHA256 `75e4ecd33de4f3241c4d89639f51f7bd4cd39294eb84b7e3b8489468b1a4fd1c`

```lean
∀ {α : Type u_2} [inst : Zero α] [inst_1 : OfNat α 2] [NeZero 2], (2 = 0) = False
```

### `AffineDualJT.paper_basic_row_proportional._simp_1_2`

SHA256 `de9d78b8a15c9b3fd95ded624db29ca4095a24b2b7f3bd7b06e6f845e8c7373a`

```lean
∀ {α : Type u_2} [inst : Zero α] [inst_1 : OfNat α 3] [NeZero 3], (3 = 0) = False
```

### `AffineDualJT.paper_basic_row_proportional._simp_1_3`

SHA256 `f095a7325a3487c1a874180e0f2dd15d89789c9f251b3693e5871bd1e8ec9dd9`

```lean
∀ {α : Type u_2} [inst : Zero α] [inst_1 : OfNat α 4] [NeZero 4], (4 = 0) = False
```

### `AffineDualJT.paper_basic_row_proportional._simp_1_4`

SHA256 `0ddfa05159363e0bf5c0fbdef8a0e8ac202c85861144722454da7da3bb81f471`

```lean
∀ {M₀ : Type u_1} [inst : Mul M₀] [inst_1 : Zero M₀] [NoZeroDivisors M₀] {a b : M₀}, a ≠ 0 → b ≠ 0 → (a * b = 0) = False
```

### `AffineDualJT.paper_basic_row_proportional._simp_1_5`

SHA256 `742d0eeaa34c57bc37c131a15ca1aadbb0875699b0a7a71b21d125c07b9d3b3b`

```lean
∀ {M₀ : Type u_1} [inst : MonoidWithZero M₀] {a : M₀} [IsReduced M₀] (n : ℕ), a ≠ 0 → (a ^ n = 0) = False
```

### `AffineDualJT.paper_basic_row_proportional._simp_1_6`

SHA256 `c8dfb2b14d58a524bc2e747001f177907e580ab4866b5e60503beda8bc4fe564`

```lean
∀ {G₀ : Type u_3} [inst : GroupWithZero G₀] {a : G₀} (n : ℤ), a ≠ 0 → (a ^ n = 0) = False
```

### `AffineDualJT.paper_basic_row_proportional._simp_1_7`

SHA256 `d621791fa0d8f14cdf40988da1aa7d392b068ea0ff99595ae6676e9e2391dc51`

```lean
∀ {R : Type u_1} [inst : AddMonoidWithOne R] [CharZero R] (n : ℕ), (↑n + 1 = 0) = False
```

### `AffineDualJT.paper_basic_scaled_reduced_eval_zero._proof_1_1`

SHA256 `2af4f3a7862b240bb39539976ec4b9eb2b589765fb81af71a08ccd5b1ee95c24`

```lean
∀ {n : ℕ} (r : Fin n), ↑r = 0 → ¬n - 1 = n - (↑r + 1) → False
```

### `AffineDualJT.paper_bminusColumn_totalDegree_le._proof_1_1`

SHA256 `dcc27a19416813fc87ff592863a87336d0b209887310cd84dd846468bca6b47e`

```lean
∀ {n : ℕ} (r : Fin n), ¬n ≤ n + ↑r + (↑r + 1) → False
```

### `AffineDualJT.paper_bminus_column_degree_sum._proof_1_1`

SHA256 `4ad5796b3ae1d43615ce97b9ec086f882b5d3c118107e9bb486b17c6ae5cd0cd`

```lean
∀ (n : ℕ), ¬n = 0 → ¬n - 1 + 1 = n → False
```

### `AffineDualJT.paper_bminus_column_extra_row_factor._proof_1_1`

SHA256 `9cab11b07526c8f4af36233a78a1b76b235cd5d26c91f75a3f529f0e7c77be1f`

```lean
∀ {n : ℕ} (r : Fin n), ¬n + ↑r = n - (↑r + 1) + (2 * ↑r + 1) → False
```

### `AffineDualJT.paper_bminus_difference_factor_dvd_any_pair._proof_1_1`

SHA256 `7e850048aca6228074db6158098b21ed088fa2f9695a4ccec3c7ba107b194432`

```lean
∀ (n : ℕ) (a b : Fin (n + 1)),
  0 < ↑((Equiv.symm (Equiv.swap 0 b)) a) → ¬↑((Equiv.symm (Equiv.swap 0 b)) a) - 1 < n → False
```

### `AffineDualJT.paper_bminus_difference_factor_dvd_any_pair._proof_1_2`

SHA256 `7b8f0bdc8d1b4fcbfb9070aab15d777168045ffea4aa8155260ef7ac6cbf01d3`

```lean
∀ (n : ℕ) (a b : Fin (n + 1)),
  0 < ↑((Equiv.symm (Equiv.swap 0 b)) a) →
    ¬↑((Equiv.symm (Equiv.swap 0 b)) a) - 1 + 1 = ↑((Equiv.symm (Equiv.swap 0 b)) a) → False
```

### `AffineDualJT.paper_bminus_factor_dvd_any_pair._proof_1_1`

SHA256 `7e850048aca6228074db6158098b21ed088fa2f9695a4ccec3c7ba107b194432`

```lean
∀ (n : ℕ) (a b : Fin (n + 1)),
  0 < ↑((Equiv.symm (Equiv.swap 0 b)) a) → ¬↑((Equiv.symm (Equiv.swap 0 b)) a) - 1 < n → False
```

### `AffineDualJT.paper_bminus_factor_dvd_any_pair._proof_1_2`

SHA256 `7b8f0bdc8d1b4fcbfb9070aab15d777168045ffea4aa8155260ef7ac6cbf01d3`

```lean
∀ (n : ℕ) (a b : Fin (n + 1)),
  0 < ↑((Equiv.symm (Equiv.swap 0 b)) a) →
    ¬↑((Equiv.symm (Equiv.swap 0 b)) a) - 1 + 1 = ↑((Equiv.symm (Equiv.swap 0 b)) a) → False
```

### `AffineDualJT.paper_bminus_last_variable_factor_dvd._proof_1_1`

SHA256 `2a252a0689eba9e11bd7ac7967d01aabf13f00a426205d739783b6bd042f7fc9`

```lean
∀ {n : ℕ}, ¬0 < n.succ → False
```

### `AffineDualJT.paper_bminus_row_factor_degreeOf_ne._proof_1_1`

SHA256 `2fd0b7502c69f405a9c67773f75f426d70981cae036ebbd6f293869622980bbd`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (τ : F) (a x : Fin n),
  MvPolynomial.degreeOf x (1 + MvPolynomial.C τ * MvPolynomial.X a) ≤ 0 →
    ¬MvPolynomial.degreeOf x (1 + MvPolynomial.C τ * MvPolynomial.X a) = 0 → False
```

### `AffineDualJT.paper_bminus_row_isRelPrime_difference._proof_1_1`

SHA256 `c47ebe8b48cb04603bb0d3cbb05e8a5a3a6ffa3b8be9838a1e0b640c42ee911a`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (a c d : Fin n) (q : MvPolynomial (Fin n) F),
  MvPolynomial.degreeOf d (MvPolynomial.X c - MvPolynomial.X d) = 1 →
    MvPolynomial.degreeOf d (MvPolynomial.X c - MvPolynomial.X d) + MvPolynomial.degreeOf d q = 0 → False
```

### `AffineDualJT.paper_bminus_row_isRelPrime_difference._proof_1_2`

SHA256 `d2aeb390e40beeaf7a90dd608bd967b2c6a0ca6995360a00dcb64434fcd8db52`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (c d : Fin n) (q : MvPolynomial (Fin n) F),
  MvPolynomial.degreeOf c (MvPolynomial.X c - MvPolynomial.X d) = 1 →
    MvPolynomial.degreeOf c (MvPolynomial.X c - MvPolynomial.X d) + MvPolynomial.degreeOf c q = 0 → False
```

### `AffineDualJT.paper_bminus_row_isRelPrime_reciprocal._proof_1_1`

SHA256 `24e3a4e194bc213b30c654725763df70365f2abf4a277075c38218b1f410c69b`

```lean
2 ≤ 1 → False
```

### `AffineDualJT.paper_bminus_row_proportional._proof_1_1`

SHA256 `d82187cb0425241634306a864cd43abf46aafa74a19c1e4b462f1f17d72c52dc`

```lean
0 < 0 → False
```

### `AffineDualJT.paper_coordinate_augmented_det._simp_1_2`

SHA256 `70c707129b841ad68c2b1ec4e851ba4562d0290ae5f4e29ede8548240fe3aa25`

```lean
∀ {α : Sort u_1} {a b : α}, (a = b) = (b = a)
```

### `AffineDualJT.paper_ctColumn_totalDegree_le._proof_1_1`

SHA256 `aac261229c60e014b1510229f3d52c374a6668b61db1e6d161a7fde87c66365f`

```lean
∀ {n : ℕ} (r : Fin n), ¬n ≤ n + ↑r + 1 + (↑r + 1) → False
```

### `AffineDualJT.paper_ct_column_degree_sum._proof_1_1`

SHA256 `c2ec2eacdd381a8cf22d206cea39bacb258612db821f9fa2eb6ac8ae7e91fccc`

```lean
∀ (n i : ℕ), ¬n + i + 1 = n + 1 + i → False
```

### `AffineDualJT.paper_ct_column_degree_sum._proof_1_2`

SHA256 `4ad5796b3ae1d43615ce97b9ec086f882b5d3c118107e9bb486b17c6ae5cd0cd`

```lean
∀ (n : ℕ), ¬n = 0 → ¬n - 1 + 1 = n → False
```

### `AffineDualJT.paper_ct_column_extra_row_factor._proof_1_1`

SHA256 `7334474369365d2b77ccd87eff3a23648d66c74cb8f6a4c014926f46cfe8e82e`

```lean
∀ {n : ℕ} (r : Fin n), ¬↑r + 1 ≤ n → False
```

### `AffineDualJT.paper_ct_column_extra_row_factor._proof_1_2`

SHA256 `668a005760327e88fdce116ecd1bac27bb1522768a78145dead27e184699b6cd`

```lean
∀ {n : ℕ} (r : Fin n), ↑r + 1 ≤ n → ¬n + ↑r + 1 = n - (↑r + 1) + 2 * (↑r + 1) → False
```

### `AffineDualJT.paper_ct_difference_factor_dvd_any_pair._proof_1_1`

SHA256 `7e850048aca6228074db6158098b21ed088fa2f9695a4ccec3c7ba107b194432`

```lean
∀ (n : ℕ) (a b : Fin (n + 1)),
  0 < ↑((Equiv.symm (Equiv.swap 0 b)) a) → ¬↑((Equiv.symm (Equiv.swap 0 b)) a) - 1 < n → False
```

### `AffineDualJT.paper_ct_difference_factor_dvd_any_pair._proof_1_2`

SHA256 `7b8f0bdc8d1b4fcbfb9070aab15d777168045ffea4aa8155260ef7ac6cbf01d3`

```lean
∀ (n : ℕ) (a b : Fin (n + 1)),
  0 < ↑((Equiv.symm (Equiv.swap 0 b)) a) →
    ¬↑((Equiv.symm (Equiv.swap 0 b)) a) - 1 + 1 = ↑((Equiv.symm (Equiv.swap 0 b)) a) → False
```

### `AffineDualJT.paper_ct_factor_dvd_any_pair._proof_1_1`

SHA256 `7e850048aca6228074db6158098b21ed088fa2f9695a4ccec3c7ba107b194432`

```lean
∀ (n : ℕ) (a b : Fin (n + 1)),
  0 < ↑((Equiv.symm (Equiv.swap 0 b)) a) → ¬↑((Equiv.symm (Equiv.swap 0 b)) a) - 1 < n → False
```

### `AffineDualJT.paper_ct_factor_dvd_any_pair._proof_1_2`

SHA256 `7b8f0bdc8d1b4fcbfb9070aab15d777168045ffea4aa8155260ef7ac6cbf01d3`

```lean
∀ (n : ℕ) (a b : Fin (n + 1)),
  0 < ↑((Equiv.symm (Equiv.swap 0 b)) a) →
    ¬↑((Equiv.symm (Equiv.swap 0 b)) a) - 1 + 1 = ↑((Equiv.symm (Equiv.swap 0 b)) a) → False
```

### `AffineDualJT.paper_ct_last_variable_factor_dvd._proof_1_1`

SHA256 `2a252a0689eba9e11bd7ac7967d01aabf13f00a426205d739783b6bd042f7fc9`

```lean
∀ {n : ℕ}, ¬0 < n.succ → False
```

### `AffineDualJT.paper_ct_row_isRelPrime_difference._proof_1_1`

SHA256 `c47ebe8b48cb04603bb0d3cbb05e8a5a3a6ffa3b8be9838a1e0b640c42ee911a`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (a c d : Fin n) (q : MvPolynomial (Fin n) F),
  MvPolynomial.degreeOf d (MvPolynomial.X c - MvPolynomial.X d) = 1 →
    MvPolynomial.degreeOf d (MvPolynomial.X c - MvPolynomial.X d) + MvPolynomial.degreeOf d q = 0 → False
```

### `AffineDualJT.paper_ct_row_isRelPrime_difference._proof_1_2`

SHA256 `d2aeb390e40beeaf7a90dd608bd967b2c6a0ca6995360a00dcb64434fcd8db52`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (c d : Fin n) (q : MvPolynomial (Fin n) F),
  MvPolynomial.degreeOf c (MvPolynomial.X c - MvPolynomial.X d) = 1 →
    MvPolynomial.degreeOf c (MvPolynomial.X c - MvPolynomial.X d) + MvPolynomial.degreeOf c q = 0 → False
```

### `AffineDualJT.paper_ct_row_isRelPrime_reciprocal._proof_1_1`

SHA256 `24e3a4e194bc213b30c654725763df70365f2abf4a277075c38218b1f410c69b`

```lean
2 ≤ 1 → False
```

### `AffineDualJT.paper_ct_row_proportional._proof_1_1`

SHA256 `d82187cb0425241634306a864cd43abf46aafa74a19c1e4b462f1f17d72c52dc`

```lean
0 < 0 → False
```

### `AffineDualJT.paper_descending_vandermonde_eq_pair_product._proof_1_2`

SHA256 `3532b625628be75246bcf3a2f0038079172b3f8a80dee8978b1b81238701145d`

```lean
∀ {n : ℕ},
  ¬∑ i, Fintype.card { b // i < b } + ∑ i, Fintype.card { b // i < b } = 2 * ∑ i, Fintype.card { b // i < b } → False
```

### `AffineDualJT.paper_descending_vandermonde_eq_pair_product._simp_1_1`

SHA256 `cc81c77f7df55d14c1492d8ec5f96f6c29fbb461a7c1605e77a13ff626249de9`

```lean
∀ {α : Type u_1} [inst : Preorder α] [inst_1 : LocallyFiniteOrderTop α] {a x : α}, (x ∈ Finset.Ioi a) = (a < x)
```

### `AffineDualJT.paper_det_mul_injective_intermediate._simp_1_1`

SHA256 `68624debf114774d349f53d4c3484d719053117ac3dbc28483ebc62e20498db6`

```lean
∀ {α : Type u_1} {p : α → Prop} [inst : DecidablePred p] {s : Finset α} {a : α}, (a ∈ Finset.filter p s) = (a ∈ s ∧ p a)
```

### `AffineDualJT.paper_det_mul_injective_intermediate._simp_1_2`

SHA256 `4d715715c1d4d7e1b44c22b0a0c2c9a2b32ca0351c9d7fbfcb6eaf9f81ca4c14`

```lean
∀ {α : Type u_1} [inst : Fintype α] (x : α), (x ∈ Finset.univ) = True
```

### `AffineDualJT.paper_difference_factor_degreeOf_left._proof_1_1`

SHA256 `160b8861a737b53021b3e91ed952d1a9049a919a74fa2b05b25cd8c1889d8532`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (a b : Fin n),
  MvPolynomial.degreeOf a (MvPolynomial.X a - MvPolynomial.X b) ≠ 0 →
    MvPolynomial.degreeOf a (MvPolynomial.X a - MvPolynomial.X b) ≤ 1 →
      ¬MvPolynomial.degreeOf a (MvPolynomial.X a - MvPolynomial.X b) = 1 → False
```

### `AffineDualJT.paper_difference_factor_degreeOf_outside._proof_1_1`

SHA256 `36f34735ce23489406aa975f83ccf9d669b4156c6d415303763621f0cfbad94f`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (a b x : Fin n),
  MvPolynomial.degreeOf x (MvPolynomial.X a + -MvPolynomial.X b) ≤
      Max.max (MvPolynomial.degreeOf x (MvPolynomial.X a)) (MvPolynomial.degreeOf x (-MvPolynomial.X b)) →
    MvPolynomial.degreeOf x (MvPolynomial.X a) = 0 →
      MvPolynomial.degreeOf x (-MvPolynomial.X b) = 0 →
        ¬MvPolynomial.degreeOf x (MvPolynomial.X a + -MvPolynomial.X b) = 0 → False
```

### `AffineDualJT.paper_difference_factor_degreeOf_right._proof_1_1`

SHA256 `ee1fb0f29c665d07bbb2633ac01a7a70c8991365702bd01f15b88b8f1cedf433`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (a b : Fin n),
  MvPolynomial.degreeOf b (MvPolynomial.X a - MvPolynomial.X b) ≠ 0 →
    MvPolynomial.degreeOf b (MvPolynomial.X a - MvPolynomial.X b) ≤ 1 →
      ¬MvPolynomial.degreeOf b (MvPolynomial.X a - MvPolynomial.X b) = 1 → False
```

### `AffineDualJT.paper_difference_isRelPrime_difference._proof_1_1`

SHA256 `c57bc525ac6feba5a803b3a65dda2e3360b9f68440575c6ba17bccf602f23190`

```lean
∀ {n : ℕ} (a b c d : Fin n), a < b → c < d → a = d → b = c → False
```

### `AffineDualJT.paper_difference_isRelPrime_difference._proof_1_2`

SHA256 `5e05bfea6ed81dad436442e0e40ade50b51336e1d7fe1b09a805ab080d7b29b2`

```lean
∀ {n : ℕ} (a b c d : Fin n), a < b → a = d → b = d → False
```

### `AffineDualJT.paper_fColumn_totalDegree_le._proof_1_1`

SHA256 `3a1a488f63bea43770203eaa32fcb0856bd4fc254bde0e4356f987741669270d`

```lean
∀ {n : ℕ} (r : Fin n), ¬n ≤ n + ↑r - 1 + (↑r + 1) → False
```

### `AffineDualJT.paper_matrix_quotient_equiv._proof_1`

SHA256 `0411e0eab8ebb0bb831384c20e31a696a80070013d3294b6411109f3d2628f85`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (U : Matrix (Fin (n + k)) (Fin k) F),
  Module.finrank F ((Fin (n + k) → F) ⧸ U.mulVecLin.range) + k = Module.finrank F (Fin (n + k) → F) →
    Module.finrank F ↥U.mulVecLin.range = k →
      Module.finrank F ((Fin (n + k) → F) ⧸ U.mulVecLin.range) + k = n + k →
        ¬Module.finrank F ((Fin (n + k) → F) ⧸ U.mulVecLin.range) = n → False
```

### `AffineDualJT.paper_matrix_quotient_equiv._proof_2`

SHA256 `9a91fa1d1a1c0105cd874bcf84665200fa1edc4ade35b2c0b16daa7ac3f17692`

```lean
∀ {F : Type u_1} [inst : Field F], RingHomSurjective (RingHom.id F)
```

### `AffineDualJT.paper_matrix_quotient_equiv._proof_3`

SHA256 `fb7d5af131ff5431f518f6f6e83d16436a571a50d4199ee913dd384de03b63fe`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (X : Matrix (Fin n) (Fin (n + k)) F) (U : Matrix (Fin (n + k)) (Fin k) F),
  U.mulVecLin.range = X.mulVecLin.ker → U.mulVecLin.range ≤ X.mulVecLin.ker
```

### `AffineDualJT.paper_matrix_quotient_equiv._proof_4`

SHA256 `8cbbcd810736393642d21635da2ee164e5fbad3068c2ac3fbdfd70035a89a787`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (X : Matrix (Fin n) (Fin (n + k)) F) (U : Matrix (Fin (n + k)) (Fin k) F)
  (hS : U.mulVecLin.range = X.mulVecLin.ker), Function.Injective ⇑(U.mulVecLin.range.liftQ X.mulVecLin ⋯)
```

### `AffineDualJT.paper_matrix_quotient_equiv._proof_5`

SHA256 `466fa9291aa818c122bec22a8b57068538ad1016ca6c32be4419bd1a90dfa4d0`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (U : Matrix (Fin (n + k)) (Fin k) F),
  (AffineDualJT.tailRowsAfterN U).det ≠ 0 →
    Module.finrank F ((Fin (n + k) → F) ⧸ U.mulVecLin.range) = Module.finrank F (Fin n → F)
```

### `AffineDualJT.paper_matrix_quotient_equiv._proof_6`

SHA256 `143a4ab1ba18cc2a73d7de9187134a78e80ce329d7ae7af03150aae814ba6caf`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (U : Matrix (Fin (n + k)) (Fin k) F),
  FiniteDimensional F ((Fin (n + k) → F) ⧸ U.mulVecLin.range)
```

### `AffineDualJT.paper_matrix_quotient_equiv._proof_7`

SHA256 `1751c5ec33184372fa79a2c36f6bc3fb18baf8b55311108dd956fee627927a2a`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ}, FiniteDimensional F (Fin n → F)
```

### `AffineDualJT.paper_pochhammer_Bminus_ne_zero._proof_1_1`

SHA256 `76e337915743d07611e7a05048009b01ba9790a8b6ac21bfb6615af29280e49b`

```lean
∀ {n : ℕ}, ¬0 < n + 1 → False
```

### `AffineDualJT.paper_pochhammer_Bplus_ne_zero._proof_1_1`

SHA256 `76e337915743d07611e7a05048009b01ba9790a8b6ac21bfb6615af29280e49b`

```lean
∀ {n : ℕ}, ¬0 < n + 1 → False
```

### `AffineDualJT.paper_pochhammer_Ct_ne_zero._proof_1_1`

SHA256 `76e337915743d07611e7a05048009b01ba9790a8b6ac21bfb6615af29280e49b`

```lean
∀ {n : ℕ}, ¬0 < n + 1 → False
```

### `AffineDualJT.paper_quotient_top_forms_proportional._simp_1_1`

SHA256 `70c707129b841ad68c2b1ec4e851ba4562d0290ae5f4e29ede8548240fe3aa25`

```lean
∀ {α : Sort u_1} {a b : α}, (a = b) = (b = a)
```

### `AffineDualJT.paper_reciprocal_factor_degreeOf_outside._proof_1_1`

SHA256 `7aeb81d9ef7a6605158da876601259aaaa2dc941f97eb84d46906bca6ee511c1`

```lean
∀ {F : Type u_1} [inst : Field F] {n : ℕ} (t : F) (a b x : Fin n),
  MvPolynomial.degreeOf x (1 - MvPolynomial.C t * MvPolynomial.X a * MvPolynomial.X b) ≤ 0 →
    ¬MvPolynomial.degreeOf x (1 - MvPolynomial.C t * MvPolynomial.X a * MvPolynomial.X b) = 0 → False
```

### `AffineDualJT.paper_reciprocal_isRelPrime_difference._proof_1_1`

SHA256 `29c5bce75a6a8ba93ec63ac0af8e592035f50a9896d7dc9c3694c8bfe574314a`

```lean
2 ≤ 1 → False
```

### `AffineDualJT.paper_reciprocal_isRelPrime_reciprocal._proof_1_1`

SHA256 `c57bc525ac6feba5a803b3a65dda2e3360b9f68440575c6ba17bccf602f23190`

```lean
∀ {n : ℕ} (a b c d : Fin n), a < b → c < d → a = d → b = c → False
```

### `AffineDualJT.paper_reciprocal_isRelPrime_reciprocal._proof_1_2`

SHA256 `9bae3dd75f071ac3721dfb30f9eabcea3ec3ef8f97d52819b31eb69870859609`

```lean
∀ {n : ℕ} (a b c d : Fin n), a < b → a = d → b = d → False
```

### `AffineDualJT.paper_scalar_quotient_of_dvd_of_totalDegree_le._proof_1_1`

SHA256 `62e11a68c341bda2fb5ad5856066afca4fba74fd2502ecdcf73467238cb04c7f`

```lean
∀ {F : Type u_1} [inst : Field F] {σ : Type u_2} (p q r : MvPolynomial σ F),
  p.totalDegree + r.totalDegree ≤ p.totalDegree → ¬r.totalDegree = 0 → False
```

### `AffineDualJT.paper_scale_bminusColumn._proof_1_3`

SHA256 `9cab11b07526c8f4af36233a78a1b76b235cd5d26c91f75a3f529f0e7c77be1f`

```lean
∀ {n : ℕ} (r : Fin n), ¬n + ↑r = n - (↑r + 1) + (2 * ↑r + 1) → False
```

### `AffineDualJT.paper_scale_ctColumn._proof_1_3`

SHA256 `d5df9bada58b903050678a75f9da105123c2de366258dfc2fce8d21d3711d549`

```lean
∀ {n : ℕ} (r : Fin n), ¬n + ↑r + 1 = n - (↑r + 1) + 2 * (↑r + 1) → False
```

### `AffineDualJT.paper_scale_fColumn._proof_1_3`

SHA256 `14972c7ab826a98dd35d78ecc961a34a6ade80fdcf01fdd5299664d84b7d24f8`

```lean
∀ {n : ℕ} (r : Fin n), ¬n + ↑r - 1 = n - (↑r + 1) + 2 * ↑r → False
```

### `AffineDualJT.paper_transpose_quotient_equiv._proof_1`

SHA256 `5171ad85ebad83977a8e5f0c1bc01f169e0089c3614784664d45831d23626fb8`

```lean
∀ {F : Type u_1} [Field F] {n k : ℕ} (Z : Matrix (Fin (n + k)) (Fin k) F) (i : Fin k), ¬↑i < n + k → False
```

### `AffineDualJT.paper_transpose_quotient_equiv._proof_2`

SHA256 `720fe068a29bd3628bfe8c1c551cababec3f3875ec94b555eae2d2b77b99c6b4`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (Y : Matrix (Fin (n + k)) (Fin n) F) (Z : Matrix (Fin (n + k)) (Fin k) F),
  Y.transpose * Z = 0 → Z.mulVecLin.range ≤ Y.transpose.mulVecLin.ker
```

### `AffineDualJT.paper_transpose_quotient_equiv._proof_3`

SHA256 `7574a61eadffafaefadb00da0a2c7c7d9893f911297c8413a9a75fceef107fb4`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (Y : Matrix (Fin (n + k)) (Fin n) F) (Z : Matrix (Fin (n + k)) (Fin k) F),
  Z.mulVecLin.range = Y.transpose.mulVecLin.ker → Z.mulVecLin.range ≤ Y.transpose.mulVecLin.ker
```

### `AffineDualJT.paper_transpose_quotient_equiv._proof_4`

SHA256 `2c783371a108e0d6461edc9d2078500147812d49ebfefe026cb65da36d4462ac`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (Y : Matrix (Fin (n + k)) (Fin n) F) (Z : Matrix (Fin (n + k)) (Fin k) F)
  (hS : Z.mulVecLin.range = Y.transpose.mulVecLin.ker),
  Function.Injective ⇑(Z.mulVecLin.range.liftQ Y.transpose.mulVecLin ⋯)
```

### `AffineDualJT.paper_transpose_quotient_equiv._proof_5`

SHA256 `10727b03907aeb9e7752cd30e74fde4daafbf53512c60b1083e6169c7c593667`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (Z : Matrix (Fin (n + k)) (Fin k) F),
  (AffineDualJT.firstRowsZ Z).det ≠ 0 →
    Module.finrank F ((Fin (n + k) → F) ⧸ Z.mulVecLin.range) = Module.finrank F (Fin n → F)
```

### `AffineDualJT.paper_transpose_range_eq_kernel._proof_1_1`

SHA256 `84b79b7127e34f62375746008580ba7d200398af7920f8e14ed1f215441dacdd`

```lean
∀ {n k : ℕ} (i : Fin n), ¬k + ↑i < n + k → False
```

### `AffineDualJT.paper_transpose_range_eq_kernel._proof_1_2`

SHA256 `0720adb22e1a5118ba6743ea1c51a2e648874146c7b35889f1d99d30932a233b`

```lean
∀ {F : Type u_1} [inst : Field F] {n k : ℕ} (Y : Matrix (Fin (n + k)) (Fin n) F),
  Y.transpose.rank = n → ∀ (i : Fin k), ¬↑i < n + k → False
```

## 全部模块及声明 ID 索引

### `AffineDualJT.AdjacentColumns` (12)

- `AffineDualJT.adjacentColumnTransform`
- `AffineDualJT.adjacentColumnTransform_det`
- `AffineDualJT.det_hHat_eq_two_det_h`
- `AffineDualJT.hHatMatrix_eq_mul`
- `AffineDualJT.adjacentColumnTransform._proof_1`
- `AffineDualJT.adjacentColumnTransform.eq_1`
- `AffineDualJT.adjacentColumnTransform_det._proof_1_3`
- `AffineDualJT.adjacentColumnTransform_det._proof_1_4`
- `AffineDualJT.adjacentColumnTransform_det._simp_1_2`
- `AffineDualJT.hHatMatrix_eq_mul._proof_1_2`
- `AffineDualJT.hHatMatrix_eq_mul._proof_1_3`
- `AffineDualJT.hHatMatrix_eq_mul._proof_1_4`

### `AffineDualJT.AffineDetSum` (17)

- `AffineDualJT.AffineDetSum.EvenVector`
- `AffineDualJT.AffineDetSum.JK`
- `AffineDualJT.AffineDetSum.JKEven`
- `AffineDualJT.AffineDetSum.JKEven_zero`
- `AffineDualJT.AffineDetSum.JKOn`
- `AffineDualJT.AffineDetSum.JKOn_even`
- `AffineDualJT.AffineDetSum.JKOn_univ`
- `AffineDualJT.AffineDetSum.JK_zero`
- `AffineDualJT.AffineDetSum.det_fin_zero_eq_one`
- `AffineDualJT.AffineDetSum.evenVector_zero`
- `AffineDualJT.AffineDetSum.jkMatrix`
- `AffineDualJT.AffineDetSum.weighted_shift_hasFiniteSupport`
- `AffineDualJT.AffineDetSum.EvenVector.eq_1`
- `AffineDualJT.AffineDetSum.JK.eq_1`
- `AffineDualJT.AffineDetSum.JKEven.eq_1`
- `AffineDualJT.AffineDetSum.JKOn.eq_1`
- `AffineDualJT.AffineDetSum.evenVector_zero._simp_1`

### `AffineDualJT.AffineParity` (10)

- `AffineDualJT.JKEven_projector`
- `AffineDualJT.jkMatrix_signed_det`
- `AffineDualJT.neg_one_zpow_sum`
- `AffineDualJT.JKEven_projector._simp_1_1`
- `AffineDualJT.JKEven_projector._simp_1_2`
- `AffineDualJT.JKEven_projector._simp_1_3`
- `AffineDualJT.JKEven_projector._simp_1_4`
- `AffineDualJT.JKEven_projector._simp_1_5`
- `AffineDualJT.JKEven_projector._simp_1_6`
- `AffineDualJT.JKEven_projector._simp_1_7`

### `AffineDualJT.AlternantFactorization` (9)

- `AffineDualJT.bminusAlternantColumn_row_factor`
- `AffineDualJT.ctAlternantColumn_row_factor`
- `AffineDualJT.fColumn_row_factor`
- `AffineDualJT.bminusAlternantColumn_row_factor._proof_1_1`
- `AffineDualJT.bminusAlternantColumn_row_factor._proof_1_2`
- `AffineDualJT.ctAlternantColumn_row_factor._proof_1_1`
- `AffineDualJT.ctAlternantColumn_row_factor._proof_1_2`
- `AffineDualJT.fColumn_row_factor._proof_1_1`
- `AffineDualJT.fColumn_row_factor._proof_1_2`

### `AffineDualJT.AlternantMatrices` (11)

- `AffineDualJT.bminusAlternantColumn`
- `AffineDualJT.ctAlternantColumn`
- `AffineDualJT.fColumn`
- `AffineDualJT.map_Nt`
- `AffineDualJT.map_bminusAlternantColumn`
- `AffineDualJT.map_ctAlternantColumn`
- `AffineDualJT.map_fColumn`
- `AffineDualJT.Nt.eq_1`
- `AffineDualJT.bminusAlternantColumn.eq_1`
- `AffineDualJT.ctAlternantColumn.eq_1`
- `AffineDualJT.fColumn.eq_1`

### `AffineDualJT.AlternantPaperRoute` (16)

- `AffineDualJT.paper_basic_alternant_vanish_under_reciprocal`
- `AffineDualJT.paper_basic_row_proportional`
- `AffineDualJT.paper_bminus_alternant_vanish_under_reciprocal`
- `AffineDualJT.paper_bminus_row_proportional`
- `AffineDualJT.paper_ct_alternant_vanish_under_reciprocal`
- `AffineDualJT.paper_ct_row_proportional`
- `_private.AffineDualJT.AlternantPaperRoute.0.AffineDualJT.paper_det_zero_of_row_smul`
- `AffineDualJT.paper_basic_row_proportional._simp_1_1`
- `AffineDualJT.paper_basic_row_proportional._simp_1_2`
- `AffineDualJT.paper_basic_row_proportional._simp_1_3`
- `AffineDualJT.paper_basic_row_proportional._simp_1_4`
- `AffineDualJT.paper_basic_row_proportional._simp_1_5`
- `AffineDualJT.paper_basic_row_proportional._simp_1_6`
- `AffineDualJT.paper_basic_row_proportional._simp_1_7`
- `AffineDualJT.paper_bminus_row_proportional._proof_1_1`
- `AffineDualJT.paper_ct_row_proportional._proof_1_1`

### `AffineDualJT.AlternantPolynomials` (34)

- `AffineDualJT.alternantPolyBasic`
- `AffineDualJT.alternantPolyBasic_eval`
- `AffineDualJT.alternantPolyBminus`
- `AffineDualJT.alternantPolyBminus_eval`
- `AffineDualJT.alternantPolyCt`
- `AffineDualJT.alternantPolyCt_eval`
- `AffineDualJT.dickson_first_eval`
- `AffineDualJT.dickson_second_eval`
- `_private.AffineDualJT.AlternantPolynomials.0.AffineDualJT.alternantPolyBminus_add_two`
- `AffineDualJT.alternantPolyBasic.eq_1`
- `AffineDualJT.alternantPolyBasic_eval._simp_1_2`
- `AffineDualJT.alternantPolyBasic_eval._simp_1_3`
- `AffineDualJT.alternantPolyBasic_eval._simp_1_4`
- `AffineDualJT.alternantPolyBasic_eval._simp_1_5`
- `AffineDualJT.alternantPolyBasic_eval._simp_1_6`
- `AffineDualJT.alternantPolyBasic_eval._simp_1_7`
- `AffineDualJT.alternantPolyBasic_eval._simp_1_8`
- `AffineDualJT.alternantPolyBminus.eq_1`
- `AffineDualJT.alternantPolyBminus_eval._f`
- `AffineDualJT.alternantPolyBminus_eval.match_1_1`
- `AffineDualJT.alternantPolyCt_eval._proof_1_8`
- `AffineDualJT.alternantPolyCt_eval._proof_1_9`
- `AffineDualJT.alternantPolyCt_eval._simp_1_1`
- `AffineDualJT.alternantPolyCt_eval._simp_1_2`
- `AffineDualJT.alternantPolyCt_eval._simp_1_3`
- `AffineDualJT.alternantPolyCt_eval._simp_1_4`
- `AffineDualJT.alternantPolyCt_eval._simp_1_5`
- `AffineDualJT.alternantPolyCt_eval._simp_1_6`
- `AffineDualJT.alternantPolyCt_eval._simp_1_7`
- `AffineDualJT.dickson_first_eval._f`
- `AffineDualJT.dickson_first_eval.match_1_1`
- `AffineDualJT.dickson_second_eval._f`
- `AffineDualJT.dickson_second_eval.match_1_1`
- `_private.AffineDualJT.AlternantPolynomials.0.AffineDualJT.alternantPolyBminus_add_two._simp_1_2`

### `AffineDualJT.Basic` (41)

- `AffineDualJT.hHatKernel`
- `AffineDualJT.hHatKernel_hasFiniteSupport`
- `AffineDualJT.hHat_eq_h_add_shift`
- `AffineDualJT.hKernel`
- `AffineDualJT.hKernel_hasFiniteSupport`
- `AffineDualJT.hKernel_reflect`
- `AffineDualJT.hKernel_zero_of_gt`
- `AffineDualJT.hPlusKernel`
- `AffineDualJT.hPlusKernel_hasFiniteSupport`
- `AffineDualJT.hPlusKernel_reflect`
- `AffineDualJT.hPlusKernel_zero_of_gt`
- `AffineDualJT.lambdaKernel`
- `AffineDualJT.lambdaKernel_hasFiniteSupport`
- `AffineDualJT.lambdaKernel_neg`
- `AffineDualJT.lambdaKernel_zero`
- `AffineDualJT.lambdaKernel_zero_of_gt`
- `AffineDualJT.paperIndex`
- `AffineDualJT.paperIndex_eq`
- `AffineDualJT.paperIndex_le`
- `AffineDualJT.paperIndex_pos`
- `AffineDualJT.hHatKernel.eq_1`
- `AffineDualJT.hHatKernel_hasFiniteSupport._proof_1_1`
- `AffineDualJT.hHatKernel_hasFiniteSupport._proof_1_2`
- `AffineDualJT.hKernel.eq_1`
- `AffineDualJT.hKernel_hasFiniteSupport._proof_1_1`
- `AffineDualJT.hKernel_hasFiniteSupport._proof_1_2`
- `AffineDualJT.hKernel_zero_of_gt._proof_1_2`
- `AffineDualJT.hKernel_zero_of_gt._proof_1_3`
- `AffineDualJT.hPlusKernel.eq_1`
- `AffineDualJT.hPlusKernel_hasFiniteSupport._proof_1_1`
- `AffineDualJT.hPlusKernel_hasFiniteSupport._proof_1_2`
- `AffineDualJT.hPlusKernel_zero_of_gt._proof_1_2`
- `AffineDualJT.hPlusKernel_zero_of_gt._proof_1_3`
- `AffineDualJT.lambdaKernel.eq_1`
- `AffineDualJT.lambdaKernel_hasFiniteSupport._proof_1_1`
- `AffineDualJT.lambdaKernel_hasFiniteSupport._proof_1_2`
- `AffineDualJT.lambdaKernel_neg._simp_1_2`
- `AffineDualJT.lambdaKernel_zero_of_gt._proof_1_2`
- `AffineDualJT.lambdaKernel_zero_of_gt._proof_1_3`
- `AffineDualJT.paperIndex.eq_1`
- `AffineDualJT.paperIndex_le._proof_1_2`

### `AffineDualJT.BracketEvaluation` (66)

- `AffineDualJT.Cfun_neg`
- `AffineDualJT.PhiB_bracket`
- `AffineDualJT.PhiC_bracket`
- `AffineDualJT.PhiPlus_bracket`
- `AffineDualJT.bracketB_paperIndex`
- `AffineDualJT.bracketB_reflect`
- `AffineDualJT.bracketB_sum`
- `AffineDualJT.bracketC_neg`
- `AffineDualJT.bracketC_paperIndex`
- `AffineDualJT.bracketC_sum`
- `AffineDualJT.bracketPlus_paperIndex`
- `AffineDualJT.bracketPlus_reflect`
- `AffineDualJT.exists_paperIndex`
- `AffineDualJT.paperIndex_injective`
- `AffineDualJT.phi_neg`
- `AffineDualJT.psi_reflect`
- `_private.AffineDualJT.BracketEvaluation.0.AffineDualJT.bracketB_sum_positive`
- `_private.AffineDualJT.BracketEvaluation.0.AffineDualJT.bracketC_sum_positive`
- `AffineDualJT.Cfun.eq_1`
- `AffineDualJT.PhiB.eq_1`
- `AffineDualJT.PhiC.eq_1`
- `AffineDualJT.PhiPlus.eq_1`
- `AffineDualJT.PhiPlus_bracket._proof_1_4`
- `AffineDualJT.PhiPlus_bracket._proof_1_5`
- `AffineDualJT.PhiPlus_bracket._simp_1_2`
- `AffineDualJT.bracketB.eq_1`
- `AffineDualJT.bracketB_paperIndex._proof_1_2`
- `AffineDualJT.bracketB_reflect._proof_1_2`
- `AffineDualJT.bracketB_reflect._proof_1_3`
- `AffineDualJT.bracketB_reflect._proof_1_4`
- `AffineDualJT.bracketB_sum._proof_1_1`
- `AffineDualJT.bracketB_sum._proof_1_2`
- `AffineDualJT.bracketB_sum._proof_1_3`
- `AffineDualJT.bracketC.eq_1`
- `AffineDualJT.bracketC_neg._proof_1_2`
- `AffineDualJT.bracketC_neg._proof_1_3`
- `AffineDualJT.bracketC_neg._proof_1_4`
- `AffineDualJT.bracketC_neg._proof_1_5`
- `AffineDualJT.bracketC_neg._proof_1_6`
- `AffineDualJT.bracketC_neg._proof_1_7`
- `AffineDualJT.bracketC_paperIndex._proof_1_2`
- `AffineDualJT.bracketC_sum._proof_1_1`
- `AffineDualJT.bracketC_sum._proof_1_3`
- `AffineDualJT.bracketC_sum._proof_1_4`
- `AffineDualJT.bracketC_sum._proof_1_5`
- `AffineDualJT.bracketC_sum._proof_1_6`
- `AffineDualJT.bracketPlus.eq_1`
- `AffineDualJT.bracketPlus_paperIndex._proof_1_1`
- `AffineDualJT.bracketPlus_paperIndex._proof_1_3`
- `AffineDualJT.bracketPlus_paperIndex._proof_1_4`
- `AffineDualJT.bracketPlus_reflect._proof_1_10`
- `AffineDualJT.bracketPlus_reflect._proof_1_11`
- `AffineDualJT.bracketPlus_reflect._proof_1_2`
- `AffineDualJT.bracketPlus_reflect._proof_1_3`
- `AffineDualJT.bracketPlus_reflect._proof_1_4`
- `AffineDualJT.bracketPlus_reflect._proof_1_5`
- `AffineDualJT.bracketPlus_reflect._proof_1_6`
- `AffineDualJT.bracketPlus_reflect._proof_1_7`
- `AffineDualJT.bracketPlus_reflect._proof_1_8`
- `AffineDualJT.bracketPlus_reflect._proof_1_9`
- `AffineDualJT.exists_paperIndex._proof_1_1`
- `AffineDualJT.exists_paperIndex._proof_1_2`
- `AffineDualJT.paperIndex_injective._proof_1_1`
- `AffineDualJT.phi.eq_1`
- `_private.AffineDualJT.BracketEvaluation.0.AffineDualJT.bracketB_sum_positive._simp_1_1`
- `_private.AffineDualJT.BracketEvaluation.0.AffineDualJT.bracketC_sum_positive._simp_1_1`

### `AffineDualJT.ClassicalColumns` (22)

- `AffineDualJT.VB0_zero`
- `AffineDualJT.VBC_zero`
- `AffineDualJT.VBminus_zero`
- `AffineDualJT.VBplus_zero`
- `AffineDualJT.VBt_zero`
- `AffineDualJT.VC0_zero`
- `AffineDualJT.VCt_zero`
- `_private.AffineDualJT.ClassicalColumns.0.AffineDualJT.leadingB`
- `_private.AffineDualJT.ClassicalColumns.0.AffineDualJT.leadingC`
- `_private.AffineDualJT.ClassicalColumns.0.AffineDualJT.leadingPlus`
- `AffineDualJT.VBminus_zero._proof_1_1`
- `AffineDualJT.VCt_zero._proof_1_1`
- `_private.AffineDualJT.ClassicalColumns.0.AffineDualJT.leadingB._proof_1_1`
- `_private.AffineDualJT.ClassicalColumns.0.AffineDualJT.leadingB._proof_1_2`
- `_private.AffineDualJT.ClassicalColumns.0.AffineDualJT.leadingB._proof_1_3`
- `_private.AffineDualJT.ClassicalColumns.0.AffineDualJT.leadingC._proof_1_1`
- `_private.AffineDualJT.ClassicalColumns.0.AffineDualJT.leadingC._proof_1_2`
- `_private.AffineDualJT.ClassicalColumns.0.AffineDualJT.leadingC._proof_1_3`
- `_private.AffineDualJT.ClassicalColumns.0.AffineDualJT.leadingPlus._proof_1_1`
- `_private.AffineDualJT.ClassicalColumns.0.AffineDualJT.leadingPlus._proof_1_2`
- `_private.AffineDualJT.ClassicalColumns.0.AffineDualJT.leadingPlus._proof_1_3`
- `_private.AffineDualJT.ClassicalColumns.0.AffineDualJT.leadingPlus._proof_1_4`

### `AffineDualJT.ClassicalCorollary` (22)

- `AffineDualJT.cor_6_2_B0_zero_quotient`
- `AffineDualJT.cor_6_2_Bplus_zero_quotient`
- `AffineDualJT.cor_6_2_Bt_zero_affine`
- `AffineDualJT.cor_6_2_C0_zero_quotient`
- `AffineDualJT.cor_6_2_Ct_zero_parity_bridge`
- `AffineDualJT.cor_6_2_Ct_zero_via_parity`
- `AffineDualJT.cor_6_2_eq_6_1`
- `AffineDualJT.cor_6_2_eq_6_2a`
- `AffineDualJT.cor_6_2_eq_6_2b`
- `AffineDualJT.cor_6_2_eq_6_2b_ratio`
- `AffineDualJT.cor_6_2_eq_6_3`
- `_private.AffineDualJT.ClassicalCorollary.0.AffineDualJT.classical_PhiB_mul`
- `_private.AffineDualJT.ClassicalCorollary.0.AffineDualJT.classical_PhiC_mul`
- `_private.AffineDualJT.ClassicalCorollary.0.AffineDualJT.classical_PhiPlus_mul`
- `AffineDualJT.cor_6_2_Bt_zero_affine._proof_1_1`
- `AffineDualJT.cor_6_2_eq_6_1._proof_1_1`
- `AffineDualJT.cor_6_2_eq_6_2a._proof_1_1`
- `AffineDualJT.cor_6_2_eq_6_2b_ratio._proof_1_1`
- `AffineDualJT.cor_6_2_eq_6_3._proof_1_1`
- `AffineDualJT.lastRowsY.eq_1`
- `_private.AffineDualJT.ClassicalCorollary.0.AffineDualJT.classical_PhiPlus_mul._proof_1_2`
- `_private.AffineDualJT.ClassicalCorollary.0.AffineDualJT.classical_PhiPlus_mul._proof_1_3`

### `AffineDualJT.ClassicalSpecialization` (8)

- `AffineDualJT.classical_parity_minor_identity`
- `AffineDualJT.classical_parity_minor_identity._simp_1_1`
- `AffineDualJT.classical_parity_minor_identity._simp_1_2`
- `AffineDualJT.classical_parity_minor_identity._simp_1_3`
- `AffineDualJT.classical_parity_minor_identity._simp_1_4`
- `AffineDualJT.classical_parity_minor_identity._simp_1_5`
- `AffineDualJT.classical_parity_minor_identity._simp_1_6`
- `AffineDualJT.classical_parity_minor_identity._simp_1_7`

### `AffineDualJT.ClassicalTransfer` (6)

- `AffineDualJT.classicalV`
- `AffineDualJT.classical_phi_mul`
- `AffineDualJT.prod_first_sign`
- `AffineDualJT.classicalV._proof_1`
- `AffineDualJT.classicalV._proof_2`
- `AffineDualJT.zetaSign.eq_1`

### `AffineDualJT.CoefficientMatrices` (7)

- `AffineDualJT.DB`
- `AffineDualJT.DC`
- `AffineDualJT.DPlus`
- `AffineDualJT.omegaSign`
- `AffineDualJT.rowSign`
- `AffineDualJT.rowSign_eq_zpow`
- `AffineDualJT.zetaSign`

### `AffineDualJT.CoefficientMinors` (25)

- `AffineDualJT.lemma_3_2_minor_DB`
- `AffineDualJT.lemma_3_2_minor_DC`
- `AffineDualJT.lemma_3_2_minor_DPlus`
- `AffineDualJT.prod_tail_rowSign`
- `_private.AffineDualJT.CoefficientMinors.0.AffineDualJT.hPlus_tail_entry`
- `_private.AffineDualJT.CoefficientMinors.0.AffineDualJT.h_tail_entry`
- `_private.AffineDualJT.CoefficientMinors.0.AffineDualJT.lambda_tail_entry`
- `AffineDualJT.lemma_3_2_minor_DB._proof_1_1`
- `AffineDualJT.lemma_3_2_minor_DB._proof_1_3`
- `AffineDualJT.lemma_3_2_minor_DB._proof_1_4`
- `AffineDualJT.lemma_3_2_minor_DB._simp_1_2`
- `AffineDualJT.lemma_3_2_minor_DC._proof_1_1`
- `AffineDualJT.lemma_3_2_minor_DC._proof_1_3`
- `AffineDualJT.lemma_3_2_minor_DC._proof_1_4`
- `AffineDualJT.lemma_3_2_minor_DC._simp_1_2`
- `AffineDualJT.lemma_3_2_minor_DPlus._proof_1_1`
- `AffineDualJT.lemma_3_2_minor_DPlus._proof_1_4`
- `AffineDualJT.lemma_3_2_minor_DPlus._proof_1_5`
- `AffineDualJT.lemma_3_2_minor_DPlus._proof_1_6`
- `AffineDualJT.lemma_3_2_minor_DPlus._simp_1_3`
- `AffineDualJT.prod_tail_rowSign._proof_1_1`
- `AffineDualJT.rowSign.eq_1`
- `_private.AffineDualJT.CoefficientMinors.0.AffineDualJT.hPlus_tail_entry._proof_1_1`
- `_private.AffineDualJT.CoefficientMinors.0.AffineDualJT.h_tail_entry._proof_1_1`
- `_private.AffineDualJT.CoefficientMinors.0.AffineDualJT.lambda_tail_entry._proof_1_1`

### `AffineDualJT.Coefficients` (78)

- `AffineDualJT.CoeffSystem`
- `AffineDualJT.classicalCoefficients`
- `AffineDualJT.classicalCoefficients_eDot_zero`
- `AffineDualJT.ddotE`
- `AffineDualJT.ddotE_degree_le`
- `AffineDualJT.ddotE_reflect`
- `AffineDualJT.dotE`
- `AffineDualJT.dotE_degree_le`
- `AffineDualJT.dotE_reflect`
- `AffineDualJT.intCoeff`
- `AffineDualJT.intCoeff_nat`
- `AffineDualJT.intCoeff_of_neg`
- `AffineDualJT.intCoeff_of_nonneg`
- `AffineDualJT.intCoeff_one_add_X_mul`
- `AffineDualJT.intCoeff_pal`
- `AffineDualJT.intCoeff_zero_of_gt`
- `AffineDualJT.reciprocalFactor`
- `AffineDualJT.reciprocalFactor_degree_le`
- `AffineDualJT.reciprocalFactor_eq`
- `AffineDualJT.reciprocalFactor_reflect`
- `_private.AffineDualJT.Coefficients.0.AffineDualJT.reciprocalProduct_properties`
- `AffineDualJT.CoeffSystem._sizeOf_1`
- `AffineDualJT.CoeffSystem._sizeOf_inst`
- `AffineDualJT.CoeffSystem.casesOn`
- `AffineDualJT.CoeffSystem.ctorIdx`
- `AffineDualJT.CoeffSystem.eDdot`
- `AffineDualJT.CoeffSystem.eDdot_eq`
- `AffineDualJT.CoeffSystem.eDdot_hasFiniteSupport`
- `AffineDualJT.CoeffSystem.eDdot_pal`
- `AffineDualJT.CoeffSystem.eDdot_zero_of_gt`
- `AffineDualJT.CoeffSystem.eDdot_zero_of_neg`
- `AffineDualJT.CoeffSystem.eDot`
- `AffineDualJT.CoeffSystem.eDot_hasFiniteSupport`
- `AffineDualJT.CoeffSystem.eDot_pal`
- `AffineDualJT.CoeffSystem.eDot_zero_of_gt`
- `AffineDualJT.CoeffSystem.eDot_zero_of_neg`
- `AffineDualJT.CoeffSystem.mk`
- `AffineDualJT.CoeffSystem.noConfusion`
- `AffineDualJT.CoeffSystem.noConfusionType`
- `AffineDualJT.CoeffSystem.rec`
- `AffineDualJT.CoeffSystem.recOn`
- `AffineDualJT.classicalCoefficients._proof_1`
- `AffineDualJT.classicalCoefficients._proof_2`
- `AffineDualJT.classicalCoefficients._proof_3`
- `AffineDualJT.classicalCoefficients._proof_4`
- `AffineDualJT.classicalCoefficients._proof_5`
- `AffineDualJT.classicalCoefficients._proof_6`
- `AffineDualJT.classicalCoefficients._proof_7`
- `AffineDualJT.classicalCoefficients._proof_8`
- `AffineDualJT.classicalCoefficients_eDot_zero._proof_1_1`
- `AffineDualJT.ddotE_degree_le._proof_1_1`
- `AffineDualJT.ddotE_reflect._proof_1_1`
- `AffineDualJT.dotE.eq_1`
- `AffineDualJT.intCoeff.eq_1`
- `AffineDualJT.intCoeff_one_add_X_mul._proof_1_1`
- `AffineDualJT.intCoeff_one_add_X_mul._proof_1_2`
- `AffineDualJT.intCoeff_one_add_X_mul._proof_1_4`
- `AffineDualJT.intCoeff_one_add_X_mul._proof_1_5`
- `AffineDualJT.intCoeff_pal._proof_1_1`
- `AffineDualJT.intCoeff_pal._proof_1_2`
- `AffineDualJT.intCoeff_pal._proof_1_3`
- `AffineDualJT.intCoeff_pal._proof_1_4`
- `AffineDualJT.intCoeff_pal._proof_1_5`
- `AffineDualJT.intCoeff_pal._proof_1_6`
- `AffineDualJT.intCoeff_zero_of_gt._proof_1_1`
- `AffineDualJT.intCoeff_zero_of_gt._proof_1_2`
- `AffineDualJT.intCoeff_zero_of_gt._proof_1_3`
- `AffineDualJT.reciprocalFactor.eq_1`
- `_private.AffineDualJT.Coefficients.0.AffineDualJT.reciprocalProduct_properties._proof_1_1`
- `AffineDualJT.CoeffSystem.eDdot_hasFiniteSupport._proof_1_1`
- `AffineDualJT.CoeffSystem.eDdot_hasFiniteSupport._proof_1_2`
- `AffineDualJT.CoeffSystem.eDot_hasFiniteSupport._proof_1_1`
- `AffineDualJT.CoeffSystem.eDot_hasFiniteSupport._proof_1_2`
- `AffineDualJT.CoeffSystem.mk._flat_ctor`
- `AffineDualJT.CoeffSystem.mk.inj`
- `AffineDualJT.CoeffSystem.mk.injEq`
- `AffineDualJT.CoeffSystem.mk.noConfusion`
- `AffineDualJT.CoeffSystem.mk.sizeOf_spec`

### `AffineDualJT.ComplementaryMinors` (19)

- `AffineDualJT.normalized_transfer_3_1`
- `AffineDualJT.theorem_3_1`
- `AffineDualJT.theorem_3_1_cleared`
- `AffineDualJT.normalized_transfer_3_1._simp_1_1`
- `AffineDualJT.normalized_transfer_3_1._simp_1_2`
- `AffineDualJT.normalized_transfer_3_1._simp_1_3`
- `AffineDualJT.normalized_transfer_3_1._simp_1_4`
- `AffineDualJT.normalized_transfer_3_1._simp_1_5`
- `AffineDualJT.normalized_transfer_3_1._simp_1_6`
- `AffineDualJT.normalized_transfer_3_1._simp_1_7`
- `AffineDualJT.paperFinsetSplit.congr_simp`
- `AffineDualJT.theorem_3_1._proof_1_1`
- `AffineDualJT.theorem_3_1_cleared._simp_1_1`
- `AffineDualJT.theorem_3_1_cleared._simp_1_2`
- `AffineDualJT.theorem_3_1_cleared._simp_1_3`
- `AffineDualJT.theorem_3_1_cleared._simp_1_4`
- `AffineDualJT.theorem_3_1_cleared._simp_1_5`
- `AffineDualJT.theorem_3_1_cleared._simp_1_6`
- `AffineDualJT.theorem_3_1_cleared._simp_1_7`

### `AffineDualJT.DeterminantFinsum` (6)

- `AffineDualJT.det_finsum_rows`
- `AffineDualJT.det_rows_hasFiniteSupport`
- `_private.AffineDualJT.DeterminantFinsum.0.AffineDualJT.entry_zero_outside_rowSupport`
- `_private.AffineDualJT.DeterminantFinsum.0.AffineDualJT.rowSupportFinset`
- `AffineDualJT.AffineDetSum.det_finsum_eq_JK`
- `AffineDualJT.AffineDetSum.jkMatrix_det_hasFiniteSupport`

### `AffineDualJT.ExceptionalBplusIdentity` (9)

- `AffineDualJT.Bplus_weight_zero`
- `AffineDualJT.DPlus_CPlus_Bplus_pairing`
- `AffineDualJT.exceptional_Bplus_identity`
- `AffineDualJT.exceptional_Bplus_nonzero`
- `AffineDualJT.Bplus_weight_zero._proof_1_1`
- `AffineDualJT.DPlus_CPlus_Bplus_pairing._proof_1_1`
- `AffineDualJT.exceptional_Bplus_identity._proof_1_1`
- `AffineDualJT.exceptional_Bplus_identity._proof_1_2`
- `AffineDualJT.exceptional_Bplus_nonzero._proof_1_1`

### `AffineDualJT.ExceptionalBplusKernels` (18)

- `AffineDualJT.CPlus_Bplus_center`
- `AffineDualJT.CPlus_Bplus_head`
- `AffineDualJT.CPlus_Bplus_positive`
- `AffineDualJT.VBplus_transpose_CPlus`
- `AffineDualJT.bBplus_small`
- `AffineDualJT.bracketPlus_CPlus_Bplus`
- `AffineDualJT.CPlus_Bplus_head._proof_1_1`
- `AffineDualJT.CPlus_Bplus_head._proof_1_2`
- `AffineDualJT.CPlus_Bplus_head._proof_1_3`
- `AffineDualJT.CPlus_Bplus_head._proof_1_4`
- `AffineDualJT.CPlus_Bplus_head._proof_1_5`
- `AffineDualJT.VBplus_transpose_CPlus._proof_1_1`
- `AffineDualJT.VBplus_transpose_CPlus._proof_1_2`
- `AffineDualJT.VBplus_transpose_CPlus._proof_1_3`
- `AffineDualJT.VBplus_transpose_CPlus._proof_1_4`
- `AffineDualJT.VBplus_transpose_CPlus._proof_1_5`
- `AffineDualJT.VBplus_transpose_CPlus._proof_1_6`
- `AffineDualJT.bBplus_small._proof_1_1`

### `AffineDualJT.ExceptionalBtIdentity` (12)

- `AffineDualJT.Bt_weight_zero`
- `AffineDualJT.DB_CB_Bt_pairing`
- `AffineDualJT.exceptional_Bt_identity`
- `AffineDualJT.exceptional_Bt_nonzero`
- `AffineDualJT.finsum_adjacent_pairing`
- `AffineDualJT.DB_CB_Bt_pairing._proof_1_2`
- `AffineDualJT.DB_CB_Bt_pairing._simp_1_1`
- `AffineDualJT.RedBt.eq_1`
- `AffineDualJT.exceptional_Bt_identity._proof_1_1`
- `AffineDualJT.exceptional_Bt_identity._proof_1_2`
- `AffineDualJT.exceptional_Bt_nonzero._proof_1_1`
- `AffineDualJT.finsum_adjacent_pairing._proof_1_1`

### `AffineDualJT.ExceptionalBtKernels` (32)

- `AffineDualJT.CB_Bt_apply`
- `AffineDualJT.CB_Bt_head`
- `AffineDualJT.CB_Bt_head_entry`
- `AffineDualJT.VBt_transpose_CB`
- `AffineDualJT.cBt_first`
- `AffineDualJT.CB_Bt_head._proof_1_1`
- `AffineDualJT.CB_Bt_head._proof_1_2`
- `AffineDualJT.CB_Bt_head._proof_1_3`
- `AffineDualJT.CB_Bt_head._proof_1_4`
- `AffineDualJT.CB_Bt_head_entry._proof_1_1`
- `AffineDualJT.CB_Bt_head_entry._proof_1_10`
- `AffineDualJT.CB_Bt_head_entry._proof_1_2`
- `AffineDualJT.CB_Bt_head_entry._proof_1_3`
- `AffineDualJT.CB_Bt_head_entry._proof_1_4`
- `AffineDualJT.CB_Bt_head_entry._proof_1_5`
- `AffineDualJT.CB_Bt_head_entry._proof_1_6`
- `AffineDualJT.CB_Bt_head_entry._proof_1_7`
- `AffineDualJT.CB_Bt_head_entry._proof_1_8`
- `AffineDualJT.CB_Bt_head_entry._proof_1_9`
- `AffineDualJT.VBt_transpose_CB._proof_1_10`
- `AffineDualJT.VBt_transpose_CB._proof_1_11`
- `AffineDualJT.VBt_transpose_CB._proof_1_12`
- `AffineDualJT.VBt_transpose_CB._proof_1_13`
- `AffineDualJT.VBt_transpose_CB._proof_1_2`
- `AffineDualJT.VBt_transpose_CB._proof_1_3`
- `AffineDualJT.VBt_transpose_CB._proof_1_4`
- `AffineDualJT.VBt_transpose_CB._proof_1_5`
- `AffineDualJT.VBt_transpose_CB._proof_1_6`
- `AffineDualJT.VBt_transpose_CB._proof_1_7`
- `AffineDualJT.VBt_transpose_CB._proof_1_8`
- `AffineDualJT.VBt_transpose_CB._proof_1_9`
- `AffineDualJT.VBt_transpose_CB._simp_1_1`

### `AffineDualJT.ExceptionalCtIdentity` (23)

- `AffineDualJT.Ct_even_sum_zero_parity`
- `AffineDualJT.Ct_last_column_sum_zero`
- `AffineDualJT.Ct_unsigned_JK_zero`
- `AffineDualJT.Ct_weight_exception_one`
- `AffineDualJT.Ct_weight_zero_except`
- `AffineDualJT.DC_CC_Ct_pairing`
- `AffineDualJT.exceptional_Ct_identity`
- `AffineDualJT.exceptional_Ct_signed_identity`
- `AffineDualJT.Ct_even_sum_zero_parity._proof_1_1`
- `AffineDualJT.Ct_last_column_sum_zero._proof_1_1`
- `AffineDualJT.Ct_unsigned_JK_zero._proof_1_1`
- `AffineDualJT.Ct_unsigned_JK_zero._proof_1_2`
- `AffineDualJT.Ct_unsigned_JK_zero._proof_1_3`
- `AffineDualJT.DC_CC_Ct_pairing._proof_1_1`
- `AffineDualJT.exceptional_Ct_identity._proof_1_1`
- `AffineDualJT.exceptional_Ct_signed_identity._proof_1_8`
- `AffineDualJT.exceptional_Ct_signed_identity._simp_1_1`
- `AffineDualJT.exceptional_Ct_signed_identity._simp_1_2`
- `AffineDualJT.exceptional_Ct_signed_identity._simp_1_3`
- `AffineDualJT.exceptional_Ct_signed_identity._simp_1_4`
- `AffineDualJT.exceptional_Ct_signed_identity._simp_1_5`
- `AffineDualJT.exceptional_Ct_signed_identity._simp_1_6`
- `AffineDualJT.exceptional_Ct_signed_identity._simp_1_7`

### `AffineDualJT.ExceptionalCtKernels` (34)

- `AffineDualJT.CC_Ct_head`
- `AffineDualJT.VCt_transpose_CC`
- `AffineDualJT.VCt_transpose_CC_all`
- `AffineDualJT.bCt_small`
- `AffineDualJT.bCt_zero_outside`
- `AffineDualJT.cCt_head_entry`
- `AffineDualJT.cCt_neg`
- `AffineDualJT.cCt_zero`
- `AffineDualJT.CC_Ct_head._proof_1_1`
- `AffineDualJT.CC_Ct_head._proof_1_2`
- `AffineDualJT.VCt_transpose_CC._proof_1_2`
- `AffineDualJT.VCt_transpose_CC._proof_1_3`
- `AffineDualJT.VCt_transpose_CC._proof_1_4`
- `AffineDualJT.VCt_transpose_CC._proof_1_5`
- `AffineDualJT.VCt_transpose_CC._simp_1_1`
- `AffineDualJT.VCt_transpose_CC_all._proof_1_1`
- `AffineDualJT.VCt_transpose_CC_all._proof_1_2`
- `AffineDualJT.VCt_transpose_CC_all._proof_1_3`
- `AffineDualJT.bCt_small._proof_1_1`
- `AffineDualJT.bCt_zero_outside._proof_1_1`
- `AffineDualJT.bCt_zero_outside._proof_1_2`
- `AffineDualJT.bCt_zero_outside._proof_1_3`
- `AffineDualJT.bCt_zero_outside._proof_1_4`
- `AffineDualJT.cCt_head_entry._proof_1_1`
- `AffineDualJT.cCt_head_entry._proof_1_10`
- `AffineDualJT.cCt_head_entry._proof_1_11`
- `AffineDualJT.cCt_head_entry._proof_1_2`
- `AffineDualJT.cCt_head_entry._proof_1_3`
- `AffineDualJT.cCt_head_entry._proof_1_4`
- `AffineDualJT.cCt_head_entry._proof_1_5`
- `AffineDualJT.cCt_head_entry._proof_1_6`
- `AffineDualJT.cCt_head_entry._proof_1_7`
- `AffineDualJT.cCt_head_entry._proof_1_8`
- `AffineDualJT.cCt_head_entry._proof_1_9`

### `AffineDualJT.ExceptionalSequences` (22)

- `AffineDualJT.Gamma`
- `AffineDualJT.aBt`
- `AffineDualJT.bBplus`
- `AffineDualJT.bCt`
- `AffineDualJT.bCt_quasiperiod`
- `AffineDualJT.cBt`
- `AffineDualJT.cCt`
- `AffineDualJT.cCt_reflection`
- `AffineDualJT.gammaBt`
- `AffineDualJT.lemma_5_2_affine`
- `AffineDualJT.lemma_5_2_center`
- `AffineDualJT.lemma_5_2_fixed`
- `AffineDualJT.lemma_5_2_quasiperiod`
- `AffineDualJT.lemma_5_4_eq_5_3`
- `AffineDualJT.lemma_5_4_eq_5_4`
- `AffineDualJT.lemma_5_4_eq_5_5`
- `AffineDualJT.lemma_5_4_fixed`
- `AffineDualJT.Gamma.eq_1`
- `AffineDualJT.aBt.eq_1`
- `AffineDualJT.cBt.eq_1`
- `AffineDualJT.cCt.eq_1`
- `AffineDualJT.gammaBt.eq_1`

### `AffineDualJT.ExternalHallLittlewood` (7)

- `AffineDualJT.ExternalHL.B0`
- `AffineDualJT.ExternalHL.BC`
- `AffineDualJT.ExternalHL.Bminus`
- `AffineDualJT.ExternalHL.Bplus`
- `AffineDualJT.ExternalHL.Bt`
- `AffineDualJT.ExternalHL.C0`
- `AffineDualJT.ExternalHL.Ct`

### `AffineDualJT.FieldEmbedding` (11)

- `AffineDualJT.mapWeylVariables`
- `AffineDualJT.map_DeltaB`
- `AffineDualJT.map_DeltaC`
- `AffineDualJT.map_JK`
- `AffineDualJT.map_classical_eDot`
- `AffineDualJT.map_dotE`
- `AffineDualJT.map_hKernel`
- `AffineDualJT.map_intCoeff`
- `AffineDualJT.map_lambdaKernel`
- `AffineDualJT.map_reducedWeyl`
- `AffineDualJT.mapWeylVariables.eq_1`

### `AffineDualJT.FiniteBplus` (6)

- `AffineDualJT.finite_bplus_ratio`
- `AffineDualJT.finite_bplus_ratio_all_width`
- `AffineDualJT.reducedBplus_det_sum`
- `AffineDualJT.RedBplus.eq_1`
- `AffineDualJT.basicWeightedMatrix.eq_1`
- `AffineDualJT.reducedWeyl.eq_1`

### `AffineDualJT.FiniteCB` (14)

- `AffineDualJT.finite_b0_ratio`
- `AffineDualJT.finite_b0_ratio_all_width`
- `AffineDualJT.finite_bc_ratio`
- `AffineDualJT.finite_bc_ratio_all_width`
- `AffineDualJT.finite_bminus_ratio`
- `AffineDualJT.finite_bminus_ratio_all_width`
- `AffineDualJT.finite_bt_ratio`
- `AffineDualJT.finite_bt_ratio_all_width`
- `AffineDualJT.finite_c0_ratio`
- `AffineDualJT.finite_c0_ratio_all_width`
- `AffineDualJT.finite_ct_ratio`
- `AffineDualJT.finite_ct_ratio_all_width`
- `AffineDualJT.RedB0.eq_1`
- `AffineDualJT.RedC0.eq_1`

### `AffineDualJT.FiniteColumnData` (25)

- `AffineDualJT.RedB0`
- `AffineDualJT.RedBC`
- `AffineDualJT.RedBminus`
- `AffineDualJT.RedBplus`
- `AffineDualJT.RedBt`
- `AffineDualJT.RedC0`
- `AffineDualJT.RedCt`
- `AffineDualJT.VB0`
- `AffineDualJT.VBC`
- `AffineDualJT.VBminus`
- `AffineDualJT.VBplus`
- `AffineDualJT.VBt`
- `AffineDualJT.VC0`
- `AffineDualJT.VCt`
- `AffineDualJT.bracketB`
- `AffineDualJT.bracketC`
- `AffineDualJT.bracketPlus`
- `AffineDualJT.reducedWeyl`
- `AffineDualJT.uB`
- `AffineDualJT.uBTilde`
- `AffineDualJT.uC`
- `AffineDualJT.uCTilde`
- `AffineDualJT.uPlus`
- `_private.AffineDualJT.FiniteColumnData.0.AffineDualJT.kZ`
- `AffineDualJT.bracketPlus._proof_1`

### `AffineDualJT.FiniteColumnEvaluation` (69)

- `AffineDualJT.PhiB_VBminus_apply`
- `AffineDualJT.PhiB_VBminus_apply_all_width`
- `AffineDualJT.PhiB_uBTilde_apply`
- `AffineDualJT.PhiB_uBTilde_apply_all_width`
- `AffineDualJT.PhiB_uB_apply`
- `AffineDualJT.PhiB_uB_apply_all_width`
- `AffineDualJT.PhiC_VCt_apply`
- `AffineDualJT.PhiC_VCt_apply_all_width`
- `AffineDualJT.PhiC_uCTilde_apply`
- `AffineDualJT.PhiC_uCTilde_apply_all_width`
- `AffineDualJT.PhiC_uC_apply`
- `AffineDualJT.PhiC_uC_apply_all_width`
- `AffineDualJT.PhiPlus_VBplus_apply`
- `AffineDualJT.PhiPlus_VBplus_apply_all_width`
- `AffineDualJT.finite_column_pairing`
- `AffineDualJT.weighted_fColumn`
- `AffineDualJT.weighted_fColumn_plus_fold`
- `AffineDualJT.weighted_fColumn_plus_fold_all_width`
- `AffineDualJT.PhiB_VBminus_apply_all_width._proof_1_2`
- `AffineDualJT.PhiB_VBminus_apply_all_width._proof_1_3`
- `AffineDualJT.PhiB_VBminus_apply_all_width._proof_1_4`
- `AffineDualJT.PhiB_VBminus_apply_all_width._proof_1_5`
- `AffineDualJT.PhiB_uBTilde_apply_all_width._proof_1_2`
- `AffineDualJT.PhiB_uBTilde_apply_all_width._proof_1_3`
- `AffineDualJT.PhiB_uBTilde_apply_all_width._proof_1_4`
- `AffineDualJT.PhiB_uBTilde_apply_all_width._proof_1_5`
- `AffineDualJT.PhiB_uBTilde_apply_all_width._proof_1_6`
- `AffineDualJT.PhiB_uBTilde_apply_all_width._proof_1_7`
- `AffineDualJT.PhiB_uB_apply_all_width._proof_1_2`
- `AffineDualJT.PhiB_uB_apply_all_width._proof_1_3`
- `AffineDualJT.PhiB_uB_apply_all_width._proof_1_4`
- `AffineDualJT.PhiB_uB_apply_all_width._proof_1_5`
- `AffineDualJT.PhiB_uB_apply_all_width._proof_1_6`
- `AffineDualJT.PhiB_uB_apply_all_width._proof_1_7`
- `AffineDualJT.PhiC_VCt_apply_all_width._proof_1_3`
- `AffineDualJT.PhiC_VCt_apply_all_width._proof_1_4`
- `AffineDualJT.PhiC_VCt_apply_all_width._proof_1_5`
- `AffineDualJT.PhiC_VCt_apply_all_width._proof_1_6`
- `AffineDualJT.PhiC_VCt_apply_all_width._simp_1_2`
- `AffineDualJT.PhiC_uCTilde_apply_all_width._proof_1_2`
- `AffineDualJT.PhiC_uCTilde_apply_all_width._proof_1_3`
- `AffineDualJT.PhiC_uCTilde_apply_all_width._proof_1_4`
- `AffineDualJT.PhiC_uCTilde_apply_all_width._proof_1_5`
- `AffineDualJT.PhiC_uCTilde_apply_all_width._proof_1_6`
- `AffineDualJT.PhiC_uCTilde_apply_all_width._proof_1_7`
- `AffineDualJT.PhiC_uC_apply_all_width._proof_1_2`
- `AffineDualJT.PhiC_uC_apply_all_width._proof_1_3`
- `AffineDualJT.PhiC_uC_apply_all_width._proof_1_4`
- `AffineDualJT.PhiC_uC_apply_all_width._proof_1_5`
- `AffineDualJT.PhiC_uC_apply_all_width._proof_1_6`
- `AffineDualJT.PhiC_uC_apply_all_width._proof_1_7`
- `AffineDualJT.PhiPlus_VBplus_apply_all_width._proof_1_3`
- `AffineDualJT.PhiPlus_VBplus_apply_all_width._proof_1_4`
- `AffineDualJT.PhiPlus_VBplus_apply_all_width._proof_1_5`
- `AffineDualJT.PhiPlus_VBplus_apply_all_width._proof_1_6`
- `AffineDualJT.PhiPlus_VBplus_apply_all_width._proof_1_7`
- `AffineDualJT.PhiPlus_VBplus_apply_all_width._proof_1_8`
- `AffineDualJT.VBminus.eq_1`
- `AffineDualJT.VBplus.eq_1`
- `AffineDualJT.VCt.eq_1`
- `AffineDualJT.uB.eq_1`
- `AffineDualJT.uBTilde.eq_1`
- `AffineDualJT.uC.eq_1`
- `AffineDualJT.uCTilde.eq_1`
- `AffineDualJT.uPlus.eq_1`
- `AffineDualJT.weighted_fColumn._proof_1_1`
- `AffineDualJT.weighted_fColumn._proof_1_2`
- `AffineDualJT.weighted_fColumn._proof_1_3`
- `AffineDualJT.weighted_fColumn_plus_fold_all_width._simp_1_1`

### `AffineDualJT.FiniteColumnMinors` (170)

- `AffineDualJT.prop_2_2_minor_VB0`
- `AffineDualJT.prop_2_2_minor_VBC`
- `AffineDualJT.prop_2_2_minor_VBminus`
- `AffineDualJT.prop_2_2_minor_VBplus`
- `AffineDualJT.prop_2_2_minor_VBt`
- `AffineDualJT.prop_2_2_minor_VC0`
- `AffineDualJT.prop_2_2_minor_VCt`
- `_private.AffineDualJT.FiniteColumnMinors.0.AffineDualJT.det_unit_upper`
- `AffineDualJT.prop_2_2_minor_VB0._proof_1_1`
- `AffineDualJT.prop_2_2_minor_VB0._proof_1_10`
- `AffineDualJT.prop_2_2_minor_VB0._proof_1_11`
- `AffineDualJT.prop_2_2_minor_VB0._proof_1_12`
- `AffineDualJT.prop_2_2_minor_VB0._proof_1_13`
- `AffineDualJT.prop_2_2_minor_VB0._proof_1_14`
- `AffineDualJT.prop_2_2_minor_VB0._proof_1_15`
- `AffineDualJT.prop_2_2_minor_VB0._proof_1_2`
- `AffineDualJT.prop_2_2_minor_VB0._proof_1_3`
- `AffineDualJT.prop_2_2_minor_VB0._proof_1_4`
- `AffineDualJT.prop_2_2_minor_VB0._proof_1_5`
- `AffineDualJT.prop_2_2_minor_VB0._proof_1_6`
- `AffineDualJT.prop_2_2_minor_VB0._proof_1_7`
- `AffineDualJT.prop_2_2_minor_VB0._proof_1_8`
- `AffineDualJT.prop_2_2_minor_VB0._proof_1_9`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_1`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_10`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_11`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_12`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_13`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_14`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_15`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_16`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_17`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_18`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_19`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_2`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_20`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_21`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_22`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_23`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_24`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_25`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_26`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_27`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_28`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_29`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_3`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_30`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_31`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_32`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_33`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_34`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_35`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_36`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_37`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_38`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_39`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_4`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_40`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_41`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_42`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_43`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_44`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_5`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_6`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_7`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_8`
- `AffineDualJT.prop_2_2_minor_VBC._proof_1_9`
- `AffineDualJT.prop_2_2_minor_VBminus._proof_1_1`
- `AffineDualJT.prop_2_2_minor_VBminus._proof_1_10`
- `AffineDualJT.prop_2_2_minor_VBminus._proof_1_2`
- `AffineDualJT.prop_2_2_minor_VBminus._proof_1_3`
- `AffineDualJT.prop_2_2_minor_VBminus._proof_1_4`
- `AffineDualJT.prop_2_2_minor_VBminus._proof_1_5`
- `AffineDualJT.prop_2_2_minor_VBminus._proof_1_6`
- `AffineDualJT.prop_2_2_minor_VBminus._proof_1_7`
- `AffineDualJT.prop_2_2_minor_VBminus._proof_1_8`
- `AffineDualJT.prop_2_2_minor_VBminus._proof_1_9`
- `AffineDualJT.prop_2_2_minor_VBplus._proof_1_1`
- `AffineDualJT.prop_2_2_minor_VBplus._proof_1_10`
- `AffineDualJT.prop_2_2_minor_VBplus._proof_1_11`
- `AffineDualJT.prop_2_2_minor_VBplus._proof_1_12`
- `AffineDualJT.prop_2_2_minor_VBplus._proof_1_13`
- `AffineDualJT.prop_2_2_minor_VBplus._proof_1_14`
- `AffineDualJT.prop_2_2_minor_VBplus._proof_1_15`
- `AffineDualJT.prop_2_2_minor_VBplus._proof_1_16`
- `AffineDualJT.prop_2_2_minor_VBplus._proof_1_17`
- `AffineDualJT.prop_2_2_minor_VBplus._proof_1_18`
- `AffineDualJT.prop_2_2_minor_VBplus._proof_1_19`
- `AffineDualJT.prop_2_2_minor_VBplus._proof_1_2`
- `AffineDualJT.prop_2_2_minor_VBplus._proof_1_20`
- `AffineDualJT.prop_2_2_minor_VBplus._proof_1_21`
- `AffineDualJT.prop_2_2_minor_VBplus._proof_1_22`
- `AffineDualJT.prop_2_2_minor_VBplus._proof_1_23`
- `AffineDualJT.prop_2_2_minor_VBplus._proof_1_3`
- `AffineDualJT.prop_2_2_minor_VBplus._proof_1_4`
- `AffineDualJT.prop_2_2_minor_VBplus._proof_1_5`
- `AffineDualJT.prop_2_2_minor_VBplus._proof_1_6`
- `AffineDualJT.prop_2_2_minor_VBplus._proof_1_7`
- `AffineDualJT.prop_2_2_minor_VBplus._proof_1_8`
- `AffineDualJT.prop_2_2_minor_VBplus._proof_1_9`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_1`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_10`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_11`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_12`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_13`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_14`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_15`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_16`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_17`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_18`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_19`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_2`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_20`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_21`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_22`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_23`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_24`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_25`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_26`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_27`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_28`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_29`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_3`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_30`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_31`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_32`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_33`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_34`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_35`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_36`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_37`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_38`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_39`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_4`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_40`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_41`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_42`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_43`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_44`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_5`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_6`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_7`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_8`
- `AffineDualJT.prop_2_2_minor_VBt._proof_1_9`
- `AffineDualJT.prop_2_2_minor_VC0._proof_1`
- `AffineDualJT.prop_2_2_minor_VC0._proof_1_1`
- `AffineDualJT.prop_2_2_minor_VC0._proof_1_10`
- `AffineDualJT.prop_2_2_minor_VC0._proof_1_11`
- `AffineDualJT.prop_2_2_minor_VC0._proof_1_12`
- `AffineDualJT.prop_2_2_minor_VC0._proof_1_13`
- `AffineDualJT.prop_2_2_minor_VC0._proof_1_14`
- `AffineDualJT.prop_2_2_minor_VC0._proof_1_15`
- `AffineDualJT.prop_2_2_minor_VC0._proof_1_2`
- `AffineDualJT.prop_2_2_minor_VC0._proof_1_3`
- `AffineDualJT.prop_2_2_minor_VC0._proof_1_4`
- `AffineDualJT.prop_2_2_minor_VC0._proof_1_5`
- `AffineDualJT.prop_2_2_minor_VC0._proof_1_6`
- `AffineDualJT.prop_2_2_minor_VC0._proof_1_7`
- `AffineDualJT.prop_2_2_minor_VC0._proof_1_8`
- `AffineDualJT.prop_2_2_minor_VC0._proof_1_9`
- `AffineDualJT.prop_2_2_minor_VCt._proof_1_1`
- `AffineDualJT.prop_2_2_minor_VCt._proof_1_10`
- `AffineDualJT.prop_2_2_minor_VCt._proof_1_2`
- `AffineDualJT.prop_2_2_minor_VCt._proof_1_3`
- `AffineDualJT.prop_2_2_minor_VCt._proof_1_4`
- `AffineDualJT.prop_2_2_minor_VCt._proof_1_5`
- `AffineDualJT.prop_2_2_minor_VCt._proof_1_6`
- `AffineDualJT.prop_2_2_minor_VCt._proof_1_7`
- `AffineDualJT.prop_2_2_minor_VCt._proof_1_8`
- `AffineDualJT.prop_2_2_minor_VCt._proof_1_9`

### `AffineDualJT.FiniteColumns` (7)

- `AffineDualJT.prop_2_2_B0`
- `AffineDualJT.prop_2_2_BC`
- `AffineDualJT.prop_2_2_Bminus`
- `AffineDualJT.prop_2_2_Bplus`
- `AffineDualJT.prop_2_2_Bt`
- `AffineDualJT.prop_2_2_C0`
- `AffineDualJT.prop_2_2_Ct`

### `AffineDualJT.FiniteDeterminantTransfer` (5)

- `AffineDualJT.finiteB_from_alternant`
- `AffineDualJT.finiteB_from_alternant_all_width`
- `AffineDualJT.finiteC_from_alternant`
- `AffineDualJT.finiteC_from_alternant_all_width`
- `AffineDualJT.weightedAlternant.eq_1`

### `AffineDualJT.FiniteFolding` (2)

- `AffineDualJT.det_weighted_bool_rows`
- `AffineDualJT.inversion_sum_ratio`

### `AffineDualJT.FiniteRowFunctions` (43)

- `AffineDualJT.finiteBCRow_column`
- `AffineDualJT.finiteBCRow_column_all_width`
- `AffineDualJT.finiteBasicRow`
- `AffineDualJT.finiteBasicRow_B_column`
- `AffineDualJT.finiteBasicRow_B_column_all_width`
- `AffineDualJT.finiteBasicRow_B_tilde_column`
- `AffineDualJT.finiteBasicRow_B_tilde_column_all_width`
- `AffineDualJT.finiteBasicRow_C_column`
- `AffineDualJT.finiteBasicRow_C_column_all_width`
- `AffineDualJT.finiteBasicRow_C_tilde_column`
- `AffineDualJT.finiteBasicRow_C_tilde_column_all_width`
- `AffineDualJT.finiteBasicRow_apply`
- `AffineDualJT.finiteBasicRow_foldB`
- `AffineDualJT.finiteBasicRow_foldC`
- `AffineDualJT.finiteBasicRow_mul_z`
- `AffineDualJT.finiteBminusRow`
- `AffineDualJT.finiteBminusRow_apply`
- `AffineDualJT.finiteBminusRow_column`
- `AffineDualJT.finiteBminusRow_column_all_width`
- `AffineDualJT.finiteBtRow_column`
- `AffineDualJT.finiteBtRow_column_all_width`
- `AffineDualJT.finiteCtRow`
- `AffineDualJT.finiteCtRow_apply`
- `AffineDualJT.finiteCtRow_column`
- `AffineDualJT.finiteCtRow_column_all_width`
- `AffineDualJT.z_mul_inv_zpow`
- `AffineDualJT.VB0.eq_1`
- `AffineDualJT.VBC.eq_1`
- `AffineDualJT.VBt.eq_1`
- `AffineDualJT.VC0.eq_1`
- `AffineDualJT.finiteBasicRow.eq_1`
- `AffineDualJT.finiteBasicRow_apply._proof_1_2`
- `AffineDualJT.finiteBasicRow_apply._proof_1_3`
- `AffineDualJT.finiteBasicRow_apply._proof_1_4`
- `AffineDualJT.finiteBasicRow_foldC._simp_1_1`
- `AffineDualJT.finiteBminusRow.eq_1`
- `AffineDualJT.finiteBminusRow_apply._proof_1_2`
- `AffineDualJT.finiteBminusRow_apply._proof_1_3`
- `AffineDualJT.finiteBtRow_column_all_width._simp_1_3`
- `AffineDualJT.finiteCtRow.eq_1`
- `AffineDualJT.finiteCtRow_apply._proof_1_2`
- `AffineDualJT.finiteCtRow_apply._proof_1_3`
- `AffineDualJT.finiteCtRow_column_all_width._simp_1_1`

### `AffineDualJT.FiniteUnfolding` (34)

- `AffineDualJT.unfold_center_one`
- `AffineDualJT.unfold_center_two`
- `AffineDualJT.unfold_odd`
- `_private.AffineDualJT.FiniteUnfolding.0.AffineDualJT.mem_positiveRows`
- `_private.AffineDualJT.FiniteUnfolding.0.AffineDualJT.pair_finsum`
- `_private.AffineDualJT.FiniteUnfolding.0.AffineDualJT.paperIndex_injective`
- `_private.AffineDualJT.FiniteUnfolding.0.AffineDualJT.positiveRows`
- `AffineDualJT.unfold_center_one._proof_1_1`
- `AffineDualJT.unfold_center_one._proof_1_2`
- `AffineDualJT.unfold_center_one._proof_1_3`
- `AffineDualJT.unfold_center_one._proof_1_4`
- `AffineDualJT.unfold_center_one._proof_1_5`
- `AffineDualJT.unfold_center_one._proof_1_6`
- `AffineDualJT.unfold_center_two._proof_1_1`
- `AffineDualJT.unfold_center_two._proof_1_10`
- `AffineDualJT.unfold_center_two._proof_1_11`
- `AffineDualJT.unfold_center_two._proof_1_2`
- `AffineDualJT.unfold_center_two._proof_1_6`
- `AffineDualJT.unfold_center_two._proof_1_7`
- `AffineDualJT.unfold_center_two._proof_1_8`
- `AffineDualJT.unfold_center_two._proof_1_9`
- `AffineDualJT.unfold_center_two._simp_1_3`
- `AffineDualJT.unfold_center_two._simp_1_4`
- `AffineDualJT.unfold_center_two._simp_1_5`
- `AffineDualJT.unfold_odd._proof_1_1`
- `AffineDualJT.unfold_odd._proof_1_2`
- `AffineDualJT.unfold_odd._proof_1_3`
- `AffineDualJT.unfold_odd._proof_1_4`
- `AffineDualJT.unfold_odd._proof_1_5`
- `_private.AffineDualJT.FiniteUnfolding.0.AffineDualJT.mem_positiveRows._proof_1_1`
- `_private.AffineDualJT.FiniteUnfolding.0.AffineDualJT.mem_positiveRows._proof_1_2`
- `_private.AffineDualJT.FiniteUnfolding.0.AffineDualJT.mem_positiveRows._proof_1_3`
- `_private.AffineDualJT.FiniteUnfolding.0.AffineDualJT.paperIndex_injective._proof_1_1`
- `_private.AffineDualJT.FiniteUnfolding.0.AffineDualJT.positiveRows.eq_1`

### `AffineDualJT.FiniteWeyl` (7)

- `AffineDualJT.lemma_2_1_eq_2_3`
- `AffineDualJT.lemma_2_1_eq_2_3_of`
- `AffineDualJT.lemma_2_1_eq_2_4`
- `AffineDualJT.lemma_2_1_eq_2_4_of`
- `AffineDualJT.lemma_2_1_eq_2_5`
- `AffineDualJT.lemma_2_1_eq_2_5_of`
- `AffineDualJT.paperBasicAlternantPolynomial.eq_1`

### `AffineDualJT.Folding` (17)

- `AffineDualJT.CB`
- `AffineDualJT.CC`
- `AffineDualJT.CPlus`
- `AffineDualJT.lemma_3_3_eq_3_5`
- `AffineDualJT.lemma_3_3_eq_3_6`
- `AffineDualJT.lemma_3_3_eq_3_7`
- `AffineDualJT.row_zero_above_support`
- `AffineDualJT.row_zero_below_support`
- `AffineDualJT.CB.eq_1`
- `AffineDualJT.CC.eq_1`
- `AffineDualJT.CPlus.eq_1`
- `AffineDualJT.lemma_3_3_eq_3_7._proof_1_1`
- `AffineDualJT.row_zero_above_support._proof_1_1`
- `AffineDualJT.row_zero_above_support._proof_1_2`
- `AffineDualJT.row_zero_above_support._proof_1_3`
- `AffineDualJT.row_zero_below_support._proof_1_1`
- `AffineDualJT.row_zero_below_support._proof_1_2`

### `AffineDualJT.GeneratingFunctions` (12)

- `AffineDualJT.dotE_eval_neg_variable`
- `AffineDualJT.hPlus_generating`
- `AffineDualJT.h_center_generating`
- `AffineDualJT.h_generating`
- `AffineDualJT.intCoeff_finsum_eval`
- `AffineDualJT.lambda_generating`
- `AffineDualJT.shifted_intCoeff_finsum_eval`
- `AffineDualJT.h_center_generating._proof_1_1`
- `AffineDualJT.h_center_generating._proof_1_2`
- `AffineDualJT.intCoeff_finsum_eval._proof_1_1`
- `AffineDualJT.lambda_generating._proof_1_1`
- `AffineDualJT.lambda_generating._proof_1_2`

### `AffineDualJT.HallLittlewoodAffine` (7)

- `AffineDualJT.prop_4_1_BC_HL`
- `AffineDualJT.prop_4_1_C0_HL`
- `AffineDualJT.prop_4_2_B0_HL`
- `AffineDualJT.prop_4_2_Bminus_HL`
- `AffineDualJT.prop_5_1_Ct_HL`
- `AffineDualJT.prop_5_3_Bplus_HL`
- `AffineDualJT.prop_5_5_Bt_HL`

### `AffineDualJT.HallLittlewoodClassical` (12)

- `AffineDualJT.cor_6_2_B0_zero_HL`
- `AffineDualJT.cor_6_2_BC_zero_HL`
- `AffineDualJT.cor_6_2_Bminus_zero_HL`
- `AffineDualJT.cor_6_2_Bplus_zero_HL`
- `AffineDualJT.cor_6_2_Bt_zero_HL`
- `AffineDualJT.cor_6_2_C0_zero_HL`
- `AffineDualJT.cor_6_2_Ct_zero_HL`
- `_private.AffineDualJT.HallLittlewoodClassical.0.AffineDualJT.classical_PhiB_mul`
- `_private.AffineDualJT.HallLittlewoodClassical.0.AffineDualJT.classical_PhiC_mul`
- `_private.AffineDualJT.HallLittlewoodClassical.0.AffineDualJT.classical_PhiPlus_mul`
- `_private.AffineDualJT.HallLittlewoodClassical.0.AffineDualJT.classical_PhiPlus_mul._proof_1_2`
- `_private.AffineDualJT.HallLittlewoodClassical.0.AffineDualJT.classical_PhiPlus_mul._proof_1_3`

### `AffineDualJT.HallLittlewoodFinite` (7)

- `AffineDualJT.prop_2_2_B0_HL`
- `AffineDualJT.prop_2_2_BC_HL`
- `AffineDualJT.prop_2_2_Bminus_HL`
- `AffineDualJT.prop_2_2_Bplus_HL`
- `AffineDualJT.prop_2_2_Bt_HL`
- `AffineDualJT.prop_2_2_C0_HL`
- `AffineDualJT.prop_2_2_Ct_HL`

### `AffineDualJT.HallLittlewoodWeyl` (19)

- `AffineDualJT.ExternalHL.Admissible`
- `AffineDualJT.ExternalHL.Vn`
- `AffineDualJT.ExternalHL.nuBminus`
- `AffineDualJT.ExternalHL.nuBplus`
- `AffineDualJT.ExternalHL.nuCt`
- `AffineDualJT.ExternalHL.pochhammer`
- `AffineDualJT.ExternalHL.signedVariables`
- `AffineDualJT.ExternalHL.weylSum`
- `AffineDualJT.ExternalHL.weylSummand`
- `AffineDualJT.ExternalHL.weylVariables`
- `AffineDualJT.ExternalHL.Admissible.boundary`
- `AffineDualJT.ExternalHL.Admissible.casesOn`
- `AffineDualJT.ExternalHL.Admissible.distinct`
- `AffineDualJT.ExternalHL.Admissible.mk`
- `AffineDualJT.ExternalHL.Admissible.normalization`
- `AffineDualJT.ExternalHL.Admissible.pair`
- `AffineDualJT.ExternalHL.Admissible.rec`
- `AffineDualJT.ExternalHL.Admissible.recOn`
- `AffineDualJT.ExternalHL.Admissible.mk._flat_ctor`

### `AffineDualJT.Kernels` (11)

- `AffineDualJT.lemma_3_2_PhiB_DB`
- `AffineDualJT.lemma_3_2_PhiC_DC`
- `AffineDualJT.lemma_3_2_PhiPlus_DPlus`
- `_private.AffineDualJT.Kernels.0.AffineDualJT.negOne_zpow_neg`
- `_private.AffineDualJT.Kernels.0.AffineDualJT.negOne_zpow_one_sub`
- `_private.AffineDualJT.Kernels.0.AffineDualJT.negOne_zpow_two_sub`
- `_private.AffineDualJT.Kernels.0.AffineDualJT.neg_zpow`
- `AffineDualJT.DB.eq_1`
- `AffineDualJT.DC.eq_1`
- `AffineDualJT.DPlus.eq_1`
- `AffineDualJT.lemma_3_2_PhiPlus_DPlus._proof_1_1`

### `AffineDualJT.MainIdentities` (24)

- `AffineDualJT.bridge_B0`
- `AffineDualJT.bridge_BC`
- `AffineDualJT.bridge_Bminus`
- `AffineDualJT.bridge_Bplus`
- `AffineDualJT.bridge_Bt`
- `AffineDualJT.bridge_C0`
- `AffineDualJT.bridge_Ct`
- `AffineDualJT.theorem_A_1_3`
- `AffineDualJT.theorem_A_1_4`
- `AffineDualJT.theorem_A_1_5`
- `AffineDualJT.theorem_A_1_6`
- `AffineDualJT.theorem_A_1_7`
- `AffineDualJT.theorem_A_1_8`
- `AffineDualJT.theorem_A_Bplus_width_zero`
- `AffineDualJT.theorem_B_1_9`
- `AffineDualJT.theorem_B_Bt_width_zero`
- `AffineDualJT.RedCt.eq_1`
- `AffineDualJT.ExternalHL.B0.eq_1`
- `AffineDualJT.ExternalHL.BC.eq_1`
- `AffineDualJT.ExternalHL.Bminus.eq_1`
- `AffineDualJT.ExternalHL.Bplus.eq_1`
- `AffineDualJT.ExternalHL.Bt.eq_1`
- `AffineDualJT.ExternalHL.C0.eq_1`
- `AffineDualJT.ExternalHL.Ct.eq_1`

### `AffineDualJT.MatrixBlocks` (12)

- `AffineDualJT.firstCols`
- `AffineDualJT.firstRowsZ`
- `AffineDualJT.lastRowsY`
- `AffineDualJT.tailRowsAfterN`
- `AffineDualJT.firstCols._proof_1`
- `AffineDualJT.firstCols._proof_2`
- `AffineDualJT.firstRowsZ._proof_1`
- `AffineDualJT.firstRowsZ._proof_2`
- `AffineDualJT.lastRowsY._proof_1`
- `AffineDualJT.lastRowsY._proof_2`
- `AffineDualJT.tailRowsAfterN._proof_1`
- `AffineDualJT.tailRowsAfterN._proof_2`

### `AffineDualJT.NormalizedAlternants` (2)

- `AffineDualJT.weightedAlternant`
- `AffineDualJT.weightedAlternant_ratio`

### `AffineDualJT.OrdinaryBCColumnKernels` (24)

- `AffineDualJT.CC_BC_head`
- `AffineDualJT.VBC_transpose_CC`
- `AffineDualJT.bBC_small`
- `AffineDualJT.cBC_zero`
- `AffineDualJT.CC_BC_head._proof_1_1`
- `AffineDualJT.CC_BC_head._proof_1_2`
- `AffineDualJT.CC_BC_head._proof_1_3`
- `AffineDualJT.CC_BC_head._proof_1_4`
- `AffineDualJT.CC_BC_head._proof_1_5`
- `AffineDualJT.VBC_transpose_CC._proof_1_10`
- `AffineDualJT.VBC_transpose_CC._proof_1_11`
- `AffineDualJT.VBC_transpose_CC._proof_1_12`
- `AffineDualJT.VBC_transpose_CC._proof_1_13`
- `AffineDualJT.VBC_transpose_CC._proof_1_2`
- `AffineDualJT.VBC_transpose_CC._proof_1_3`
- `AffineDualJT.VBC_transpose_CC._proof_1_4`
- `AffineDualJT.VBC_transpose_CC._proof_1_5`
- `AffineDualJT.VBC_transpose_CC._proof_1_6`
- `AffineDualJT.VBC_transpose_CC._proof_1_7`
- `AffineDualJT.VBC_transpose_CC._proof_1_8`
- `AffineDualJT.VBC_transpose_CC._proof_1_9`
- `AffineDualJT.VBC_transpose_CC._simp_1_1`
- `AffineDualJT.VBC_transpose_CC._simp_1_14`
- `AffineDualJT.bBC_small._proof_1_1`

### `AffineDualJT.OrdinaryBCIdentity` (18)

- `AffineDualJT.DC_CC_BC_pairing`
- `AffineDualJT.ordinary_BC_identity`
- `AffineDualJT.ordinary_BC_nonzero`
- `AffineDualJT.ordinary_BC_zero`
- `AffineDualJT.ordinary_BC_zero_of_infinite`
- `AffineDualJT.DC_CC_BC_pairing._proof_1_1`
- `AffineDualJT.RedBC.eq_1`
- `AffineDualJT.ordinary_BC_nonzero._proof_1_8`
- `AffineDualJT.ordinary_BC_nonzero._simp_1_1`
- `AffineDualJT.ordinary_BC_nonzero._simp_1_2`
- `AffineDualJT.ordinary_BC_nonzero._simp_1_3`
- `AffineDualJT.ordinary_BC_nonzero._simp_1_4`
- `AffineDualJT.ordinary_BC_nonzero._simp_1_5`
- `AffineDualJT.ordinary_BC_nonzero._simp_1_6`
- `AffineDualJT.ordinary_BC_nonzero._simp_1_7`
- `AffineDualJT.ordinary_BC_zero._proof_1_2`
- `AffineDualJT.ordinary_BC_zero_of_infinite._proof_1_1`
- `AffineDualJT.ordinary_BC_zero_of_infinite._proof_1_2`

### `AffineDualJT.OrdinaryBColumnKernels` (32)

- `AffineDualJT.CB_B0_apply`
- `AffineDualJT.CB_B0_head`
- `AffineDualJT.CB_Bminus_apply`
- `AffineDualJT.CB_Bminus_head`
- `AffineDualJT.CB_head_of_small`
- `AffineDualJT.VB0_transpose_CB`
- `AffineDualJT.VBminus_transpose_CB`
- `AffineDualJT.bB0_small`
- `AffineDualJT.bBminus_small`
- `AffineDualJT.gammaB0_fixed`
- `AffineDualJT.CB_B0_head._proof_1_1`
- `AffineDualJT.CB_B0_head._proof_1_2`
- `AffineDualJT.CB_B0_head._proof_1_3`
- `AffineDualJT.CB_B0_head._proof_1_4`
- `AffineDualJT.CB_B0_head._proof_1_5`
- `AffineDualJT.CB_Bminus_head._proof_1_1`
- `AffineDualJT.CB_Bminus_head._proof_1_2`
- `AffineDualJT.CB_Bminus_head._proof_1_3`
- `AffineDualJT.CB_Bminus_head._proof_1_4`
- `AffineDualJT.CB_Bminus_head._proof_1_5`
- `AffineDualJT.VB0_transpose_CB._proof_1_1`
- `AffineDualJT.VB0_transpose_CB._proof_1_2`
- `AffineDualJT.VB0_transpose_CB._proof_1_3`
- `AffineDualJT.VB0_transpose_CB._proof_1_4`
- `AffineDualJT.VB0_transpose_CB._proof_1_5`
- `AffineDualJT.VB0_transpose_CB._proof_1_6`
- `AffineDualJT.VBminus_transpose_CB._proof_1_1`
- `AffineDualJT.VBminus_transpose_CB._proof_1_2`
- `AffineDualJT.VBminus_transpose_CB._proof_1_3`
- `AffineDualJT.VBminus_transpose_CB._proof_1_4`
- `AffineDualJT.bB0_small._proof_1_1`
- `AffineDualJT.bBminus_small._proof_1_1`

### `AffineDualJT.OrdinaryBIdentities` (20)

- `AffineDualJT.B0_weight_zero`
- `AffineDualJT.DB_CB_B0_pairing`
- `AffineDualJT.DB_CB_Bminus_pairing`
- `AffineDualJT.ordinary_B0_identity`
- `AffineDualJT.ordinary_B0_nonzero`
- `AffineDualJT.ordinary_Bminus_identity`
- `AffineDualJT.ordinary_Bminus_nonzero`
- `AffineDualJT.ordinary_Bminus_zero`
- `AffineDualJT.ordinary_Bminus_zero_of_infinite`
- `AffineDualJT.B0_weight_zero._proof_1_1`
- `AffineDualJT.DB_CB_B0_pairing._proof_1_1`
- `AffineDualJT.DB_CB_Bminus_pairing._proof_1_1`
- `AffineDualJT.RedBminus.eq_1`
- `AffineDualJT.ordinary_B0_identity._proof_1_1`
- `AffineDualJT.ordinary_B0_identity._proof_1_2`
- `AffineDualJT.ordinary_B0_nonzero._proof_1_1`
- `AffineDualJT.ordinary_Bminus_nonzero._proof_1_1`
- `AffineDualJT.ordinary_Bminus_zero._proof_1_2`
- `AffineDualJT.ordinary_Bminus_zero_of_infinite._proof_1_1`
- `AffineDualJT.ordinary_Bminus_zero_of_infinite._proof_1_2`

### `AffineDualJT.OrdinaryC0Identity` (17)

- `AffineDualJT.C0_weight_zero`
- `AffineDualJT.DC_CC_C0_pairing`
- `AffineDualJT.ordinary_C0_identity`
- `AffineDualJT.ordinary_C0_nonzero`
- `AffineDualJT.ordinary_C0_zero`
- `AffineDualJT.C0_weight_zero._proof_1_1`
- `AffineDualJT.DC_CC_C0_pairing._proof_1_1`
- `AffineDualJT.ordinary_C0_nonzero._proof_1_8`
- `AffineDualJT.ordinary_C0_nonzero._simp_1_1`
- `AffineDualJT.ordinary_C0_nonzero._simp_1_2`
- `AffineDualJT.ordinary_C0_nonzero._simp_1_3`
- `AffineDualJT.ordinary_C0_nonzero._simp_1_4`
- `AffineDualJT.ordinary_C0_nonzero._simp_1_5`
- `AffineDualJT.ordinary_C0_nonzero._simp_1_6`
- `AffineDualJT.ordinary_C0_nonzero._simp_1_7`
- `AffineDualJT.ordinary_C0_zero._proof_1_1`
- `AffineDualJT.ordinary_C0_zero._proof_1_2`

### `AffineDualJT.OrdinaryColumnKernels` (17)

- `AffineDualJT.CC_C0_head`
- `AffineDualJT.VC0_transpose_CC`
- `AffineDualJT.bC0_small`
- `AffineDualJT.cC0_fixed`
- `AffineDualJT.cC0_zero`
- `AffineDualJT.CC_C0_head._proof_1_1`
- `AffineDualJT.CC_C0_head._proof_1_2`
- `AffineDualJT.CC_C0_head._proof_1_3`
- `AffineDualJT.CC_C0_head._proof_1_4`
- `AffineDualJT.CC_C0_head._proof_1_5`
- `AffineDualJT.VC0_transpose_CC._proof_1_1`
- `AffineDualJT.VC0_transpose_CC._proof_1_2`
- `AffineDualJT.VC0_transpose_CC._proof_1_3`
- `AffineDualJT.VC0_transpose_CC._proof_1_4`
- `AffineDualJT.VC0_transpose_CC._proof_1_5`
- `AffineDualJT.VC0_transpose_CC._proof_1_6`
- `AffineDualJT.bC0_small._proof_1_1`

### `AffineDualJT.OrdinaryIdentityTransfer` (3)

- `AffineDualJT.JK_of_zero_shifts`
- `AffineDualJT.omegaSign_mul_self`
- `AffineDualJT.ordinary_B_transfer`

### `AffineDualJT.OrdinarySequences` (24)

- `AffineDualJT.bB0Seq`
- `AffineDualJT.bB0_quasiperiod`
- `AffineDualJT.bBCSeq`
- `AffineDualJT.bBC_quasiperiod`
- `AffineDualJT.bBminusSeq`
- `AffineDualJT.bBminus_quasiperiod`
- `AffineDualJT.bC0Seq`
- `AffineDualJT.bC0_quasiperiod`
- `AffineDualJT.cBCSeq`
- `AffineDualJT.cBC_affine`
- `AffineDualJT.cBC_neg`
- `AffineDualJT.cC0Seq`
- `AffineDualJT.cC0_affine`
- `AffineDualJT.cC0_neg`
- `AffineDualJT.gammaB0`
- `AffineDualJT.gammaB0_first`
- `AffineDualJT.gammaB0_second`
- `AffineDualJT.gammaBminus`
- `AffineDualJT.gammaBminus_first`
- `AffineDualJT.gammaBminus_second`
- `AffineDualJT.cBCSeq.eq_1`
- `AffineDualJT.cC0Seq.eq_1`
- `AffineDualJT.gammaB0.eq_1`
- `AffineDualJT.gammaBminus.eq_1`

### `AffineDualJT.PaperAlternantDivisibility` (179)

- `AffineDualJT.paperAlternantPairIndex`
- `AffineDualJT.paperBasicAlternantPolynomial`
- `AffineDualJT.paperBasicFactor`
- `AffineDualJT.paperBasicFactorIndex`
- `AffineDualJT.paperBasicFactorProduct`
- `AffineDualJT.paperBminusAlternantPolynomial`
- `AffineDualJT.paperBminusFactor`
- `AffineDualJT.paperBminusFactorIndex`
- `AffineDualJT.paperBminusFactorProduct`
- `AffineDualJT.paperBminusRowQuotient`
- `AffineDualJT.paperCtAlternantPolynomial`
- `AffineDualJT.paperCtFactor`
- `AffineDualJT.paperCtFactorIndex`
- `AffineDualJT.paperCtFactorProduct`
- `AffineDualJT.paperCtRowQuotient`
- `AffineDualJT.paper_alternant_pairIndex_card`
- `AffineDualJT.paper_alternant_pairIndex_card_eq_triangular`
- `AffineDualJT.paper_basic_alternant_totalDegree_le`
- `AffineDualJT.paper_basic_column_degree_sum`
- `AffineDualJT.paper_basic_difference_factor_dvd_any_pair`
- `AffineDualJT.paper_basic_factor_degree_sum`
- `AffineDualJT.paper_basic_factor_dvd_any_pair`
- `AffineDualJT.paper_basic_factor_pairwise_isRelPrime`
- `AffineDualJT.paper_basic_factor_product_eq_Nt`
- `AffineDualJT.paper_basic_factor_product_totalDegree`
- `AffineDualJT.paper_basic_factor_product_totalDegree_eq`
- `AffineDualJT.paper_basic_factor_totalDegree`
- `AffineDualJT.paper_basic_full_factor_product_dvd`
- `AffineDualJT.paper_basic_last_variable_difference_dvd`
- `AffineDualJT.paper_basic_last_variable_factor_dvd`
- `AffineDualJT.paper_bminusColumn_totalDegree_le`
- `AffineDualJT.paper_bminus_alternant_totalDegree_le`
- `AffineDualJT.paper_bminus_column_degree_sum`
- `AffineDualJT.paper_bminus_column_extra_row_factor`
- `AffineDualJT.paper_bminus_determinant_extra_row_factors`
- `AffineDualJT.paper_bminus_difference_factor_dvd_any_pair`
- `AffineDualJT.paper_bminus_factor_dvd_any_pair`
- `AffineDualJT.paper_bminus_factor_pairwise_isRelPrime`
- `AffineDualJT.paper_bminus_factor_product_eq`
- `AffineDualJT.paper_bminus_factor_product_totalDegree`
- `AffineDualJT.paper_bminus_factor_product_totalDegree_eq`
- `AffineDualJT.paper_bminus_full_factor_product_dvd`
- `AffineDualJT.paper_bminus_last_variable_difference_dvd`
- `AffineDualJT.paper_bminus_last_variable_factor_dvd`
- `AffineDualJT.paper_bminus_row_factor_degreeOf_ne`
- `AffineDualJT.paper_bminus_row_factor_degreeOf_self`
- `AffineDualJT.paper_bminus_row_factor_irreducible`
- `AffineDualJT.paper_bminus_row_factor_totalDegree`
- `AffineDualJT.paper_bminus_row_isRelPrime_difference`
- `AffineDualJT.paper_bminus_row_isRelPrime_reciprocal`
- `AffineDualJT.paper_bminus_rows_isRelPrime`
- `AffineDualJT.paper_ctColumn_totalDegree_le`
- `AffineDualJT.paper_ct_alternant_totalDegree_le`
- `AffineDualJT.paper_ct_column_degree_sum`
- `AffineDualJT.paper_ct_column_extra_row_factor`
- `AffineDualJT.paper_ct_determinant_extra_row_factors`
- `AffineDualJT.paper_ct_difference_factor_dvd_any_pair`
- `AffineDualJT.paper_ct_factor_dvd_any_pair`
- `AffineDualJT.paper_ct_factor_pairwise_isRelPrime`
- `AffineDualJT.paper_ct_factor_product_eq`
- `AffineDualJT.paper_ct_factor_product_totalDegree`
- `AffineDualJT.paper_ct_factor_product_totalDegree_eq`
- `AffineDualJT.paper_ct_full_factor_product_dvd`
- `AffineDualJT.paper_ct_last_variable_difference_dvd`
- `AffineDualJT.paper_ct_last_variable_factor_dvd`
- `AffineDualJT.paper_ct_row_factor_degreeOf_ne`
- `AffineDualJT.paper_ct_row_factor_degreeOf_self`
- `AffineDualJT.paper_ct_row_factor_totalDegree`
- `AffineDualJT.paper_ct_row_isRelPrime_difference`
- `AffineDualJT.paper_ct_row_isRelPrime_reciprocal`
- `AffineDualJT.paper_ct_row_isRelPrime_reciprocal_any`
- `AffineDualJT.paper_ct_row_isRelPrime_sum`
- `AffineDualJT.paper_ct_rows_isRelPrime`
- `AffineDualJT.paper_det_totalDegree_le_sum_column_bounds`
- `AffineDualJT.paper_difference_factor_degreeOf_left`
- `AffineDualJT.paper_difference_factor_degreeOf_outside`
- `AffineDualJT.paper_difference_factor_degreeOf_right`
- `AffineDualJT.paper_difference_factor_irreducible`
- `AffineDualJT.paper_difference_factor_totalDegree`
- `AffineDualJT.paper_difference_isRelPrime_difference`
- `AffineDualJT.paper_fColumn_totalDegree_le`
- `AffineDualJT.paper_fin_upper_card`
- `AffineDualJT.paper_reciprocal_factor_degreeOf_left`
- `AffineDualJT.paper_reciprocal_factor_degreeOf_outside`
- `AffineDualJT.paper_reciprocal_factor_degreeOf_right`
- `AffineDualJT.paper_reciprocal_factor_irreducible`
- `AffineDualJT.paper_reciprocal_factor_totalDegree`
- `AffineDualJT.paper_reciprocal_isRelPrime_difference`
- `AffineDualJT.paper_reciprocal_isRelPrime_reciprocal`
- `AffineDualJT.paper_scalar_quotient_of_dvd_of_totalDegree_le`
- `AffineDualJT.paper_sum_factor_degreeOf_right`
- `AffineDualJT.paper_sum_factor_irreducible`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paperFinUpperEquiv`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paper_not_dvd_degreeOf_mismatch`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paper_one_add_odd_pow_geom`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paper_one_sub_pow_geom`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paper_totalDegree_finsetProd_eq_sum`
- `AffineDualJT.paperBasicFactor.eq_1`
- `AffineDualJT.paperBasicFactorProduct.eq_1`
- `AffineDualJT.paperBminusAlternantPolynomial.eq_1`
- `AffineDualJT.paperBminusFactor.eq_1`
- `AffineDualJT.paperBminusFactor.eq_2`
- `AffineDualJT.paperBminusFactor.match_1`
- `AffineDualJT.paperBminusFactorProduct.eq_1`
- `AffineDualJT.paperBminusRowQuotient.eq_1`
- `AffineDualJT.paperCtAlternantPolynomial.eq_1`
- `AffineDualJT.paperCtFactor.eq_1`
- `AffineDualJT.paperCtFactor.eq_2`
- `AffineDualJT.paperCtFactor.match_1`
- `AffineDualJT.paperCtFactorProduct.eq_1`
- `AffineDualJT.paperCtRowQuotient.eq_1`
- `AffineDualJT.paper_alternant_pairIndex_card_eq_triangular._proof_1_1`
- `AffineDualJT.paper_basic_column_degree_sum._proof_1_1`
- `AffineDualJT.paper_basic_difference_factor_dvd_any_pair._proof_1_1`
- `AffineDualJT.paper_basic_difference_factor_dvd_any_pair._proof_1_2`
- `AffineDualJT.paper_basic_factor_dvd_any_pair._proof_1_1`
- `AffineDualJT.paper_basic_factor_dvd_any_pair._proof_1_2`
- `AffineDualJT.paper_basic_factor_pairwise_isRelPrime._simp_1_1`
- `AffineDualJT.paper_basic_factor_pairwise_isRelPrime._simp_1_3`
- `AffineDualJT.paper_bminusColumn_totalDegree_le._proof_1_1`
- `AffineDualJT.paper_bminus_column_degree_sum._proof_1_1`
- `AffineDualJT.paper_bminus_column_extra_row_factor._proof_1_1`
- `AffineDualJT.paper_bminus_difference_factor_dvd_any_pair._proof_1_1`
- `AffineDualJT.paper_bminus_difference_factor_dvd_any_pair._proof_1_2`
- `AffineDualJT.paper_bminus_factor_dvd_any_pair._proof_1_1`
- `AffineDualJT.paper_bminus_factor_dvd_any_pair._proof_1_2`
- `AffineDualJT.paper_bminus_last_variable_factor_dvd._proof_1_1`
- `AffineDualJT.paper_bminus_row_factor_degreeOf_ne._proof_1_1`
- `AffineDualJT.paper_bminus_row_isRelPrime_difference._proof_1_1`
- `AffineDualJT.paper_bminus_row_isRelPrime_difference._proof_1_2`
- `AffineDualJT.paper_bminus_row_isRelPrime_reciprocal._proof_1_1`
- `AffineDualJT.paper_ctColumn_totalDegree_le._proof_1_1`
- `AffineDualJT.paper_ct_column_degree_sum._proof_1_1`
- `AffineDualJT.paper_ct_column_degree_sum._proof_1_2`
- `AffineDualJT.paper_ct_column_extra_row_factor._proof_1_1`
- `AffineDualJT.paper_ct_column_extra_row_factor._proof_1_2`
- `AffineDualJT.paper_ct_difference_factor_dvd_any_pair._proof_1_1`
- `AffineDualJT.paper_ct_difference_factor_dvd_any_pair._proof_1_2`
- `AffineDualJT.paper_ct_factor_dvd_any_pair._proof_1_1`
- `AffineDualJT.paper_ct_factor_dvd_any_pair._proof_1_2`
- `AffineDualJT.paper_ct_last_variable_factor_dvd._proof_1_1`
- `AffineDualJT.paper_ct_row_isRelPrime_difference._proof_1_1`
- `AffineDualJT.paper_ct_row_isRelPrime_difference._proof_1_2`
- `AffineDualJT.paper_ct_row_isRelPrime_reciprocal._proof_1_1`
- `AffineDualJT.paper_difference_factor_degreeOf_left._proof_1_1`
- `AffineDualJT.paper_difference_factor_degreeOf_outside._proof_1_1`
- `AffineDualJT.paper_difference_factor_degreeOf_right._proof_1_1`
- `AffineDualJT.paper_difference_isRelPrime_difference._proof_1_1`
- `AffineDualJT.paper_difference_isRelPrime_difference._proof_1_2`
- `AffineDualJT.paper_fColumn_totalDegree_le._proof_1_1`
- `AffineDualJT.paper_reciprocal_factor_degreeOf_outside._proof_1_1`
- `AffineDualJT.paper_reciprocal_isRelPrime_difference._proof_1_1`
- `AffineDualJT.paper_reciprocal_isRelPrime_reciprocal._proof_1_1`
- `AffineDualJT.paper_reciprocal_isRelPrime_reciprocal._proof_1_2`
- `AffineDualJT.paper_scalar_quotient_of_dvd_of_totalDegree_le._proof_1_1`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paperFinUpperEquiv._proof_1`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paperFinUpperEquiv._proof_10`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paperFinUpperEquiv._proof_11`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paperFinUpperEquiv._proof_12`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paperFinUpperEquiv._proof_13`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paperFinUpperEquiv._proof_2`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paperFinUpperEquiv._proof_3`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paperFinUpperEquiv._proof_4`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paperFinUpperEquiv._proof_5`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paperFinUpperEquiv._proof_6`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paperFinUpperEquiv._proof_7`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paperFinUpperEquiv._proof_8`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paperFinUpperEquiv._proof_9`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paper_not_dvd_degreeOf_mismatch._proof_1_1`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paper_one_add_odd_pow_geom._f`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paper_one_add_odd_pow_geom.match_1_1`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paper_one_sub_pow_geom._f`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paper_one_sub_pow_geom.match_1_1`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paperBminusFactor.match_1.eq_1`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paperBminusFactor.match_1.eq_2`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paperBminusFactor.match_1.splitter`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paperCtFactor.match_1.eq_1`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paperCtFactor.match_1.eq_2`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paperCtFactor.match_1.splitter`

### `AffineDualJT.PaperAlternantNormalization` (55)

- `AffineDualJT.PaperScaledPoly`
- `AffineDualJT.paperBasicScaledMatrix`
- `AffineDualJT.paperBasicScaledNtRest`
- `AffineDualJT.paperBasicScaledReduced`
- `AffineDualJT.paperBminusScaledMatrix`
- `AffineDualJT.paperBminusScaledReduced`
- `AffineDualJT.paperCtScaledMatrix`
- `AffineDualJT.paperCtScaledReduced`
- `AffineDualJT.paperScaleHom`
- `AffineDualJT.paper_Nt_scale_lowest_coeff`
- `AffineDualJT.paper_basic_factor_scale_lowest_coeff`
- `AffineDualJT.paper_basic_factorization_by_lowest_part`
- `AffineDualJT.paper_basic_factorization_zero`
- `AffineDualJT.paper_basic_lower_exponent_sum`
- `AffineDualJT.paper_basic_scale_lowest_coeff`
- `AffineDualJT.paper_basic_scaled_det_eval_zero`
- `AffineDualJT.paper_basic_scaled_reduced_eval_zero`
- `AffineDualJT.paper_bminus_factor_scale_lowest_coeff`
- `AffineDualJT.paper_bminus_factorization_by_lowest_part`
- `AffineDualJT.paper_bminus_factorization_zero`
- `AffineDualJT.paper_bminus_scale_lowest_coeff`
- `AffineDualJT.paper_bminus_scaled_det_eval_zero`
- `AffineDualJT.paper_bminus_scaled_reduced_eval_zero`
- `AffineDualJT.paper_coeff_row_mul_X_pow`
- `AffineDualJT.paper_ct_factor_scale_lowest_coeff`
- `AffineDualJT.paper_ct_factorization_by_lowest_part`
- `AffineDualJT.paper_ct_factorization_zero`
- `AffineDualJT.paper_ct_scale_lowest_coeff`
- `AffineDualJT.paper_ct_scaled_det_eval_zero`
- `AffineDualJT.paper_ct_scaled_reduced_eval_zero`
- `AffineDualJT.paper_descending_vandermonde_eq_pair_product`
- `AffineDualJT.paper_scale_Nt`
- `AffineDualJT.paper_scale_basic_alternant`
- `AffineDualJT.paper_scale_bminusColumn`
- `AffineDualJT.paper_scale_bminus_alternant`
- `AffineDualJT.paper_scale_ctColumn`
- `AffineDualJT.paper_scale_ct_alternant`
- `AffineDualJT.paper_scale_fColumn`
- `_private.AffineDualJT.PaperAlternantNormalization.0.AffineDualJT.paper_normalize_scalar_from_lowest_coeff`
- `_private.AffineDualJT.PaperAlternantNormalization.0.AffineDualJT.paper_pair_product_ne_zero`
- `AffineDualJT.paperBasicScaledMatrix.eq_1`
- `AffineDualJT.paperBasicScaledNtRest.eq_1`
- `AffineDualJT.paperBasicScaledReduced.eq_1`
- `AffineDualJT.paperBminusScaledMatrix.eq_1`
- `AffineDualJT.paperBminusScaledReduced.eq_1`
- `AffineDualJT.paperCtScaledMatrix.eq_1`
- `AffineDualJT.paperCtScaledReduced.eq_1`
- `AffineDualJT.paperScaleHom.eq_1`
- `AffineDualJT.paper_basic_lower_exponent_sum._proof_1_1`
- `AffineDualJT.paper_basic_scaled_reduced_eval_zero._proof_1_1`
- `AffineDualJT.paper_descending_vandermonde_eq_pair_product._proof_1_2`
- `AffineDualJT.paper_descending_vandermonde_eq_pair_product._simp_1_1`
- `AffineDualJT.paper_scale_bminusColumn._proof_1_3`
- `AffineDualJT.paper_scale_ctColumn._proof_1_3`
- `AffineDualJT.paper_scale_fColumn._proof_1_3`

### `AffineDualJT.PaperCauchyBinet` (42)

- `AffineDualJT.paper_cauchy_binet`
- `AffineDualJT.paper_cauchy_binet_complement_sum`
- `AffineDualJT.paper_cauchy_binet_fixed_subset`
- `AffineDualJT.paper_det_mul_fixed_image_fiber`
- `AffineDualJT.paper_det_mul_injective_intermediate`
- `AffineDualJT.paper_det_mul_intermediate_expansion`
- `AffineDualJT.paper_det_mul_intermediate_minors`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperInjectiveTupleEquiv`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperInjectiveTupleEquiv_spec`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperPermOfTuple`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperPermOfTuple_spec`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperSubsetComplementEquiv`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paper_card_compl_fin`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paper_card_image_injective`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paper_orderEmb_eq_of_finset_eq`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paper_orderEmb_equiv_image`
- `AffineDualJT.paper_det_mul_injective_intermediate._simp_1_1`
- `AffineDualJT.paper_det_mul_injective_intermediate._simp_1_2`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperInjectiveTupleEquiv._proof_1`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperInjectiveTupleEquiv._proof_10`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperInjectiveTupleEquiv._proof_11`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperInjectiveTupleEquiv._proof_12`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperInjectiveTupleEquiv._proof_2`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperInjectiveTupleEquiv._proof_3`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperInjectiveTupleEquiv._proof_4`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperInjectiveTupleEquiv._proof_5`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperInjectiveTupleEquiv._proof_6`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperInjectiveTupleEquiv._proof_7`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperInjectiveTupleEquiv._proof_8`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperInjectiveTupleEquiv._proof_9`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperPermOfTuple._proof_1`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperPermOfTuple._proof_2`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperPermOfTuple._proof_3`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperPermOfTuple.eq_1`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperSubsetComplementEquiv._proof_1`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperSubsetComplementEquiv._proof_2`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperSubsetComplementEquiv._proof_3`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperSubsetComplementEquiv._proof_4`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperSubsetComplementEquiv._proof_5`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperSubsetComplementEquiv._proof_6`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperSubsetComplementEquiv._proof_7`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paper_card_compl_fin._proof_1_1`

### `AffineDualJT.PaperField` (18)

- `AffineDualJT.PaperField`
- `AffineDualJT.coe_paperVariables`
- `AffineDualJT.paperParameter`
- `AffineDualJT.paperParameter_ne_zero`
- `AffineDualJT.paperVariable`
- `AffineDualJT.paperVariable_ne_zero`
- `AffineDualJT.paperVariable_one_sub_mul_ne_zero`
- `AffineDualJT.paperVariable_one_sub_ne_zero`
- `AffineDualJT.paperVariable_one_sub_sq_ne_zero`
- `AffineDualJT.paperVariable_sub_ne_zero`
- `AffineDualJT.paperVariables`
- `AffineDualJT.paperParameter._proof_1`
- `AffineDualJT.paperParameter._proof_2`
- `AffineDualJT.paperParameter_ne_zero._simp_1`
- `AffineDualJT.paperVariable.eq_1`
- `AffineDualJT.paperVariables._proof_1`
- `AffineDualJT.paperVariables._proof_2`
- `AffineDualJT.paperVariables._proof_3`

### `AffineDualJT.PaperIdentities` (9)

- `AffineDualJT.paper_theorem_A_1_3`
- `AffineDualJT.paper_theorem_A_1_4`
- `AffineDualJT.paper_theorem_A_1_5`
- `AffineDualJT.paper_theorem_A_1_6`
- `AffineDualJT.paper_theorem_A_1_7`
- `AffineDualJT.paper_theorem_A_1_8`
- `AffineDualJT.paper_theorem_A_Bplus_width_zero`
- `AffineDualJT.paper_theorem_B_1_9`
- `AffineDualJT.paper_theorem_B_Bt_width_zero`

### `AffineDualJT.PaperNormalizations` (14)

- `AffineDualJT.paper_Vn_ne_zero`
- `AffineDualJT.paper_Vn_pow_ne_zero`
- `AffineDualJT.paper_nuBminus_ne_zero`
- `AffineDualJT.paper_nuBplus_ne_zero`
- `AffineDualJT.paper_nuCt_ne_zero`
- `AffineDualJT.paper_pochhammer_Bminus_ne_zero`
- `AffineDualJT.paper_pochhammer_Bplus_ne_zero`
- `AffineDualJT.paper_pochhammer_Ct_ne_zero`
- `_private.AffineDualJT.PaperNormalizations.0.AffineDualJT.mapped_polynomial_ne_zero`
- `AffineDualJT.paperParameter.eq_1`
- `AffineDualJT.paper_Vn_pow_ne_zero._proof_1_1`
- `AffineDualJT.paper_pochhammer_Bminus_ne_zero._proof_1_1`
- `AffineDualJT.paper_pochhammer_Bplus_ne_zero._proof_1_1`
- `AffineDualJT.paper_pochhammer_Ct_ne_zero._proof_1_1`

### `AffineDualJT.PaperPropositions` (22)

- `AffineDualJT.paper_lemma_5_2_affine`
- `AffineDualJT.paper_lemma_5_2_center`
- `AffineDualJT.paper_lemma_5_2_fixed`
- `AffineDualJT.paper_lemma_5_2_quasiperiod`
- `AffineDualJT.paper_lemma_5_4_eq_5_3`
- `AffineDualJT.paper_lemma_5_4_eq_5_4`
- `AffineDualJT.paper_lemma_5_4_eq_5_5`
- `AffineDualJT.paper_lemma_5_4_fixed`
- `AffineDualJT.paper_prop_2_2_B0`
- `AffineDualJT.paper_prop_2_2_BC`
- `AffineDualJT.paper_prop_2_2_Bminus`
- `AffineDualJT.paper_prop_2_2_Bplus`
- `AffineDualJT.paper_prop_2_2_Bt`
- `AffineDualJT.paper_prop_2_2_C0`
- `AffineDualJT.paper_prop_2_2_Ct`
- `AffineDualJT.paper_prop_4_1_BC`
- `AffineDualJT.paper_prop_4_1_C0`
- `AffineDualJT.paper_prop_4_2_B0`
- `AffineDualJT.paper_prop_4_2_Bminus`
- `AffineDualJT.paper_prop_5_1_Ct`
- `AffineDualJT.paper_prop_5_3_Bplus`
- `AffineDualJT.paper_prop_5_5_Bt`

### `AffineDualJT.PaperRegularity` (9)

- `AffineDualJT.paper_admissible`
- `AffineDualJT.paper_admissible_Bminus`
- `AffineDualJT.paper_admissible_Bplus`
- `AffineDualJT.paper_admissible_Ct`
- `AffineDualJT.paper_admissible_of_normalization`
- `AffineDualJT.paper_admissible_squared`
- `AffineDualJT.signed_paper_boundary`
- `AffineDualJT.signed_paper_distinct`
- `AffineDualJT.signed_paper_pair`

### `AffineDualJT.PaperSpecializations` (20)

- `AffineDualJT.paper_admissible_zero`
- `AffineDualJT.paper_cor_6_2_B0_zero`
- `AffineDualJT.paper_cor_6_2_BC_zero`
- `AffineDualJT.paper_cor_6_2_Bminus_zero`
- `AffineDualJT.paper_cor_6_2_Bplus_zero`
- `AffineDualJT.paper_cor_6_2_Bt_zero`
- `AffineDualJT.paper_cor_6_2_C0_zero`
- `AffineDualJT.paper_cor_6_2_Ct_zero`
- `AffineDualJT.paper_cor_6_2_eq_6_1`
- `AffineDualJT.paper_cor_6_2_eq_6_2a`
- `AffineDualJT.paper_cor_6_2_eq_6_2b`
- `AffineDualJT.paper_cor_6_2_eq_6_2b_ratio`
- `AffineDualJT.paper_cor_6_2_eq_6_3`
- `AffineDualJT.paper_prop_6_1_B0`
- `AffineDualJT.paper_prop_6_1_BC`
- `AffineDualJT.paper_prop_6_1_Bminus`
- `AffineDualJT.paper_prop_6_1_Bplus`
- `AffineDualJT.paper_prop_6_1_Bt`
- `AffineDualJT.paper_prop_6_1_C0`
- `AffineDualJT.paper_prop_6_1_Ct`

### `AffineDualJT.PaperTopForms` (118)

- `AffineDualJT.paperEpsilon`
- `AffineDualJT.paperEpsilon_firstCols`
- `AffineDualJT.paperEpsilon_lastRows`
- `AffineDualJT.paperFinsetSplit`
- `AffineDualJT.paperFinsetSplit_sign_eq_paperEpsilon`
- `AffineDualJT.paperFixedColumnDetAlternating`
- `AffineDualJT.paperFixedColumnDetAlternating_apply`
- `AffineDualJT.paperFixedColumnDetAlternating_coordinate`
- `AffineDualJT.paperFixedColumnDetAlternating_eq_of_representatives`
- `AffineDualJT.paperFixedColumnDetAlternating_section_eq`
- `AffineDualJT.paperFixedColumnDetMultilinear`
- `AffineDualJT.paperFixedColumnDetMultilinear_apply`
- `AffineDualJT.paperImageTopForm`
- `AffineDualJT.paperSplitRows`
- `AffineDualJT.paper_XU_complementary_minor_relation`
- `AffineDualJT.paper_XU_coordinate_minor_relation`
- `AffineDualJT.paper_XU_finset_complement_relation`
- `AffineDualJT.paper_XU_quotient_forms_proportional`
- `AffineDualJT.paper_XU_standard_complement_relation`
- `AffineDualJT.paper_YZ_complementary_minor_relation`
- `AffineDualJT.paper_YZ_coordinate_minor_relation`
- `AffineDualJT.paper_YZ_finset_complement_relation`
- `AffineDualJT.paper_YZ_quotient_forms_proportional`
- `AffineDualJT.paper_YZ_standard_complement_relation`
- `AffineDualJT.paper_coordinate_augmented_det`
- `AffineDualJT.paper_matrix_image_in_kernel`
- `AffineDualJT.paper_matrix_quotient_equiv`
- `AffineDualJT.paper_matrix_quotient_equiv_coordinate_apply`
- `AffineDualJT.paper_matrix_quotient_equiv_mkQ_apply`
- `AffineDualJT.paper_matrix_range_eq_kernel`
- `AffineDualJT.paper_quotient_coordinate_minor_relation`
- `AffineDualJT.paper_quotient_has_linear_section`
- `AffineDualJT.paper_quotient_induced_map_injective`
- `AffineDualJT.paper_quotient_top_forms_proportional`
- `AffineDualJT.paper_transpose_quotient_equiv`
- `AffineDualJT.paper_transpose_quotient_equiv_coordinate_apply`
- `AffineDualJT.paper_transpose_range_eq_kernel`
- `AffineDualJT.topAlternatingForms_proportional`
- `finSumEquivOfFinset.congr_simp`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.det_fromRows_add_rowSpan`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperCoordinateVector`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperFinsetSplitPermFin`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperFinsetSplitPermFin_left`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperFinsetSplitPermFin_right`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperLastRowsEmb`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperQ0BlockFlip`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperQ0Split`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperQ0Split_left`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperQ0Split_right`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperQ0Split_sign`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperRowStack`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paper_card_Q_before`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paper_card_complement_before`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paper_complement_card`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paper_matrix_mulVec_coordinate`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paper_prod_ite_sign`
- `AffineDualJT.paperEpsilon.congr_simp`
- `AffineDualJT.paperEpsilon.eq_1`
- `AffineDualJT.paperFinsetSplit._proof_1`
- `AffineDualJT.paperFinsetSplit.eq_1`
- `AffineDualJT.paperFinsetSplit_sign_eq_paperEpsilon._proof_1_3`
- `AffineDualJT.paperFinsetSplit_sign_eq_paperEpsilon._proof_1_4`
- `AffineDualJT.paperFinsetSplit_sign_eq_paperEpsilon._simp_1_5`
- `AffineDualJT.paperFinsetSplit_sign_eq_paperEpsilon._simp_1_6`
- `AffineDualJT.paperFinsetSplit_sign_eq_paperEpsilon._simp_1_7`
- `AffineDualJT.paperFinsetSplit_sign_eq_paperEpsilon._simp_1_8`
- `AffineDualJT.paperFinsetSplit_sign_eq_paperEpsilon._simp_1_9`
- `AffineDualJT.paperFixedColumnDetAlternating._proof_1`
- `AffineDualJT.paperFixedColumnDetMultilinear._proof_1`
- `AffineDualJT.paperFixedColumnDetMultilinear._proof_2`
- `AffineDualJT.paperFixedColumnDetMultilinear._proof_3`
- `AffineDualJT.paperImageTopForm._proof_1`
- `AffineDualJT.paperSplitRows.eq_1`
- `AffineDualJT.paper_XU_standard_complement_relation._proof_1_1`
- `AffineDualJT.paper_XU_standard_complement_relation._proof_1_2`
- `AffineDualJT.paper_YZ_standard_complement_relation._proof_1_1`
- `AffineDualJT.paper_YZ_standard_complement_relation._proof_1_3`
- `AffineDualJT.paper_coordinate_augmented_det._simp_1_2`
- `AffineDualJT.paper_matrix_quotient_equiv._proof_1`
- `AffineDualJT.paper_matrix_quotient_equiv._proof_2`
- `AffineDualJT.paper_matrix_quotient_equiv._proof_3`
- `AffineDualJT.paper_matrix_quotient_equiv._proof_4`
- `AffineDualJT.paper_matrix_quotient_equiv._proof_5`
- `AffineDualJT.paper_matrix_quotient_equiv._proof_6`
- `AffineDualJT.paper_matrix_quotient_equiv._proof_7`
- `AffineDualJT.paper_quotient_top_forms_proportional._simp_1_1`
- `AffineDualJT.paper_transpose_quotient_equiv._proof_1`
- `AffineDualJT.paper_transpose_quotient_equiv._proof_2`
- `AffineDualJT.paper_transpose_quotient_equiv._proof_3`
- `AffineDualJT.paper_transpose_quotient_equiv._proof_4`
- `AffineDualJT.paper_transpose_quotient_equiv._proof_5`
- `AffineDualJT.paper_transpose_range_eq_kernel._proof_1_1`
- `AffineDualJT.paper_transpose_range_eq_kernel._proof_1_2`
- `Fin.castAdd.eq_1`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperCoordinateVector.eq_1`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperFinsetSplitPermFin.congr_simp`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperFinsetSplitPermFin.eq_1`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperLastRowsEmb._proof_1`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperLastRowsEmb._proof_2`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperLastRowsEmb._proof_3`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperQ0BlockFlip.eq_1`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperQ0Split.eq_1`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperRowStack.eq_1`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperRowStack.eq_2`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperRowStack.match_1`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paper_card_Q_before._simp_1_1`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paper_card_Q_before._simp_1_2`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paper_card_Q_before._simp_1_3`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paper_card_Q_before._simp_1_4`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paper_card_complement_before._proof_1_2`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paper_card_complement_before._simp_1_1`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paper_complement_card._proof_1_1`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paper_matrix_mulVec_coordinate._simp_1_2`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paper_prod_ite_sign._proof_1_1`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paper_prod_ite_sign._proof_1_2`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperRowStack.match_1.eq_1`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperRowStack.match_1.eq_2`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperRowStack.match_1.splitter`

### `AffineDualJT.PaperWeylRegularity` (4)

- `AffineDualJT.paper_DeltaB_ne_zero`
- `AffineDualJT.paper_DeltaC_ne_zero`
- `AffineDualJT.paper_DeltaPlus_ne_zero`
- `AffineDualJT.paper_Nt_one_ne_zero`

### `AffineDualJT.ParameterPolynomials` (9)

- `AffineDualJT.eval_parameterJKPolynomial`
- `AffineDualJT.eval_parameterWeylPolynomial`
- `AffineDualJT.parameterJKPolynomial`
- `AffineDualJT.parameterWeylPolynomial`
- `AffineDualJT.polynomial_eval_zero_of_nonzero`
- `AffineDualJT.pow_toNat_eq_zpow`
- `AffineDualJT.reducedWeyl_eq_JK_zero_of_nonzero`
- `AffineDualJT.parameterWeylPolynomial.eq_1`
- `AffineDualJT.AffineDetSum.jkMatrix.eq_1`

### `AffineDualJT.PermutationSigns` (13)

- `AffineDualJT.paperBlockFlip`
- `AffineDualJT.paperBlockFlip_pow`
- `AffineDualJT.paperBlockFlip_sign`
- `AffineDualJT.paperBlockFlip_zero`
- `AffineDualJT.paperBlockFlip.eq_1`
- `AffineDualJT.paperBlockFlip_pow._proof_1_1`
- `AffineDualJT.paperBlockFlip_pow._proof_1_2`
- `AffineDualJT.paperBlockFlip_pow._proof_1_4`
- `AffineDualJT.paperBlockFlip_pow._proof_1_5`
- `AffineDualJT.paperBlockFlip_pow._proof_1_6`
- `AffineDualJT.paperBlockFlip_pow._proof_1_7`
- `AffineDualJT.paperBlockFlip_sign._proof_1_1`
- `AffineDualJT.paperBlockFlip_zero._proof_1_2`

### `AffineDualJT.PlusFoldEvaluation` (4)

- `AffineDualJT.bracketPlus_sum_normalized`
- `AffineDualJT.bracketPlus_sum_normalized._proof_1_2`
- `AffineDualJT.bracketPlus_sum_normalized._proof_1_3`
- `AffineDualJT.bracketPlus_sum_normalized._simp_1_1`

### `AffineDualJT.ReducedNumerators` (5)

- `AffineDualJT.Nt_one_pair_ne_zero`
- `AffineDualJT.Nt_ratio`
- `AffineDualJT.basicWeightedMatrix`
- `AffineDualJT.basicWeightedMatrix_det`
- `AffineDualJT.basicWeightedMatrix_plus_ratio`

### `AffineDualJT.ResidueSequences` (17)

- `AffineDualJT.center_fold_affine`
- `AffineDualJT.odd_fold_affine`
- `AffineDualJT.residueSum`
- `AffineDualJT.residueSum_minus_pairing`
- `AffineDualJT.residueSum_minus_quasiperiod`
- `AffineDualJT.residueSum_minus_small`
- `AffineDualJT.residueSum_pairing`
- `AffineDualJT.residueSum_quasiperiod`
- `AffineDualJT.residueSum_small`
- `AffineDualJT.residueSum_zero`
- `AffineDualJT.residue_point_eq`
- `AffineDualJT.residue_point_hasFiniteSupport`
- `AffineDualJT.residueSum.eq_1`
- `AffineDualJT.residueSum_small._proof_1_1`
- `AffineDualJT.residueSum_small._proof_1_2`
- `AffineDualJT.residue_point_hasFiniteSupport._simp_1_1`
- `AffineDualJT.residue_point_hasFiniteSupport._simp_1_2`

### `AffineDualJT.Section4Ordinary` (4)

- `AffineDualJT.prop_4_1_BC`
- `AffineDualJT.prop_4_1_C0`
- `AffineDualJT.prop_4_2_B0`
- `AffineDualJT.prop_4_2_Bminus`

### `AffineDualJT.Section5Exceptional` (3)

- `AffineDualJT.prop_5_1_Ct`
- `AffineDualJT.prop_5_3_Bplus`
- `AffineDualJT.prop_5_5_Bt`

### `AffineDualJT.SignedDeterminants` (15)

- `AffineDualJT.Cfun_inv`
- `AffineDualJT.coe_invertedVariables`
- `AffineDualJT.deltaB_invertedVariables`
- `AffineDualJT.deltaB_invertedVariables_ne_zero`
- `AffineDualJT.deltaC_invertedVariables`
- `AffineDualJT.deltaC_invertedVariables_ne_zero`
- `AffineDualJT.deltaPlus_invertedVariables`
- `AffineDualJT.det_bool_rows`
- `AffineDualJT.invertedVariables`
- `AffineDualJT.phi_inv`
- `AffineDualJT.psi_inv`
- `AffineDualJT.Cfun_inv._simp_1_1`
- `AffineDualJT.invertedVariables.eq_1`
- `AffineDualJT.phi_inv._simp_1_1`
- `AffineDualJT.psi_inv._simp_1_1`

### `AffineDualJT.SymmetricPairProducts` (7)

- `AffineDualJT.pairProduct_permutation`
- `_private.AffineDualJT.SymmetricPairProducts.0.AffineDualJT.pairPermutation`
- `_private.AffineDualJT.SymmetricPairProducts.0.AffineDualJT.permutePair`
- `_private.AffineDualJT.SymmetricPairProducts.0.AffineDualJT.permutePair_inverse`
- `_private.AffineDualJT.SymmetricPairProducts.0.AffineDualJT.pairPermutation._proof_1`
- `_private.AffineDualJT.SymmetricPairProducts.0.AffineDualJT.permutePair._proof_1`
- `_private.AffineDualJT.SymmetricPairProducts.0.AffineDualJT.permutePair.eq_1`

### `AffineDualJT.WeightExponents` (52)

- `AffineDualJT.B0_exponent_cast`
- `AffineDualJT.B0_exponent_exact`
- `AffineDualJT.B0_exponent_nonneg`
- `AffineDualJT.B0_exponent_numerator_even`
- `AffineDualJT.B0_exponent_pos`
- `AffineDualJT.BC_exponent_nonneg`
- `AffineDualJT.Bminus_exponent_nonneg`
- `AffineDualJT.Bplus_Bt_exponent_nonneg`
- `AffineDualJT.Bplus_Bt_exponent_pos`
- `AffineDualJT.Bplus_exponent_pos`
- `AffineDualJT.Bt_exponent_pos`
- `AffineDualJT.C0_exponent_nonneg`
- `AffineDualJT.C0_exponent_pos`
- `AffineDualJT.Ct_exponent_nonneg`
- `AffineDualJT.Ct_exponent_pos_except`
- `AffineDualJT.Ct_exponent_zero_iff`
- `AffineDualJT.quadratic_exponent_nonneg`
- `AffineDualJT.B0_exponent_nonneg._proof_1_1`
- `AffineDualJT.B0_exponent_nonneg._proof_1_2`
- `AffineDualJT.B0_exponent_nonneg._proof_1_3`
- `AffineDualJT.B0_exponent_pos._proof_1_1`
- `AffineDualJT.B0_exponent_pos._proof_1_2`
- `AffineDualJT.B0_exponent_pos._proof_1_3`
- `AffineDualJT.BC_exponent_nonneg._proof_1_1`
- `AffineDualJT.BC_exponent_nonneg._proof_1_2`
- `AffineDualJT.BC_exponent_nonneg._proof_1_3`
- `AffineDualJT.Bminus_exponent_nonneg._proof_1_1`
- `AffineDualJT.Bminus_exponent_nonneg._proof_1_2`
- `AffineDualJT.Bminus_exponent_nonneg._proof_1_3`
- `AffineDualJT.Bplus_Bt_exponent_nonneg._proof_1_1`
- `AffineDualJT.Bplus_Bt_exponent_nonneg._proof_1_2`
- `AffineDualJT.Bplus_Bt_exponent_nonneg._proof_1_3`
- `AffineDualJT.Bplus_Bt_exponent_pos._proof_1_1`
- `AffineDualJT.Bplus_Bt_exponent_pos._proof_1_2`
- `AffineDualJT.Bplus_Bt_exponent_pos._proof_1_3`
- `AffineDualJT.Bplus_Bt_exponent_pos._proof_1_4`
- `AffineDualJT.C0_exponent_nonneg._proof_1_1`
- `AffineDualJT.C0_exponent_nonneg._proof_1_2`
- `AffineDualJT.C0_exponent_nonneg._proof_1_3`
- `AffineDualJT.C0_exponent_pos._proof_1_1`
- `AffineDualJT.C0_exponent_pos._proof_1_2`
- `AffineDualJT.C0_exponent_pos._proof_1_3`
- `AffineDualJT.C0_exponent_pos._proof_1_4`
- `AffineDualJT.Ct_exponent_nonneg._proof_1_1`
- `AffineDualJT.Ct_exponent_nonneg._proof_1_2`
- `AffineDualJT.Ct_exponent_zero_iff._proof_1_1`
- `AffineDualJT.Ct_exponent_zero_iff._proof_1_2`
- `AffineDualJT.Ct_exponent_zero_iff._proof_1_3`
- `AffineDualJT.Ct_exponent_zero_iff._proof_1_4`
- `AffineDualJT.quadratic_exponent_nonneg._proof_1_1`
- `AffineDualJT.quadratic_exponent_nonneg._proof_1_2`
- `AffineDualJT.quadratic_exponent_nonneg._proof_1_3`

### `AffineDualJT.WeylAdmissibility` (4)

- `AffineDualJT.admissible_DeltaB_ne_zero`
- `AffineDualJT.admissible_DeltaC_ne_zero`
- `AffineDualJT.admissible_DeltaPlus_ne_zero`
- `AffineDualJT.admissible_Nt_one_ne_zero`

### `AffineDualJT.WeylDenominators` (29)

- `AffineDualJT.deltaB_product`
- `AffineDualJT.deltaB_vandermonde`
- `AffineDualJT.deltaC_product`
- `AffineDualJT.deltaC_vandermonde`
- `AffineDualJT.deltaPlus_product`
- `AffineDualJT.deltaPlus_vandermonde`
- `AffineDualJT.prod_pair_endpoints`
- `AffineDualJT.vandermonde_add_inv_product`
- `AffineDualJT.DeltaB.eq_1`
- `AffineDualJT.deltaB_product._proof_1_2`
- `AffineDualJT.deltaC_product._proof_1_2`
- `AffineDualJT.deltaC_product._simp_1_3`
- `AffineDualJT.deltaC_product._simp_1_4`
- `AffineDualJT.deltaC_product._simp_1_5`
- `AffineDualJT.deltaC_product._simp_1_6`
- `AffineDualJT.deltaC_product._simp_1_7`
- `AffineDualJT.deltaC_product._simp_1_8`
- `AffineDualJT.deltaC_product._simp_1_9`
- `AffineDualJT.deltaPlus_product._proof_1_2`
- `AffineDualJT.prod_pair_endpoints._proof_1_2`
- `AffineDualJT.prod_pair_endpoints._simp_1_1`
- `AffineDualJT.psi.eq_1`
- `AffineDualJT.vandermonde_add_inv_product._simp_1_1`
- `AffineDualJT.vandermonde_add_inv_product._simp_1_2`
- `AffineDualJT.vandermonde_add_inv_product._simp_1_3`
- `AffineDualJT.vandermonde_add_inv_product._simp_1_4`
- `AffineDualJT.vandermonde_add_inv_product._simp_1_5`
- `AffineDualJT.vandermonde_add_inv_product._simp_1_6`
- `AffineDualJT.vandermonde_add_inv_product._simp_1_7`

### `AffineDualJT.WeylMatrices` (10)

- `AffineDualJT.Cfun`
- `AffineDualJT.DeltaB`
- `AffineDualJT.DeltaC`
- `AffineDualJT.DeltaPlus`
- `AffineDualJT.Nt`
- `AffineDualJT.PhiB`
- `AffineDualJT.PhiC`
- `AffineDualJT.PhiPlus`
- `AffineDualJT.phi`
- `AffineDualJT.psi`

### `AffineDualJT.WeylPolynomials` (39)

- `AffineDualJT.dickson_monic_natDegree_pos`
- `AffineDualJT.weylPolyB`
- `AffineDualJT.weylPolyB_eval`
- `AffineDualJT.weylPolyB_monic_degree`
- `AffineDualJT.weylPolyC`
- `AffineDualJT.weylPolyC_eval`
- `AffineDualJT.weylPolyC_monic_degree`
- `AffineDualJT.weylPolyPlus`
- `AffineDualJT.weylPolyPlus_eval`
- `AffineDualJT.weylPolyPlus_monic_degree`
- `_private.AffineDualJT.WeylPolynomials.0.AffineDualJT.bKind_eval`
- `_private.AffineDualJT.WeylPolynomials.0.AffineDualJT.dickson_degree_data`
- `_private.AffineDualJT.WeylPolynomials.0.AffineDualJT.secondKind_eval`
- `_private.AffineDualJT.WeylPolynomials.0.AffineDualJT.weylPolyB_add_two`
- `AffineDualJT.weylPolyB.eq_1`
- `AffineDualJT.weylPolyB_eval._simp_1_1`
- `AffineDualJT.weylPolyB_eval._simp_1_2`
- `AffineDualJT.weylPolyB_monic_degree._proof_1_2`
- `AffineDualJT.weylPolyB_monic_degree._proof_1_3`
- `AffineDualJT.weylPolyC.eq_1`
- `AffineDualJT.weylPolyC_eval._simp_1_2`
- `AffineDualJT.weylPolyC_eval._simp_1_3`
- `AffineDualJT.weylPolyC_monic_degree._proof_1_2`
- `AffineDualJT.weylPolyPlus.eq_1`
- `AffineDualJT.weylPolyPlus_eval._simp_1_2`
- `AffineDualJT.weylPolyPlus_eval._simp_1_3`
- `AffineDualJT.weylPolyPlus_monic_degree._proof_1_2`
- `_private.AffineDualJT.WeylPolynomials.0.AffineDualJT.bKind_eval._f`
- `_private.AffineDualJT.WeylPolynomials.0.AffineDualJT.bKind_eval.match_1_1`
- `_private.AffineDualJT.WeylPolynomials.0.AffineDualJT.dickson_degree_data._f`
- `_private.AffineDualJT.WeylPolynomials.0.AffineDualJT.dickson_degree_data._proof_1_6`
- `_private.AffineDualJT.WeylPolynomials.0.AffineDualJT.dickson_degree_data._proof_1_7`
- `_private.AffineDualJT.WeylPolynomials.0.AffineDualJT.dickson_degree_data._simp_1_3`
- `_private.AffineDualJT.WeylPolynomials.0.AffineDualJT.dickson_degree_data._simp_1_4`
- `_private.AffineDualJT.WeylPolynomials.0.AffineDualJT.dickson_degree_data._simp_1_5`
- `_private.AffineDualJT.WeylPolynomials.0.AffineDualJT.dickson_degree_data.match_1_1`
- `_private.AffineDualJT.WeylPolynomials.0.AffineDualJT.secondKind_eval._f`
- `_private.AffineDualJT.WeylPolynomials.0.AffineDualJT.secondKind_eval.match_1_1`
- `_private.AffineDualJT.WeylPolynomials.0.AffineDualJT.weylPolyB_add_two._simp_1_2`

### `AffineDualJT.WeylReduction` (5)

- `AffineDualJT.weylSum_eq_reducedWeyl`
- `AffineDualJT.weylSummand_factor`
- `AffineDualJT.weylSummand_permutation_sum`
- `AffineDualJT.ExternalHL.signedVariables.eq_1`
- `AffineDualJT.ExternalHL.weylSummand.eq_1`

### `AffineDualJT.WeylSymmetrizer` (108)

- `AffineDualJT.SymmetrizerPairIndex`
- `AffineDualJT.Vn_succ`
- `AffineDualJT.eval_symmetrizerAlternantPolynomial`
- `AffineDualJT.eval_symmetrizerVandermondePolynomial`
- `AffineDualJT.pairProduct`
- `AffineDualJT.pairProduct_difference_permutation`
- `AffineDualJT.pairProduct_subtype`
- `AffineDualJT.pairProduct_succ`
- `AffineDualJT.symmetrizer`
- `AffineDualJT.symmetrizerAlternantPolynomial`
- `AffineDualJT.symmetrizerAlternantPolynomial_eq_Vn_mul_vandermonde`
- `AffineDualJT.symmetrizerAlternantPolynomial_eq_inverse`
- `AffineDualJT.symmetrizerAlternantPolynomial_eq_scalar_mul_vandermonde`
- `AffineDualJT.symmetrizerAlternantPolynomial_rename`
- `AffineDualJT.symmetrizerAlternantPolynomial_zeroHead`
- `AffineDualJT.symmetrizerAlternantPolynomial_zeroHead_subst`
- `AffineDualJT.symmetrizerAlternantScalar`
- `AffineDualJT.symmetrizerAlternantScalarQuotient`
- `AffineDualJT.symmetrizerAlternantScalarQuotient_eq_C`
- `AffineDualJT.symmetrizerAlternantScalarQuotient_is_constant`
- `AffineDualJT.symmetrizerAlternantScalarQuotient_spec`
- `AffineDualJT.symmetrizerAlternantScalar_eq_Vn`
- `AffineDualJT.symmetrizerAlternantScalar_one`
- `AffineDualJT.symmetrizerAlternantScalar_succ`
- `AffineDualJT.symmetrizerAlternantScalar_zero`
- `AffineDualJT.symmetrizerAlternant_difference_dvd`
- `AffineDualJT.symmetrizerAlternant_last_difference_dvd`
- `AffineDualJT.symmetrizerAlternant_vandermonde_dvd`
- `AffineDualJT.symmetrizerVandermondePairProduct`
- `AffineDualJT.symmetrizerVandermondePairProduct_eq`
- `AffineDualJT.symmetrizerVandermondePolynomial`
- `AffineDualJT.symmetrizerVandermondePolynomial_zeroHead`
- `AffineDualJT.symmetrizerVandermondePolynomial_zeroHead_subst`
- `AffineDualJT.symmetrizer_eq_alternant_div`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.eval_pairProduct`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.eval_pairProduct_F02`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.eval_symmetrizerInverseTerm_decomposeFin'Symm`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.pairProduct_comp_eq_of_symmetric`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.pairProduct_difference_ne_zero`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.pairProduct_div`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.pairProduct_eq_prod_Ioi`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.pairProduct_succ_F02`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.skewPairAux`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.skewPairAux_anti`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizerAlternantTerm_eq_inverseTerm`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizerAlternant_totalDegree_le`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizerInverseAlternantPolynomial`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizerInverseFactor`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizerInverseFactor_symmetric`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizerInverseTerm`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizerPairProduct_degree_le`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizerVandermonde_ne_zero`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizerVandermonde_totalDegree`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizerZeroHeadSubst`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizer_zero_position_coefficient`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizer_zero_position_factor_product`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.totalDegree_finsetProd_eq_sum`
- `AffineDualJT.pairProduct.eq_1`
- `AffineDualJT.pairProduct_difference_permutation._simp_1_1`
- `AffineDualJT.pairProduct_succ._simp_1_1`
- `AffineDualJT.pairProduct_succ._simp_1_2`
- `AffineDualJT.pairProduct_succ._simp_1_3`
- `AffineDualJT.pairProduct_succ._simp_1_4`
- `AffineDualJT.symmetrizer._simp_1_1`
- `AffineDualJT.symmetrizer._simp_1_2`
- `AffineDualJT.symmetrizer._simp_1_3`
- `AffineDualJT.symmetrizer._simp_1_4`
- `AffineDualJT.symmetrizer._simp_1_5`
- `AffineDualJT.symmetrizer._simp_1_6`
- `AffineDualJT.symmetrizer._simp_1_7`
- `AffineDualJT.symmetrizerAlternantPolynomial.eq_1`
- `AffineDualJT.symmetrizerAlternantPolynomial_rename._simp_1_1`
- `AffineDualJT.symmetrizerAlternantPolynomial_rename._simp_1_2`
- `AffineDualJT.symmetrizerAlternantPolynomial_rename._simp_1_3`
- `AffineDualJT.symmetrizerAlternantPolynomial_rename._simp_1_4`
- `AffineDualJT.symmetrizerAlternantPolynomial_rename._simp_1_5`
- `AffineDualJT.symmetrizerAlternantPolynomial_rename._simp_1_6`
- `AffineDualJT.symmetrizerAlternantPolynomial_rename._simp_1_7`
- `AffineDualJT.symmetrizerAlternantScalar.congr_simp`
- `AffineDualJT.symmetrizerAlternantScalarQuotient.congr_simp`
- `AffineDualJT.symmetrizerAlternantScalarQuotient_is_constant._proof_1_2`
- `AffineDualJT.symmetrizerAlternant_difference_dvd._proof_1_1`
- `AffineDualJT.symmetrizerAlternant_difference_dvd._proof_1_2`
- `AffineDualJT.symmetrizerAlternant_vandermonde_dvd._simp_1_1`
- `AffineDualJT.symmetrizerVandermondePolynomial.eq_1`
- `AffineDualJT.symmetrizer_eq_alternant_div._simp_1_1`
- `AffineDualJT.symmetrizer_eq_alternant_div._simp_1_2`
- `AffineDualJT.symmetrizer_eq_alternant_div._simp_1_3`
- `AffineDualJT.symmetrizer_eq_alternant_div._simp_1_4`
- `AffineDualJT.symmetrizer_eq_alternant_div._simp_1_5`
- `AffineDualJT.symmetrizer_eq_alternant_div._simp_1_6`
- `AffineDualJT.symmetrizer_eq_alternant_div._simp_1_7`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.eval_symmetrizerInverseTerm_decomposeFin'Symm._simp_1_2`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.pairProduct_eq_prod_Ioi._simp_1_1`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.pairProduct_succ_F02._simp_1_1`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.pairProduct_succ_F02._simp_1_2`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.pairProduct_succ_F02._simp_1_3`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.pairProduct_succ_F02._simp_1_4`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.skewPairAux.eq_1`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizerInverseFactor.eq_1`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizerInverseTerm.eq_1`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizerZeroHeadSubst.eq_1`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizer_zero_position_coefficient._proof_1_4`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizer_zero_position_coefficient._proof_1_5`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizer_zero_position_coefficient._simp_1_1`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizer_zero_position_coefficient._simp_1_2`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizer_zero_position_coefficient._simp_1_3`
- `AffineDualJT.ExternalHL.Vn.eq_1`

### `AffineDualJT.WidthZero` (11)

- `AffineDualJT.equation_1_5_width_zero_requires_separate_endpoint`
- `AffineDualJT.prop_6_1_B0`
- `AffineDualJT.prop_6_1_BC`
- `AffineDualJT.prop_6_1_Bminus`
- `AffineDualJT.prop_6_1_Bplus`
- `AffineDualJT.prop_6_1_Bt`
- `AffineDualJT.prop_6_1_C0`
- `AffineDualJT.prop_6_1_Ct`
- `AffineDualJT.ExternalHL.nuBminus.eq_1`
- `AffineDualJT.ExternalHL.nuBplus.eq_1`
- `AffineDualJT.ExternalHL.nuCt.eq_1`

### `AffineDualJT.WidthZeroColumns` (71)

- `AffineDualJT.width_zero_VB0_det`
- `AffineDualJT.width_zero_VBC_det`
- `AffineDualJT.width_zero_VBminus_det`
- `AffineDualJT.width_zero_VBplus_det`
- `AffineDualJT.width_zero_VBt_det`
- `AffineDualJT.width_zero_VC0_det`
- `AffineDualJT.width_zero_VC0_diagonal`
- `AffineDualJT.width_zero_VC0_upper`
- `AffineDualJT.width_zero_VCt_det`
- `AffineDualJT.width_zero_uCTilde_zero`
- `AffineDualJT.width_zero_VB0_det._proof_1_10`
- `AffineDualJT.width_zero_VB0_det._proof_1_11`
- `AffineDualJT.width_zero_VB0_det._proof_1_4`
- `AffineDualJT.width_zero_VB0_det._proof_1_5`
- `AffineDualJT.width_zero_VB0_det._proof_1_6`
- `AffineDualJT.width_zero_VB0_det._proof_1_7`
- `AffineDualJT.width_zero_VB0_det._proof_1_8`
- `AffineDualJT.width_zero_VB0_det._proof_1_9`
- `AffineDualJT.width_zero_VBminus_det._proof_1_3`
- `AffineDualJT.width_zero_VBminus_det._proof_1_4`
- `AffineDualJT.width_zero_VBminus_det._proof_1_5`
- `AffineDualJT.width_zero_VBminus_det._proof_1_6`
- `AffineDualJT.width_zero_VBminus_det._proof_1_7`
- `AffineDualJT.width_zero_VBplus_det._proof_1_1`
- `AffineDualJT.width_zero_VBplus_det._proof_1_10`
- `AffineDualJT.width_zero_VBplus_det._proof_1_11`
- `AffineDualJT.width_zero_VBplus_det._proof_1_12`
- `AffineDualJT.width_zero_VBplus_det._proof_1_5`
- `AffineDualJT.width_zero_VBplus_det._proof_1_6`
- `AffineDualJT.width_zero_VBplus_det._proof_1_7`
- `AffineDualJT.width_zero_VBplus_det._proof_1_8`
- `AffineDualJT.width_zero_VBplus_det._proof_1_9`
- `AffineDualJT.width_zero_VBt_det._proof_1_10`
- `AffineDualJT.width_zero_VBt_det._proof_1_11`
- `AffineDualJT.width_zero_VBt_det._proof_1_12`
- `AffineDualJT.width_zero_VBt_det._proof_1_13`
- `AffineDualJT.width_zero_VBt_det._proof_1_14`
- `AffineDualJT.width_zero_VBt_det._proof_1_15`
- `AffineDualJT.width_zero_VBt_det._proof_1_16`
- `AffineDualJT.width_zero_VBt_det._proof_1_17`
- `AffineDualJT.width_zero_VBt_det._proof_1_18`
- `AffineDualJT.width_zero_VBt_det._proof_1_19`
- `AffineDualJT.width_zero_VBt_det._proof_1_20`
- `AffineDualJT.width_zero_VBt_det._proof_1_21`
- `AffineDualJT.width_zero_VBt_det._proof_1_5`
- `AffineDualJT.width_zero_VBt_det._proof_1_6`
- `AffineDualJT.width_zero_VBt_det._proof_1_7`
- `AffineDualJT.width_zero_VBt_det._proof_1_8`
- `AffineDualJT.width_zero_VBt_det._proof_1_9`
- `AffineDualJT.width_zero_VC0_diagonal._proof_1_4`
- `AffineDualJT.width_zero_VC0_diagonal._proof_1_5`
- `AffineDualJT.width_zero_VC0_upper._proof_1_4`
- `AffineDualJT.width_zero_VC0_upper._proof_1_5`
- `AffineDualJT.width_zero_VC0_upper._proof_1_6`
- `AffineDualJT.width_zero_VC0_upper._proof_1_7`
- `AffineDualJT.width_zero_VC0_upper._proof_1_8`
- `AffineDualJT.width_zero_VC0_upper._proof_1_9`
- `AffineDualJT.width_zero_VCt_det._proof_1_3`
- `AffineDualJT.width_zero_VCt_det._proof_1_4`
- `AffineDualJT.width_zero_VCt_det._proof_1_5`
- `AffineDualJT.width_zero_VCt_det._proof_1_6`
- `AffineDualJT.width_zero_VCt_det._proof_1_7`
- `AffineDualJT.width_zero_uCTilde_zero._proof_1_10`
- `AffineDualJT.width_zero_uCTilde_zero._proof_1_2`
- `AffineDualJT.width_zero_uCTilde_zero._proof_1_3`
- `AffineDualJT.width_zero_uCTilde_zero._proof_1_5`
- `AffineDualJT.width_zero_uCTilde_zero._proof_1_6`
- `AffineDualJT.width_zero_uCTilde_zero._proof_1_7`
- `AffineDualJT.width_zero_uCTilde_zero._proof_1_8`
- `AffineDualJT.width_zero_uCTilde_zero._proof_1_9`
- `AffineDualJT.ExternalHL.pochhammer.eq_1`

### `AffineDualJT.WidthZeroReduced` (7)

- `AffineDualJT.reduced_B0_width_zero`
- `AffineDualJT.reduced_BC_width_zero`
- `AffineDualJT.reduced_Bminus_width_zero`
- `AffineDualJT.reduced_Bplus_width_zero`
- `AffineDualJT.reduced_Bt_width_zero`
- `AffineDualJT.reduced_C0_width_zero`
- `AffineDualJT.reduced_Ct_width_zero`

## 未逐项数学解释的定义 ID

- `AffineDualJT.CB`
- `AffineDualJT.CC`
- `AffineDualJT.CPlus`
- `AffineDualJT.CoeffSystem._sizeOf_1`
- `AffineDualJT.CoeffSystem._sizeOf_inst`
- `AffineDualJT.CoeffSystem.casesOn`
- `AffineDualJT.CoeffSystem.ctorIdx`
- `AffineDualJT.CoeffSystem.mk._flat_ctor`
- `AffineDualJT.CoeffSystem.mk.noConfusion`
- `AffineDualJT.CoeffSystem.noConfusion`
- `AffineDualJT.CoeffSystem.noConfusionType`
- `AffineDualJT.CoeffSystem.recOn`
- `AffineDualJT.ExternalHL.Admissible.casesOn`
- `AffineDualJT.ExternalHL.Admissible.mk._flat_ctor`
- `AffineDualJT.ExternalHL.Admissible.recOn`
- `AffineDualJT.SymmetrizerPairIndex`
- `AffineDualJT.adjacentColumnTransform`
- `AffineDualJT.alternantPolyBasic`
- `AffineDualJT.alternantPolyBminus`
- `AffineDualJT.alternantPolyBminus_eval._f`
- `AffineDualJT.alternantPolyBminus_eval.match_1_1`
- `AffineDualJT.alternantPolyCt`
- `AffineDualJT.basicWeightedMatrix`
- `AffineDualJT.classicalV`
- `AffineDualJT.dickson_first_eval._f`
- `AffineDualJT.dickson_first_eval.match_1_1`
- `AffineDualJT.dickson_second_eval._f`
- `AffineDualJT.dickson_second_eval.match_1_1`
- `AffineDualJT.finiteBasicRow`
- `AffineDualJT.finiteBminusRow`
- `AffineDualJT.finiteCtRow`
- `AffineDualJT.invertedVariables`
- `AffineDualJT.mapWeylVariables`
- `AffineDualJT.pairProduct`
- `AffineDualJT.residueSum`
- `AffineDualJT.symmetrizerAlternantPolynomial`
- `AffineDualJT.symmetrizerAlternantScalar`
- `AffineDualJT.symmetrizerAlternantScalarQuotient`
- `AffineDualJT.symmetrizerVandermondePairProduct`
- `AffineDualJT.symmetrizerVandermondePolynomial`
- `AffineDualJT.weightedAlternant`
- `AffineDualJT.weylPolyB`
- `AffineDualJT.weylPolyC`
- `AffineDualJT.weylPolyPlus`
- `_private.AffineDualJT.DeterminantFinsum.0.AffineDualJT.rowSupportFinset`
- `_private.AffineDualJT.FiniteColumnData.0.AffineDualJT.kZ`
- `_private.AffineDualJT.FiniteUnfolding.0.AffineDualJT.positiveRows`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paperBminusFactor.match_1.splitter`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paperCtFactor.match_1.splitter`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paperFinUpperEquiv`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paper_one_add_odd_pow_geom._f`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paper_one_add_odd_pow_geom.match_1_1`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paper_one_sub_pow_geom._f`
- `_private.AffineDualJT.PaperAlternantDivisibility.0.AffineDualJT.paper_one_sub_pow_geom.match_1_1`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperInjectiveTupleEquiv`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperPermOfTuple`
- `_private.AffineDualJT.PaperCauchyBinet.0.AffineDualJT.paperSubsetComplementEquiv`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperFinsetSplitPermFin`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperQ0BlockFlip`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperQ0Split`
- `_private.AffineDualJT.PaperTopForms.0.AffineDualJT.paperRowStack.match_1.splitter`
- `_private.AffineDualJT.SymmetricPairProducts.0.AffineDualJT.pairPermutation`
- `_private.AffineDualJT.SymmetricPairProducts.0.AffineDualJT.permutePair`
- `_private.AffineDualJT.WeylPolynomials.0.AffineDualJT.bKind_eval._f`
- `_private.AffineDualJT.WeylPolynomials.0.AffineDualJT.bKind_eval.match_1_1`
- `_private.AffineDualJT.WeylPolynomials.0.AffineDualJT.dickson_degree_data._f`
- `_private.AffineDualJT.WeylPolynomials.0.AffineDualJT.dickson_degree_data.match_1_1`
- `_private.AffineDualJT.WeylPolynomials.0.AffineDualJT.secondKind_eval._f`
- `_private.AffineDualJT.WeylPolynomials.0.AffineDualJT.secondKind_eval.match_1_1`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.skewPairAux`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizerInverseAlternantPolynomial`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizerInverseFactor`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizerInverseTerm`
- `_private.AffineDualJT.WeylSymmetrizer.0.AffineDualJT.symmetrizerZeroHeadSubst`
