"""Additional compiled semantic mutations using this paper's actual Spec types.

The deterministic main checker already has three minimal acceptance-boundary
fixtures. These supplementary probes import the real frozen project and test
StatementA13 itself in temporary modules. They never edit the project sources.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import shutil
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'scripts'))
from fidelity.common import canonical_digest, input_snapshot, now, tool_snapshot

FIXED = ROOT / '.tooling/elan/toolchains/leanprover--lean4---v4.35.0-rc3/bin'
HEADER = 'import FidelityLean.Certificates\nnoncomputable section\nnamespace Fidelity.PaperMutation\n'
BODIES = {
 'paper_goal_added_as_hypothesis': '''theorem result (n k : ℕ) (target : Fidelity.Spec.StatementA13 n k) :
    Fidelity.Spec.StatementA13 n k := target
''',
 'paper_width_restricted_to_one': '''theorem result (n : ℕ) : Fidelity.Spec.StatementA13 n 1 :=
  Fidelity.Certificate.A13 n 1
''',
 'paper_left_redefined_as_rhs': '''def rhs (n k : ℕ) : Fidelity.Spec.ParameterField n :=
  Fidelity.Spec.JK (k := k) (2 * (k : ℤ) + 1)
    (Fidelity.Spec.weightB0 (Fidelity.Spec.symbolicParameter n))
    (Fidelity.Spec.hKernel (Fidelity.Spec.symbolicX n))
def fakeP (n k : ℕ) : Fidelity.Spec.ParameterField n := rhs n k
theorem result (n k : ℕ) (_hn : 0 < n) : fakeP n k = rhs n k := rfl
'''}
EXPECTED = '''import Mutant
theorem fixed_paper_acceptance : ∀ n k : ℕ, Fidelity.Spec.StatementA13 n k :=
  Fidelity.PaperMutation.result
'''

def run():
 env = os.environ.copy()
 if FIXED.is_dir():
  env['PATH'] = str(FIXED) + os.pathsep + env.get('PATH', '')
  env['ELAN_HOME'] = str(ROOT / '.tooling/elan')
 lake = shutil.which('lake', path=env.get('PATH'))
 assert lake, 'Install the pinned Lean toolchain before running these probes.'
 sibling = Path(lake).with_name('lean')
 lean = str(sibling) if sibling.is_file() else shutil.which('lean', path=env.get('PATH'))
 assert lean, 'The pinned Lean executable is unavailable.'
 path = subprocess.run([lake, 'env', 'printenv', 'LEAN_PATH'], cwd=ROOT,
                       env=env, capture_output=True, text=True, check=True).stdout.strip()
 version = subprocess.run([lean, '--version'], env=env, capture_output=True, text=True, check=True).stdout.strip()
 assert '4.35.0-rc3' in version
 before = input_snapshot(ROOT)
 records = []
 for name, body in BODIES.items():
  with tempfile.TemporaryDirectory(prefix='paper-semantic-mutant-') as directory:
   folder = Path(directory)
   source = HEADER + body + 'end Fidelity.PaperMutation\n#print axioms Fidelity.PaperMutation.result\n'
   (folder / 'Mutant.lean').write_text(source)
   (folder / 'Acceptance.lean').write_text(EXPECTED)
   case_env = dict(env)
   case_env['LEAN_PATH'] = str(folder) + os.pathsep + path
   steps = []
   for filename, output in [('Mutant.lean', 'Mutant.olean'), ('Acceptance.lean', 'Acceptance.olean')]:
    command = [lean, '-o', str(folder / output), str(folder / filename)]
    result = subprocess.run(command, cwd=folder, env=case_env, capture_output=True, text=True, check=False)
    steps.append({'argv': command, 'cwd': str(folder), 'exit_code': result.returncode,
                  'stdout': result.stdout, 'stderr': result.stderr})
   accepted = (steps[0]['exit_code'] == 0 and steps[1]['exit_code'] != 0
               and 'sorryAx' not in steps[0]['stdout'] + steps[0]['stderr']
               and 'type mismatch' in (steps[1]['stdout'] + steps[1]['stderr']).lower())
   records.append({'id': name, 'status': 'pass' if accepted else 'fail',
                   'mutant_source': source, 'mutant_source_sha256': hashlib.sha256(source.encode()).hexdigest(),
                   'acceptance_source': EXPECTED, 'acceptance_source_sha256': hashlib.sha256(EXPECTED.encode()).hexdigest(),
                   'steps': steps, 'meaning': 'The wrong paper interface compiles; the unchanged real paper Spec type rejects it.'})
 assert before == input_snapshot(ROOT)
 report = {'schema_version': 1, 'finished_at': now(), 'lean_version': version,
           'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'snapshot_sha256': canonical_digest(before), 'tools_sha256': canonical_digest(tool_snapshot(ROOT)),
           'supporting_only': True, 'uses_actual_paper_type': 'Fidelity.Spec.StatementA13',
           'cases': records, 'status': 'pass' if all(r['status'] == 'pass' for r in records) else 'fail'}
 (Path(__file__).parent / 'results.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
 print(report['status'], [r['id'] for r in records])
 return 0 if report['status'] == 'pass' else 1

if __name__ == '__main__':
 raise SystemExit(run())
