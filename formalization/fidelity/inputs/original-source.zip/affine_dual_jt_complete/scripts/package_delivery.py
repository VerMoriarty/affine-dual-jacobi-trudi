#!/usr/bin/env python3
"""Package the source delivery and SHA-256 checksums using only Python's stdlib.

This command does not run Lean or certify that verification has passed.
"""

import argparse
import hashlib
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE_ROOT = "affine_dual_jt_complete"
REQUIRED_FILES = (
    ".gitignore",
    "AffineDualJT.lean",
    "README.md",
    "STATIC_CHECK.json",
    "lean-toolchain",
    "lean-toolchain.rc3",
    "lakefile.toml",
    "lakefile.rc3.toml",
    "lake-manifest.json",
    "source.tex",
    "source.pdf",
    "scripts/check_foundation.sh",
    "scripts/check_formalization.sh",
    "scripts/check_sorries.sh",
    "scripts/proof_status.py",
    "scripts/build_rc3.sh",
    "scripts/package_delivery.py",
    "scripts/deliver.sh",
)
OPTIONAL_FILES = (
    "delivery_logs/environment.log",
    "delivery_logs/build.log",
    "delivery_logs/foundation.log",
    "delivery_logs/formalization.log",
)


def delivery_files() -> list[Path]:
    paths = {ROOT / name for name in REQUIRED_FILES}
    missing = sorted(str(path.relative_to(ROOT)) for path in paths if not path.is_file())
    if missing:
        raise ValueError("Missing required delivery files: " + ", ".join(missing))
    modules = set((ROOT / "AffineDualJT").rglob("*.lean"))
    if not modules:
        raise ValueError("No Lean modules found in AffineDualJT/")
    paths.update(modules)
    paths.update((ROOT / "scripts").glob("*.py"))
    paths.update((ROOT / "scripts").glob("*.sh"))
    paths.update(ROOT / name for name in OPTIONAL_FILES if (ROOT / name).exists())
    for path in paths:
        # Do not follow links that could include files outside the project.
        if path.is_symlink() or any(
            (ROOT / parent).is_symlink() for parent in path.relative_to(ROOT).parents
        ):
            raise ValueError(f"Symlinks are not allowed in delivery files: {path}")
        if not path.is_file() or not path.resolve().is_relative_to(ROOT):
            raise ValueError(f"Not a regular project file: {path}")
    return sorted(paths)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path,
        default=ROOT / "dist" / f"{ARCHIVE_ROOT}-source.zip",
        help="ZIP destination; replace existing archive/checksum files",
    )
    args = parser.parse_args()
    output = args.output.absolute()
    checksum = output.with_name(output.name + ".sha256")
    if output.suffix.lower() != ".zip":
        parser.error("--output must end in .zip")
    try:
        paths = delivery_files()
        output.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix=".package-", dir=output.parent) as temporary:
            staged_output = Path(temporary) / output.name
            staged_checksum = Path(temporary) / checksum.name
            manifest = []
            with zipfile.ZipFile(staged_output, "x", compression=zipfile.ZIP_DEFLATED) as archive:
                for path in paths:
                    relative = path.relative_to(ROOT).as_posix()
                    data = path.read_bytes()
                    info = zipfile.ZipInfo.from_file(path, f"{ARCHIVE_ROOT}/{relative}")
                    archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED)
                    manifest.append(f"{hashlib.sha256(data).hexdigest()}  {relative}\n")
                archive.writestr(
                    f"{ARCHIVE_ROOT}/DELIVERY_MANIFEST.sha256", "".join(manifest),
                )
            digest = hashlib.sha256(staged_output.read_bytes()).hexdigest()
            staged_checksum.write_text(
                f"{digest}  {output.name}\n", encoding="utf-8",
            )
            staged_output.replace(output)
            staged_checksum.replace(checksum)
    except (OSError, ValueError) as error:
        print(f"Delivery packaging failed: {error}", file=sys.stderr)
        return 1
    print(f"ZIP: {output}")
    print(f"SHA-256: {checksum}")
    print(f"Packaged {len(paths)} files plus DELIVERY_MANIFEST.sha256; .lake/ excluded.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
